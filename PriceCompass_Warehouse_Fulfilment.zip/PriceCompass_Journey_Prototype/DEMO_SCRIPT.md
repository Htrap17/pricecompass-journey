# PriceCompass warehouse walkthrough

Use root index.html. Catalogue data, outcome rates and sample costs are demonstration inputs, not live seller evidence.

## 1. Start with costs

Point to **Demo using a sample catalogue**. The catalogue provides the product, 250 g weight and current buyer price ₹210. Costs and target start blank. **Ship from my location** is selected.

Choose **Try sample values**: purchase ₹55, packing ₹5, minimum earnings ₹10. Choose **Suggest a price**.

The suggestion is **₹193**. Payout is **₹95.65 to ₹102.73** and average earnings are **₹10.08 to ₹17.52**. Explain: “This is the lowest supported price meeting the target using the cautious estimate. Forward shipping is assumed to be half the reverse fee, with GST added. Confirm the payout in Meesho.”

Move the slider or type a price to show immediate updates.

## 2. Explain the warehouse option

Return to Product costs and select **Use a warehouse**. With carrier and distance unknown, no supported price meets the ₹10 target. This is an uncertainty result, not a recommendation to increase price beyond the comparison range.

Open More details, then Shipping and returns. Select **Valmo** and **Over 500 km**. Update shipping settings. The suggestion becomes **₹202**. Type buyer price **₹189** to demonstrate the supplied example.

Open How earnings are calculated:

- Forward fee ₹72.50, which is half the warehouse reverse fee ₹145.
- Forward GST ₹13.05.
- Warehouse delivery handling ₹20 and GST ₹3.60.
- Estimated payout ₹79.85.
- Total customer-return cost ₹171.10, which is ₹145 plus GST only.

No extra warehouse return handling is charged in this model. At this price, sample average earnings are **-₹0.99**, below the target. Use suggested price to return to ₹202, which gives payout ₹92.85 and average earnings ₹10.06 in this selected scenario.

Warehouse inbound transport, old-inventory and rejected-stock costs are excluded. Their rate-card rows remain reference information under More details.

## 3. Confirm and save

Choose the price. A real seller enters the actual net panel payout and total return charge including all applicable GST. These totals override estimates directly; no further shipping or warehouse deduction is applied.

For a separate historical demonstration at buyer price ₹189, net payout ₹96 and total return fee ₹153 reproduce average earnings ₹14.55. Do not describe those recorded totals as the output of the new rate formula or as a current quote.

Save the choice. It stays in this session and does not update the Meesho listing. Change price or fulfilment to show that confirmation is cleared and the saved choice needs review.

The supplied rate card is not verified as a current official tariff. The half-fee formula is a seller-authorised demo assumption. There is no live integration, exact pincode quote or automatic stock purchase.
