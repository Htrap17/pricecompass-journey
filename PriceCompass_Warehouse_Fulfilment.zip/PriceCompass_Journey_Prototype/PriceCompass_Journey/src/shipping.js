/* Bundled indicative observations, not an official Meesho tariff. No network calls. */
(function(root){
 'use strict';
 const sources = {
  ecomarray: {name:'EcomArray · indicative observations',url:'https://www.ecomarray.com/what-are-the-shipping-charges-for-sellers-on-meesho',published:'2025-12-02',retrieved:'2026-10-05'},
  shiprocket: {name:'Shiprocket · reproduces seller-reported observations',url:'https://www.shiprocket.in/blog/meesho-shipping-charges/',published:'2026-02-17',retrieved:'2026-10-05'},
  rto: {name:'Meesho shipping policy · no additional RTO shipping fee',url:'https://supplier.meesho.com/shipping',published:null,retrieved:'2026-10-05'}
 };
 const cards = [
  {max:500,local:[35,45],regional:[45,70],national:[55,90]},
  {max:1000,local:[50,70],regional:[65,95],national:[80,120]},
  {max:1500,local:[60,85],regional:[80,120],national:[100,150]},
  {max:2000,local:[70,95],regional:[95,135],national:[120,170]}
 ];
 const carriers = {valmo:[153,163,169,184],ecom:[165,175,181,196],shadowfax:[162,172,178,192],delhivery:[161,203,244,290],xpressbees:[155,165,171,186]};
 const supplied = {
  source:{name:'Seller-supplied screenshot',url:null,published:null,retrieved:'2026-10-05',taxBasis:'GST exclusive, confirmed by seller',returnCoverage:'Reverse shipping only, confirmed by seller'},
  bands:[500,1000,1500,2000,2500],
  self:{valmo:[153,163,169,184,202],xpressbees:[155,165,171,186,204],shadowfax:[162,172,178,192,210],delhivery:[161,203,244,290,340],ecom:[165,175,181,196,213]},
  warehouse:{valmo:[145,155,161,176,194],xpressbees:[147,157,163,178,196],shadowfax:[154,164,170,184,202],delhivery:[153,195,236,282,332],ecom:[157,167,173,188,205]},
  handling:[
   {max:150,local:4,national:15,returnHandling:12.75,oldInventory:7.5,reject:4},
   {max:500,local:10,national:20,returnHandling:14,oldInventory:17,reject:11},
   {max:1000,local:13.5,national:27,returnHandling:14.75,oldInventory:28,reject:17},
   {max:2000,local:28,national:40,returnHandling:20.5,oldInventory:50,reject:30},
   {max:null,local:38,national:67,returnHandling:20.5,oldInventory:104,reject:66}
  ]
 };
 const carrierNames = {unknown:'Carrier not confirmed',valmo:'Valmo',ecom:'Ecom Express',shadowfax:'Shadowfax',delhivery:'Delhivery',xpressbees:'Xpressbees'};
 const round=x=>Math.round((x+Number.EPSILON)*100)/100;
 const amount=x=>typeof x==='number'&&Number.isFinite(x)&&x>=0;
 const rangeOK=x=>Array.isArray(x)&&x.length===2&&x.every(amount)&&x[0]<=x[1];
 function defaults(){return {mode:'historical',buyer:189,zone:'national',taxBasis:'exclusive',carrier:'unknown',returnTaxBasis:'unknown',panelWeight:null,other:0,rateSource:'ecomarray',manualForward:[null,null],manualReturn:[null,null],confirmed:null};}
 function slab(weight){return typeof weight==='number'&&Number.isFinite(weight)&&weight>0?cards.findIndex(c=>weight<=c.max):-1;}
 function tax(value,basis){
  if(!amount(value)||!['exclusive','inclusive'].includes(basis))return null;
  if(basis==='exclusive'){const gst=round(value*.18);return {base:round(value),gst,gross:round(value+gst)};}
  const base=round(value/1.18);return {base,gst:round(value-base),gross:round(value)};
 }
 function taxes(values,basis){const endpoints=values.map(x=>tax(x,basis));return {base:endpoints.map(x=>x.base),gst:endpoints.map(x=>x.gst),gross:endpoints.map(x=>x.gross)};}
 function context(s){const c=s.shipping||defaults();return JSON.stringify({weight:s.product.packedWeight,weightSource:s.product.packedWeightSource,panelWeight:c.panelWeight,fulfilment:s.product.fulfilment,buyer:c.buyer,zone:c.zone,taxBasis:c.taxBasis,carrier:c.carrier,returnTaxBasis:c.returnTaxBasis,other:c.other,rateSource:c.rateSource,manualForward:c.manualForward,manualReturn:c.manualReturn,feeProfile:c.feeProfile||'legacy',fulfilmentOption:c.fulfilment||'self',forwardMethod:c.forwardMethod||'published',warehouseDistance:c.warehouseDistance||'unknown',cardVersion:c.feeProfile==='supplied'?'seller-screenshot-2026-10-05':'observations-2026-10-05'});}
 function calculate(s){
  if(s.shipping?.feeProfile==='supplied')return calculateSupplied(s);
  const c=s.shipping||defaults(),errs=[],weight=c.panelWeight===null?s.product.packedWeight:c.panelWeight;
  if(typeof weight!=='number'||!Number.isFinite(weight)||weight<=0)errs.push('Enter a positive packed or panel chargeable weight.');
  if(!amount(c.buyer)||c.buyer<=0)errs.push('Buyer total must be greater than zero.');
  if(!amount(c.other))errs.push('Other deductions must be zero or more.');
  if(!['local','regional','national'].includes(c.zone))errs.push('Choose a delivery zone.');
  if(!['exclusive','inclusive'].includes(c.taxBasis))errs.push('Choose the forward-fee GST basis.');
  if(!['unknown','exclusive','inclusive'].includes(c.returnTaxBasis))errs.push('Choose a return-fee GST basis.');
  if(!Object.hasOwn(carrierNames,c.carrier))errs.push('Choose a return carrier.');
  if(!['ecomarray','shiprocket','manual'].includes(c.rateSource))errs.push('Choose a rate source.');
  const hardErrors=[...errs];
  const index=slab(weight);let forward=null,reverse=null;
  if(c.rateSource==='manual'){
   if(!rangeOK(c.manualForward))errs.push('Enter a valid manual forward-fee range.');else forward=c.manualForward;
  }else if(index<0){errs.push('No published band above 2 kg. Enter manual forward and return rates; no extrapolation.');}
  else forward=cards[index][c.zone];
  if(c.rateSource==='manual'){
   if(!rangeOK(c.manualReturn))errs.push('Enter a valid manual return-fee range.');else reverse=c.manualReturn;
  }else if(index>=0){const vals=c.carrier==='unknown'?Object.values(carriers).map(x=>x[index]):[carriers[c.carrier]?.[index]];if(vals.every(amount))reverse=[Math.min(...vals),Math.max(...vals)];}
  const result={ok:false,errors:errs,mode:c.mode,weight,weightBasis:c.panelWeight===null?(s.product.packedWeightSource==='measured'?'Measured packed weight; panel slab not confirmed':'Scenario packed weight; enter your measured packed weight'):'Panel-assigned chargeable weight supplied',slab:index>=0?`${index===0?'0':cards[index-1].max}–${cards[index].max} g`:'Manual rates required',source:c.rateSource==='manual'?{name:'Manual scenario rates · not an official quote',url:null,published:null,retrieved:null}:sources[c.rateSource],returnSource:sources.ecomarray,rtoSource:sources.rto,rtoFee:0,other:c.other,buyer:c.buyer,confirmed:false,forward:null,returns:null,payout:null};
  if(c.rateSource==='manual')result.returnSource=result.source;
  if(!errs.length&&forward&&reverse){
   result.forward=taxes(forward,c.taxBasis);
   const alternatives=['inclusive','exclusive'].map(b=>({basis:b,...taxes(reverse,b)}));
   const active=c.returnTaxBasis==='unknown'?alternatives:alternatives.filter(x=>x.basis===c.returnTaxBasis);
   result.returns={listed:reverse,alternatives,taxBasis:c.returnTaxBasis,gross:[Math.min(...active.map(x=>x.gross[0])),Math.max(...active.map(x=>x.gross[1]))]};
   result.payout=[round(c.buyer-result.forward.gross[1]-c.other),round(c.buyer-result.forward.gross[0]-c.other)];result.ok=true;
  }
  // A supplied payout is already net. Do not subtract forward fees or GST from it again.
  if(c.mode==='confirmed'){
   const quote=c.confirmed;
   if(hardErrors.length){result.ok=false;}
   else if(!quote){errs.push('Enter and confirm a supplier-panel payout and total return fee.');}
   else if(quote.context!==context(s)){errs.push('Shipping context changed. Reconfirm the panel quote for this weight, zone and fee basis.');}
   else if(!amount(quote.transfer)||quote.transfer>c.buyer||!amount(quote.returnGross)){errs.push('Confirmed payout and return fee are invalid.');}
   else{
    result.payout=[quote.transfer,quote.transfer];result.returns={listed:[quote.returnGross,quote.returnGross],taxBasis:'inclusive',alternatives:[],gross:[quote.returnGross,quote.returnGross]};result.confirmed=true;result.source={name:'Supplier-panel quote · manually confirmed by seller',url:null,published:quote.date,retrieved:quote.date};
    // Missing online rates do not invalidate a complete, context-matched panel quote.
    result.errors=[];result.ok=true;result.returnSource=result.source;if(index<0)result.slab='Outside bundled bands · panel quote used';
   }
   if(!result.confirmed){result.ok=false;result.payout=null;}
  }
  result.estimateStatus=result.confirmed?'seller-confirmed':!result.ok?'needs-input-or-revalidation':c.rateSource==='manual'?'manual-estimate':'indicative-estimate';
  return result;
 }
 function calculateSupplied(s){
  const c=s.shipping,errors=[],weight=c.panelWeight===null?s.product.packedWeight:c.panelWeight;
  if(!Number.isFinite(weight)||weight<=0)errors.push('Enter a positive packed or panel chargeable weight.');
  if(!amount(c.buyer)||c.buyer<=0)errors.push('Buyer total must be greater than zero.');
  if(!amount(c.other))errors.push('Other deductions must be zero or more.');
  if(!['self','warehouse'].includes(c.fulfilment))errors.push('Choose how you will ship this product.');
  if(!['half-return','published','manual'].includes(c.forwardMethod))errors.push('Choose a shipping calculation method.');
  if(!['local','regional','national'].includes(c.zone))errors.push('Choose a delivery zone.');
  if(!['local','national','unknown'].includes(c.warehouseDistance))errors.push('Choose a warehouse distance.');
  if(!Object.hasOwn(carrierNames,c.carrier))errors.push('Choose a return carrier.');
  if(!['ecomarray','shiprocket','manual'].includes(c.rateSource))errors.push('Choose a rate source.');
  if(c.taxBasis!=='exclusive'||c.returnTaxBasis!=='exclusive')errors.push('The supplied fees exclude GST. Add 18% GST.');
  if(c.forwardMethod==='published'&&!['ecomarray','shiprocket'].includes(c.rateSource))errors.push('Choose a published forward-rate source.');
  const hardErrors=[...errors],index=weight>0?supplied.bands.findIndex(max=>weight<=max):-1;
  const handling=weight>0?supplied.handling.find(row=>row.max===null||weight<=row.max):null;
  let reverse=null,forward=null;
  if(c.forwardMethod==='manual'){
   if(!rangeOK(c.manualForward))errors.push('Enter a valid manual forward-fee range.');else forward=c.manualForward;
   if(!rangeOK(c.manualReturn))errors.push('Enter a valid manual return-fee range.');else reverse=c.manualReturn;
  }else{
   if(index<0)errors.push('For parcels above 2,500 g, enter shipping and return fees in More details.');
   else if(Object.hasOwn(supplied,c.fulfilment)){
    const table=supplied[c.fulfilment],values=c.carrier==='unknown'?Object.values(table).map(row=>row[index]):[table[c.carrier]?.[index]];
    if(values.every(amount))reverse=[Math.min(...values),Math.max(...values)];
   }
   if(c.forwardMethod==='half-return'&&reverse)forward=reverse.map(x=>round(x/2));
   if(c.forwardMethod==='published'){
    if(c.fulfilment!=='self')errors.push('Published shipping estimates apply only to shipping from your location.');
    const band=slab(weight);
    if(band<0)errors.push('Published forward estimates stop at 2,000 g. Choose the demo formula or enter rates.');
    else forward=cards[band][c.zone];
   }
  }
  const result={ok:false,errors,mode:c.mode,weight,weightBasis:c.panelWeight===null?(s.product.packedWeightSource==='measured'?'Measured packed weight':'Sample catalogue weight'):'Panel chargeable weight',slab:index>=0?`${index===0?0:supplied.bands[index-1]} to ${supplied.bands[index]} g`:'Manual rates required',source:c.forwardMethod==='manual'?{name:'Manually entered fees excluding GST',url:null,published:null,retrieved:null}:c.forwardMethod==='published'?sources[c.rateSource]:supplied.source,returnSource:c.forwardMethod==='manual'?{name:'Manually entered reverse fee',url:null}:supplied.source,rtoSource:sources.rto,rtoFee:0,other:c.other,buyer:c.buyer,confirmed:false,forward:null,warehouse:null,returns:null,payout:null,fulfilment:c.fulfilment,forwardMethod:c.forwardMethod,assumption:c.forwardMethod==='half-return'?'Shipping uses a demo assumption: forward fee is half the listed reverse fee.':'',warehouseSource:supplied.source};
  if(!errors.length&&forward&&reverse&&handling){
   const w=c.fulfilment==='warehouse'?(c.warehouseDistance==='unknown'?[handling.local,handling.national]:[handling[c.warehouseDistance],handling[c.warehouseDistance]]):[0,0];
   result.forward=taxes(forward,'exclusive');result.warehouse=taxes(w,'exclusive');
   result.returns={listed:reverse,taxBasis:'exclusive',alternatives:[{basis:'exclusive',...taxes(reverse,'exclusive')}],...taxes(reverse,'exclusive')};
   result.payout=[round(c.buyer-result.forward.gross[1]-result.warehouse.gross[1]-c.other),round(c.buyer-result.forward.gross[0]-result.warehouse.gross[0]-c.other)];result.ok=true;
  }
  if(c.mode==='confirmed'){
   const quote=c.confirmed;
   if(hardErrors.length)result.ok=false;
   else if(!quote)errors.push('Enter and confirm the net payout and total return charge from Meesho.');
   else if(quote.context!==context(s))errors.push('Your shipping details changed. Confirm the panel payout again.');
   else if(!amount(quote.transfer)||quote.transfer>c.buyer||!amount(quote.returnGross))errors.push('Confirmed payout and return fee are invalid.');
   else{
    result.ok=true;result.errors=[];result.confirmed=true;result.payout=[quote.transfer,quote.transfer];
    result.forward=null;result.warehouse=null;result.returns={listed:[quote.returnGross,quote.returnGross],gross:[quote.returnGross,quote.returnGross],taxBasis:'inclusive',alternatives:[]};
    result.source={name:'Net panel payout supplied by seller',url:null,published:quote.date,retrieved:quote.date};result.returnSource=result.source;result.assumption='';
   }
   if(!result.confirmed){result.ok=false;result.payout=null;}
  }
  result.estimateStatus=result.confirmed?'seller-confirmed':!result.ok?'needs-input-or-revalidation':c.forwardMethod==='half-return'?'demo-assumption':c.forwardMethod==='manual'?'manual-estimate':'indicative-estimate';
  return result;
 }
 const api={sources,supplied,cards,carriers,carrierNames,defaults,slab,tax,taxes,context,calculate,round};
 if(typeof module!=='undefined')module.exports=api;else root.PCShipping=api;
})(globalThis);
