'use strict';
/* PriceCompass one-SKU journey: interface. All state is in memory; nothing leaves the page. */
const M = PCJourney, P = PCRecord;
function startingState(){const s=P.base();s.shipping.mode='online';return s;}
let S = startingState(), step = 'quotes', review = null, K = 20, lastChange = null, noteMsg = '';
let quoteEditor = false, quoteMessage = '';
const COHORT_ID = 'PC-CABLE-5M-v1-D1-D9';
const HISTORICAL_INPUTS = P.base();
const $ = id => document.getElementById(id);
const esc = x => String(x).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const inr = x => typeof x === 'number' && Number.isFinite(x)
  ? (x < 0 ? '−' : '') + '₹' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: Number.isInteger(M.r2(x)) ? 0 : 2, maximumFractionDigits: 2 }).format(Math.abs(M.r2(x)))
  : '–';
const inr2 = x => typeof x === 'number' ? (x < 0 ? '−' : '') + '₹' + Math.abs(M.r2(x)).toFixed(2) : '–';
const pct = x => M.r2(x) + '%';
const tag = (t, cls = '') => `<span class="tag ${cls}">${esc(t)}</span>`;
const SRC = { audit: ['Observed · audit 28 Sep 2026', 'obs'], panel: ['Historical panel', 'hist'], panelFee: ['Panel / fee page', 'hist'], derived: ['Estimate (formula)', 'est'],
  assumed: ['Assumption', 'asm'], generated: ['Generated register', 'gen'], synthetic: ['Synthetic test cohort', 'gen'], calc: ['Calculation', 'calc'], missing: ['Missing', 'miss'] };
const src = k => tag(SRC[k][0], SRC[k][1]);
const STEPS = [['product', '1', 'Confirm your product'], ['alternatives', '2', 'Comparable offers'], ['quotes', '3', 'Price and payout'], ['economics', '4', 'Earnings after returns'],
  ['constraints', '5', 'Cash and stock'], ['decision', '6', 'Your decision'], ['review', '7', 'Review and learn']];
const ev = () => M.evaluate(S);

function strip(e) {
  const prodGaps = [S.product.conductor === null, S.product.packedWeightSource !== 'measured', S.product.offlinePrice === null].filter(Boolean).length;
  const st = {
    product: `${prodGaps} gaps`,
    alternatives: `${e.cmp.n} qualified${S.mode === 'real' ? ' (audit)' : ' (register)'}`,
    quotes: S.shipping.mode!=='historical' ? pricingLabels[S.shipping.mode] + (e.shipping.confirmed?' · current context':' · estimate/review') : S.mode === 'real' ? 'not current' : S.quoteValid ? `valid · v${S.versions.quotes}` : 'INVALID',
    economics: e.shipping ? (e.rows[0].econRange ? moneyRange(e.rows[0].econRange.expected) : 'unconfirmed') : e.choice ? inr(e.choice.econ.expected) + ' / dispatch' : (e.rows[0].econ ? inr(e.rows[0].econ.expected) : 'ceilings only'),
    constraints: e.proc.known ? (e.proc.blocked ? 'blocked' : `${e.proc.units} units · ${inr(e.proc.need)}`) : 'unverified',
    decision: decisionLabel(e),
    review: review ? `v${S.versions.outcomes} updated` : 'not yet'
  };
  const bad = { quotes: S.mode === 'real' || !S.quoteValid, constraints: e.proc.blocked, decision: e.status !== 'READY FOR YOUR APPROVAL', alternatives: e.cmp.n === 0 };
  return `<ol class="strip">${STEPS.map(([id, n, name]) => `<li><button data-step="${id}" aria-current="${step === id ? 'step' : 'false'}" class="${step === id ? 'on' : ''} ${bad[id] ? 'warn' : ''}"><b>${n} · ${name}</b><span>${esc(st[id])}</span></button></li>`).join('<li class="arr" aria-hidden="true">→</li>')}</ol>`;
}

function banner(e) {
  if(e.shipping) return `<div class="mode scen"><b>${esc(pricingLabels[S.shipping.mode].toUpperCase())}</b> ${e.shipping.confirmed?'Panel values manually supplied by the seller. Confirmation is tied to the current weight, zone and fee context.':'Published observations give an estimated range, not an exact Meesho quote. Outcome rates and seller costs remain labelled scenario inputs.'}${S.mode==='real'?' Real seller evidence remains incomplete; approval is held.':''}</div>`;
  const real = S.mode === 'real';
  return `<div class="mode ${real ? 'real' : 'scen'}"><b>${real ? 'REAL RECORD' : 'PROTOTYPE SCENARIO'}</b> ${real
    ? 'Only observed evidence is used: the dated audit and the historical panel. Assumed costs and the generated register are switched off.'
    : 'Illustrative inputs only. Historical or manually entered price/payout pairs are assumed current for this demo; comparable offers are generated. This is not a live Meesho recommendation.'}
    <span class="status s-${e.status.split(' ')[0].toLowerCase()}">${esc(decisionLabel(e))}</span></div>`;
}

function changeBox() {
  if (!lastChange) return '';
  return `<section class="change" role="status"><h3>What just changed · ${esc(lastChange.title)}</h3><ul>${lastChange.lines.map(l => `<li>${l}</li>`).join('')}</ul></section>`;
}

function productView() {
  const p = S.product;
  const row = (f, v, s, note = '') => `<tr><th>${f}</th><td>${v}</td><td>${s}</td><td class="muted">${note}</td></tr>`;
  return `<h2>Confirm your product · ${esc(p.sku)} · version ${p.version}</h2><p class="lead">What exactly will be shipped. A photo match finds candidates; it does not prove equivalence.</p>
  <table class="grid"><thead><tr><th>Field</th><th>Value</th><th>Source</th><th>Note</th></tr></thead><tbody>
  ${row('Unit and specs', esc(p.title + ', ' + p.unit), src('panel'), 'Listing title in the historical panel')}
  ${row('Conductor', p.conductor ? esc(p.conductor) : '<b class="neg">Unresolved</b>', src('missing'), 'Copper vs copper-clad aluminium changes comparability')}
  ${row('Pack', esc(p.pack), src('panel'), '')}
  ${row('Packed weight', p.packedWeight + ' g', src(p.packedWeightSource === 'measured' ? 'calc' : 'assumed'), `Fee band used: up to ${p.weightBand} g. Crossing the band invalidates the quote and the return fee.`)}
  ${row('Fulfilment', esc(p.fulfilment), src('assumed'), 'Warehouse fees not in scope for v1')}
  ${row('Offline price', p.offlinePrice ? inr(p.offlinePrice) : '<b class="neg">Not recorded</b>', src('missing'), 'Gap: ask the seller')}
  ${row('Acquisition cost C', S.costs.private ? 'Private' : inr(S.costs.C), src('assumed'), 'Seller-private; ceiling shown if withheld')}
  ${row('Outside cost o', inr(S.costs.o) + ' per dispatch', src('assumed'), 'Packing and preparation, paid on every dispatch')}
  </tbody></table>
  <div class="row"><label class="field">Packed weight (g)<input type="number" id="in-weight" value="${p.packedWeight}" min="1"></label>
  <label class="field">Acquisition cost C (₹)<input type="number" id="in-C" value="${S.costs.private ? '' : S.costs.C ?? ''}" min="0" step="any" ${S.costs.private ? 'disabled' : ''}></label>
  <label class="field">Packing and preparation (₹ / dispatch)<input type="number" id="in-o" value="${S.costs.o ?? ''}" min="0" step="0.01"></label>
  <label class="check"><input type="checkbox" id="in-private" ${S.costs.private ? 'checked' : ''}> Keep my cost private (show ceilings only)</label></div><button data-action="inputs">Apply inputs and recalculate</button>`;
}

function alternativesView(e) {
  const real = S.mode === 'real';
  const list = (rows, editable) => `<table class="grid"><thead><tr><th>ID</th><th>Offer</th><th>Buyer price</th><th>Status</th><th>Reason</th>${editable ? '<th></th>' : ''}</tr></thead><tbody>${rows.map((x, i) =>
    `<tr class="${x.status}"><td>${x.id}</td><td>${esc(x.what || 'Register row')}</td><td>${inr(x.price)}</td><td>${x.status === 'accepted' ? '✓ qualified' : '✕ excluded'}</td><td>${esc(x.reason)}</td>${editable ? `<td>${x.status === 'accepted' ? `<button class="mini" data-fail="${i}">Fails re-check</button>` : ''}</td>` : ''}</tr>`).join('')}</tbody></table>`;
  const c = e.cmp;
  return `<h2>Comparable offers</h2><p class="lead">What this buyer can buy instead: same spec, in stock, independent seller, same buyer context, same date. Every exclusion is logged. <b>A comparable range is not willingness to pay.</b></p>
  <h3>Observed: public audit, 28 Sep 2026 ${src('audit')}</h3>${list(S.audit, false)}
  <p class="callout ${real ? 'bad' : ''}">Audit result: <b>0 qualified</b> of 5 asks. With no qualified match the real record can only support a justified HOLD, or a weak-evidence test the seller explicitly accepts.</p>
  ${real ? '' : `<h3>Prototype register M1–M6 ${src('generated')}</h3>${list(S.register, true)}`}
  <div class="kpis"><div><b>${c.n}</b><span>qualified (${real ? 'audit' : 'register'})</span></div><div><b>${c.n ? inr(c.min) + '–' + inr(c.max) : 'none'}</b><span>qualified range, not demand</span></div><div><b>${c.median !== null ? inr(c.median) : '–'}</b><span>median: reference only, no quote</span></div></div>
  ${real ? '' : `<label class="check"><input type="checkbox" id="in-weak" ${S.weakAck ? 'checked' : ''}> If nothing qualifies, I accept a capped weak-evidence test</label>`}`;
}

const moneyRange = values => values && values.every(Number.isFinite) ? values[0] === values[1] ? inr2(values[0]) : `${inr2(values[0])}–${inr2(values[1])}` : 'Not available';
const pricingLabels = {historical:'Historical example',online:'Online estimate',confirmed:'Confirmed panel quote'};
function shippingModes(){return `<div class="pricing-modes" role="group" aria-label="Payout calculation source">${Object.entries(pricingLabels).map(([id,label])=>`<button data-pricing="${id}" class="${S.shipping.mode===id?'selected':''}" aria-pressed="${S.shipping.mode===id}">${label}</button>`).join('')}</div>`;}
function shippingSources(){const sh=PCShipping;return `<details class="shipping-sources"><summary>Rate sources, dates and assumptions</summary><p>Indicative observations, not an official Meesho tariff. Rates are bundled for offline use; they do not refresh automatically.</p><p>${[sh.sources.ecomarray,sh.sources.shiprocket].map(x=>`<a href="${x.url}" target="_blank" rel="noopener">${esc(x.name)}</a> · published ${x.published} · retrieved ${x.retrieved}`).join('<br>')}</p><p><a href="${sh.sources.rto.url}" target="_blank" rel="noopener">Meesho shipping policy</a> · retrieved ${sh.sources.rto.retrieved}: no additional RTO shipping fee. This does not make failed orders cost-free.</p><p>Forward rates are treated as excluding 18% shipping GST by default. Return tax treatment is not specified by the rate table; both interpretations are shown until confirmed. The old ₹153 total-return-fee example is retained only in Historical example mode. Outcome rates, product cost and other deductions remain scenario assumptions.</p><p>Weight slabs use measured packed weight unless you supply a panel-assigned chargeable weight. No volumetric divisor, pincode tariff or payment-mode surcharge is invented. Handling/other deductions default to zero; enter any confirmed extra charges. Contribution is before seller product-tax and withholding reconciliation.</p><table class="grid"><thead><tr><th>Weight</th><th>Local</th><th>Regional</th><th>National</th></tr></thead><tbody>${sh.cards.map((x,i)=>`<tr><td>${i?sh.cards[i-1].max:0}–${x.max} g</td><td>${moneyRange(x.local)}</td><td>${moneyRange(x.regional)}</td><td>${moneyRange(x.national)}</td></tr>`).join('')}</tbody></table><table class="grid"><thead><tr><th>Return carrier</th>${sh.cards.map(x=>`<th>≤${x.max} g</th>`).join('')}</tr></thead><tbody>${Object.entries(sh.carriers).map(([key,fees])=>`<tr><td>${esc(sh.carrierNames[key])}</td>${fees.map(x=>`<td>${inr2(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></details>`;}
function shippingForm(){
 const c=S.shipping,q=c.confirmed||{},option=(value,label,selected)=>`<option value="${value}" ${value===selected?'selected':''}>${label}</option>`;
 return `<form id="shipping-form" class="shipping-form"><h3>${c.mode==='confirmed'?'Confirm your panel quote':'Estimate shipping and payout'}</h3><p>Keep the buyer total fixed. Choose the delivery zone yourself; this is not an exact pincode quote.</p><div class="row">
 <label class="field">Buyer total, fixed (₹)<input name="ship-buyer" type="number" min="0.01" step="0.01" required value="${c.buyer??''}"></label>
 <label class="field">Packed weight estimate (g)<input name="ship-weight" type="number" min="0.01" step="any" required value="${S.product.packedWeight??''}"></label>
 <label class="field">Panel chargeable weight (g, optional)<input name="ship-panel-weight" type="number" min="0.01" step="any" value="${c.panelWeight??''}"></label>
 <label class="field">Delivery zone<select name="ship-zone">${[['local','Local · intra-city'],['regional','Regional · intra-state'],['national','National · inter-state']].map(([v,l])=>option(v,l,c.zone)).join('')}</select></label>
 <label class="field">Forward shipping GST basis<select name="ship-tax">${option('exclusive','Fee excludes GST · add 18%',c.taxBasis)}${option('inclusive','Fee includes GST · split only',c.taxBasis)}</select></label>
 <label class="field">Other deductions (₹, total)<input name="ship-other" type="number" min="0" step="0.01" required value="${c.other??''}"></label>
 <label class="field">Rate source<select name="ship-source">${option('ecomarray','EcomArray · published observations',c.rateSource)}${option('shiprocket','Shiprocket · same observed forward bands',c.rateSource)}${option('manual','Manual ranges · scenario input',c.rateSource)}</select></label>
 <label class="field">Customer-return carrier<select name="ship-carrier">${Object.entries(PCShipping.carrierNames).map(([v,l])=>option(v,l,c.carrier)).join('')}</select></label>
 <label class="field">Return fee GST basis<select name="ship-return-tax">${option('unknown','Not confirmed · show both cases',c.returnTaxBasis)}${option('inclusive','Return fee already includes GST',c.returnTaxBasis)}${option('exclusive','Return fee excludes GST · add 18%',c.returnTaxBasis)}</select></label></div>
 <p class="muted">Packed weight includes packaging; enter a measured value. The optional panel weight means you have checked the assigned chargeable weight and it overrides the measured weight. A fee-source change needs quote revalidation.</p>
 <details id="manual-fees" ${c.rateSource==='manual'?'open':''}><summary>Manual fee ranges · needed above 2 kg</summary><p>Select “Manual ranges” as the rate source. Enter both ranges; they remain assumptions until a panel quote is confirmed.</p><div class="row">${[['ship-forward-min','Forward fee minimum (₹)',c.manualForward[0]],['ship-forward-max','Forward fee maximum (₹)',c.manualForward[1]],['ship-return-min','Return fee minimum (₹)',c.manualReturn[0]],['ship-return-max','Return fee maximum (₹)',c.manualReturn[1]]].map(([name,label,value])=>`<label class="field">${label}<input type="number" name="${name}" min="0" step="0.01" value="${value??''}"></label>`).join('')}</div></details>
 ${c.mode==='confirmed'?`<div class="panel-quote"><h3>Supplier-panel values</h3><p>Use the current payout for this buyer offer and shipping context. It already contains the platform deductions; no shipping is subtracted again.</p><div class="row"><label class="field">Panel seller entry (₹, optional)<input name="panel-entry" type="number" min="0" step="0.01" value="${q.entry??''}"></label><label class="field">Panel net payout (₹)<input name="panel-transfer" type="number" min="0" step="0.01" required value="${q.transfer??''}"></label><label class="field">Panel total return fee (₹, including tax)<input name="panel-return" type="number" min="0" step="0.01" required value="${q.returnGross??''}"></label><label class="field">Quote date<input name="panel-date" type="date" required value="${q.date||'2026-10-05'}"></label></div><label class="check"><input name="panel-confirm" type="checkbox" required> I checked this payout and total return fee in the supplier panel for the stated context.</label></div>`:''}
 <button class="primary" type="submit">${c.mode==='confirmed'?'Confirm panel quote':'Calculate shipping and payout'}</button><p id="shipping-feedback" role="status"></p></form>`;
}
function nextAction(e) {
  const offer=e.shipping?e.rows[0]:e.choice;
  if(S.mode==='real')return {title:'Confirm seller evidence',detail:'Confirm the product, current payout and your own costs before a test.',step:'product',label:'Review seller inputs'};
  if(e.shipping&&!e.shipping.ok)return {title:S.shipping.mode==='confirmed'?'Reconfirm panel payout':'Complete shipping inputs',detail:'The shipping context is incomplete or changed. Enter the missing values before using the payout or cash figures.',step:'quotes',label:'Review shipping inputs'};
  if(S.costs.private)return {title:'Check your private costs',detail:'Assess the estimate using your own costs. Profit and funding stay unconfirmed while costs are private.',step:'product',label:'Review product inputs'};
  if(!S.quoteValid&&!e.shipping)return {title:'Confirm panel payout',detail:'Product or packed weight changed. Replace the stale price/payout quote and return fee before approval.',step:'quotes',label:'Review price and payout'};
  if(e.errors.some(x=>/return.*fee|reverse.*fee/i.test(x)))return {title:'Confirm return charges',detail:'Confirm the return charge for this weight band before checking earnings and funding.',step:'quotes',label:'Review price and payout'};
  if(e.errors.some(x=>/outcome|mix|share|percent|sum|100/i.test(x)))return {title:'Review order outcomes',detail:'Complete the outcome inputs and ensure the shares total 100%.',step:'economics',label:'Review outcome inputs'};
  if(e.errors.length)return {title:'Confirm missing inputs',detail:'Resolve the missing seller costs or outcome inputs shown below before approval.',step:'product',label:'Review product costs'};
  if(e.status==='Repair economics'||(offer&&offer.econ&&offer.econ.expected<=0&&!e.shipping))return {title:'Review product costs',detail:'The earnings check fails. Check acquisition, packing and return costs; a smaller batch limits exposure but does not fix losing units.',step:'product',label:'Review product costs'};
  if(e.proc.blocked)return {title:'Review batch funding',detail:'Reduce the batch where the supplier MOQ allows, renegotiate MOQ or confirm more available cash. Review the cash requirement before buying.',step:'constraints',label:'Review cash and batch size'};
  if(e.shipping&&!e.shipping.confirmed)return {title:'Confirm panel payout',detail:e.status==='Review shipping uncertainty'?'Only part of the range passes. Confirm the actual payout and return fee, then review earnings again.':'The estimate passes the earnings check. Confirm the actual payout and return fee before approval.',action:'confirm-shipping',label:'Confirm panel payout'};
  if(!S.quoteValid&&!e.shipping)return {title:'Confirm panel payout',detail:'Product or packed weight changed. Replace the stale price/payout quote before approval.',step:'quotes',label:'Review price and payout'};
  if(e.cmp.n===0)return {title:'Review comparable offers',detail:'Add qualified offers for the same product and selling context before relying on this price.',step:'alternatives',label:'Review comparable offers'};
  if(!['READY FOR YOUR APPROVAL','WEAK-EVIDENCE TEST'].includes(e.status))return {title:'Review downside earnings',detail:'Review the failed earnings checks and another candidate before committing.',step:'economics',label:'Review earnings checks'};
  return {title:'Review and approve your test',detail:'Check the evidence and batch limit below. Approval only saves your decision in this prototype.',step:'constraints',label:'Review cash and stock'};
}
function decisionLabel(e){return ['HOLD','PRICE PASSES · PROCUREMENT HOLD','ASSISTED REVIEW REQUIRED'].includes(e.status)?nextAction(e).title:e.status;}
function nextActionCard(e){const a=nextAction(e);return `<section class="next-action"><p class="eyebrow">NEXT ACTION</p><h3>${esc(a.title)}</h3><p>${esc(a.detail)}</p><button class="primary" ${a.action?`data-action="${a.action}"`:`data-step="${a.step}"`}>${esc(a.label)}</button></section>`;}
function evidenceSummary(e){
 const c=e.shipping,measured=S.product.packedWeightSource==='measured',real=S.mode==='real';
 const values=[['Weight',c&&S.shipping.panelWeight!==null?'Seller-supplied panel weight':measured?'Seller-entered measured weight':'Scenario weight · measure your parcel'],['Payout',c?(c.confirmed?'Seller-confirmed panel value':S.shipping.rateSource==='manual'?'Manual scenario estimate':'Published estimate · confirm panel'):'Historical example · not a current quote'],['Product costs',S.costs.private?'Private · profit unconfirmed':real?'Seller costs missing':`${inr(S.costs.C)} acquisition + ${inr(S.costs.o)} packing · scenario inputs`],['Order outcomes',real?'Seller outcomes missing':S.mix.source==='blended'?'Scenario + sample cohort · calculated':`${pct(S.mix.k)} kept / ${pct(S.mix.r)} RTO / ${pct(S.mix.q)} return · assumptions`]];
 return `<section class="evidence-summary" aria-label="Evidence behind this result"><h3>What supports this result?</h3><div class="evidence-grid">${values.map(([label,value])=>`<div><b>${label}</b><span>${esc(value)}</span></div>`).join('')}</div><p class="muted">${c&&!c.confirmed?'Public shipping rates are indicative observations. ':''}${real?'Complete the real seller record before approving.':'Entering a measured weight or confirming a payout does not confirm the scenario costs, comparable offers or order outcomes.'}</p></section>`;
}
function payoutExplanation(c){if(!c.ok)return '';return `<section class="payout-explanation"><h3>Why this payout?</h3><p>${c.confirmed?`The supplier-panel net payout is <b>${moneyRange(c.payout)}</b>. Use it directly; shipping is already accounted for. The reference fees below are not deducted again.`:`For <b>${c.weight} g · ${esc(c.slab)} · ${esc(S.shipping.zone)} delivery</b>, ${S.shipping.rateSource==='manual'?'your manual inputs':'the published observations'} give the fee range below. The highest total charge gives the lowest payout.`}</p>${!c.confirmed?`<p>Forward fee: <b>${moneyRange(c.forward.base)}</b> · GST: <b>${moneyRange(c.forward.gst)}</b> · other deductions: <b>${inr2(c.other)}</b>.</p><p class="formula">${inr2(c.buyer)} buyer total − ${moneyRange(c.forward.gross)} shipping including GST − ${inr2(c.other)} other deductions = <b>${moneyRange(c.payout)} payout</b></p><p class="muted">${S.shipping.taxBasis==='inclusive'?'GST is split from the fee; it is not added again.':'Shipping total includes the forward fee plus rounded 18% GST.'}</p>`:''}</section>`;}

function shippingBreakdown(calc){
 if(!calc.ok)return `<div class="callout bad"><b>Complete the shipping inputs</b><ul>${calc.errors.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`;
 const line=(label,value,note='')=>`<tr><th>${label}</th><td>${value}</td><td>${note}</td></tr>`;
 return `<section class="shipping-result"><div class="shipping-result-head"><div><p class="eyebrow">${calc.confirmed?'SELLER-CONFIRMED PANEL PAYOUT':'ONLINE ESTIMATE · NOT A LIVE QUOTE'}</p><h3>${calc.confirmed?'Net payout supplied by you':'Estimated net payout'}: ${moneyRange(calc.payout)}</h3></div><span class="tag asm">Buyer total stays ${inr2(calc.buyer)}</span></div><p>${esc(calc.weightBasis)} · ${calc.weight} g · ${esc(calc.slab)} · ${esc(S.shipping.zone)} delivery</p>
 ${payoutExplanation(calc)}
 <table class="grid"><thead><tr><th>Component</th><th>Amount</th><th>Basis</th></tr></thead><tbody>
 ${line('Buyer total',inr2(calc.buyer),'Fixed customer-facing amount')}
 ${line('Forward fee before GST',calc.forward?moneyRange(calc.forward.base):'Not available',calc.confirmed?'Online reference only; not deducted again':'Sourced fee range')}
 ${line('Shipping GST · 18%',calc.forward?moneyRange(calc.forward.gst):'Not available',S.shipping.taxBasis==='inclusive'?'Split from the listed inclusive fee':'Added to exclusive forward fee')}
 ${line('Total forward shipping',calc.forward?moneyRange(calc.forward.gross):'Not available',calc.confirmed?'Informational estimate only':'Forward fee + its GST, counted once')}
 ${line('Other deductions',inr2(calc.other),calc.confirmed?'Included in supplied net payout':'Zero is a scenario assumption until confirmed')}
 ${line(calc.confirmed?'Panel net payout':'Estimated payout',`<b>${moneyRange(calc.payout)}</b>`,calc.confirmed?'Used directly; no further logistics deduction':'Buyer total − total forward fee − other deductions')}
 ${line('Customer-return total fee',moneyRange(calc.returns.gross),calc.confirmed?'Total fee supplied by seller, including tax':S.shipping.returnTaxBasis==='unknown'?'Includes both possible tax interpretations':'Selected return-fee tax basis')}
 ${line('Additional RTO shipping fee',inr2(calc.rtoFee),'Meesho official policy; preparation still costs money')}
 </tbody></table>
 ${!calc.confirmed&&calc.returns.alternatives.length?`<details ${S.shipping.returnTaxBasis==='unknown'?'open':''}><summary>Return-fee tax alternatives</summary><table class="grid"><thead><tr><th>Interpretation</th><th>Before GST</th><th>GST</th><th>Total return fee</th></tr></thead><tbody>${calc.returns.alternatives.map(x=>`<tr><td>${x.basis==='inclusive'?'Published fee includes GST':'Published fee excludes GST'}</td><td>${moneyRange(x.base)}</td><td>${moneyRange(x.gst)}</td><td>${moneyRange(x.gross)}</td></tr>`).join('')}</tbody></table><p class="muted">${S.shipping.rateSource==='manual'?'Manual return rates are scenario inputs.':'Unknown carrier spans the listed carriers; the published return table does not specify GST treatment.'} Neither tax alternative is claimed as confirmed.</p></details>`:''}
 <p class="muted">${esc(calc.source.name)}${calc.source.published?` · published ${calc.source.published}`:''}${calc.source.retrieved?` · retrieved ${calc.source.retrieved}`:''}. No seller-entry price is inferred.</p></section>`;
}
function shippingEconomics(e){
 const r=e.rows[0],range=r.econRange;
 return `<h2>Earnings after shipping and returns</h2><p class="lead">Kept ${pct(S.mix.k)} · RTO ${pct(S.mix.r)} · return ${pct(S.mix.q)}. These outcome rates remain labelled assumptions; shipping rates do not predict returns.</p>${range?`<div class="kpis"><div><b>${moneyRange(range.expected)}</b><span>expected contribution per dispatch</span></div><div><b>${moneyRange(range.kept)}</b><span>contribution on a kept order</span></div><div><b>${moneyRange(range.ret)}</b><span>contribution on a customer return</span></div></div><p class="callout">Downside uses the lowest payout and highest return fee. Upside uses the highest payout and lowest return fee. Minimum ${inr(S.seller.g)} applies per ${S.seller.denominator==='kept'?'kept order':'dispatch'}.</p>`:'<p class="callout bad">Confirm the missing inputs. Private or unconfirmed seller costs do not produce a profit figure.</p>'}
 <p class="decision-status warning">${esc(decisionLabel(e))}</p>${e.reasons.length?`<ul class="reasons">${e.reasons.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}
 <div class="row">${[['k','Kept %'],['r','RTO %'],['q','Return %']].map(([key,label])=>`<label class="field">${label}<input type="number" data-mix="${key}" value="${M.r2(S.mix[key])}" min="0" step="any"></label>`).join('')}<label class="field">Damaged share of returns (%)<input id="in-d" type="number" min="0" max="100" value="${S.fees.delta}"></label></div><button data-action="inputs">Apply inputs and recalculate</button><button data-step="quotes">Review shipping breakdown</button><details><summary>View calculation and evidence</summary><p class="formula">Expected = kept share × (net payout − acquisition cost) − preparation − return share × total return fee − return share × damaged share × acquisition cost. Additional RTO shipping = ₹0.</p>${shippingSources()}</details>`;
}
function shippingDecision(e){const c=e.shipping,r=e.rows[0],range=r.econRange,p=e.proc,canApprove=c.confirmed&&['READY FOR YOUR APPROVAL','WEAK-EVIDENCE TEST'].includes(e.status);return `<p class="eyebrow">${c.confirmed?'CONFIRMED PANEL QUOTE · SELLER SUPPLIED':'ONLINE ESTIMATE · PREPARE YOUR TEST'}</p><h2>${esc(decisionLabel(e))}</h2><p class="lead">Buyer total is fixed at ${inr2(c.buyer)}. ${c.confirmed?'Use the net payout you confirmed in the panel.':'Confirm your actual charges before approving a test.'}</p><div class="card ${canApprove?'ok':'warn'}"><div class="dgrid summary-grid"><div class="dc"><span>${c.confirmed?'Panel net payout':'Estimated net payout'}</span><b>${moneyRange(c.payout)}</b><small>shipping and GST already accounted for</small></div><div class="dc"><span>Expected contribution / dispatch</span><b>${range?moneyRange(range.expected):'Unconfirmed'}</b><small>downside through upside · scenario outcome rates</small></div><div class="dc"><span>Cash to keep available</span><b>${p.known?inr2(p.need):'Unconfirmed'}</b><small>${p.known?`includes ${inr2(p.reserveHeld)} held reserve using the highest return fee`:'Confirm private costs and charges'}</small></div><div class="dc"><span>Batch exposure limit</span><b>${p.known&&!p.blocked?p.units+' units':'Review funding'}</b><small>limit, not a demand forecast</small></div></div>${nextActionCard(e)}${evidenceSummary(e)}${e.reasons.length?`<ul class="reasons">${e.reasons.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}<div class="actions"><button data-action="confirm-shipping" class="primary">${c.confirmed?'Review panel quote':'Confirm charges in the panel'}</button><button data-action="save-estimate" ${c.ok?'':'disabled'}>Save ${c.confirmed?'quote review':'estimated plan'}</button><button data-action="approve" ${canApprove?'':'disabled'}>Approve test</button><button data-action="hold">Save for later</button></div><p class="muted">Public rates cannot create a confirmed approval. A supplied panel quote still needs earnings, comparable support and affordable cash.</p></div>${noteMsg?`<p class="callout" role="status">${noteMsg}</p>`:''}${goalControls()}<details><summary>View shipping breakdown</summary>${shippingBreakdown(c)}</details>${shippingSavedDecisions()}`;}
function shippingSavedDecisions(){return `<details ${S.snapshots.length?'open':''}><summary>Saved decisions (${S.snapshots.length})</summary>${S.snapshots.length?`<table class="grid"><thead><tr><th>Action</th><th>Source</th><th>Saved expected range</th><th>State now</th></tr></thead><tbody>${S.snapshots.map(x=>`<tr><td>${esc(x.action)}</td><td>${x.shipping?esc(x.shipping.source.name):'Historical scenario'}</td><td>${x.expectedRange?moneyRange(x.expectedRange):x.choice?inr2(x.choice.expected):'–'}</td><td>${esc(x.state)}${x.why?': '+esc(x.why):''}</td></tr>`).join('')}</tbody></table>`:'<p>No saved decision yet.</p>'}</details>`;}

function quotesView(e) {
  const editable = S.mode === 'scenario';
  if(S.shipping.mode!=='historical') return `<h2>Estimate your shipping and payout</h2><p class="lead">Start with your buyer total and parcel details. The example values below help you explore; replace them with your own inputs.</p>${shippingModes()}${shippingForm()}${shippingBreakdown(e.shipping)}${evidenceSummary(e)}${shippingSources()}`;
  return `<h2>Price and payout</h2>${shippingModes()}<p class="lead">Historical example · Keep three prices separate: what you enter, what the buyer pays, and what you receive on a kept order. Never infer a payout for a new price.</p>
  <table class="grid"><thead><tr><th>Candidate</th><th>Seller enters</th><th>Buyer pays</th><th>Transfer on kept order</th><th>Source</th><th>Quote state</th></tr></thead><tbody>${e.rows.map(r =>
    `<tr><td>${esc(r.label)}</td><td>${inr(r.entry)}${r.entryEstimate != null ? ` <small>(estimate ${inr(r.entryEstimate)})</small>` : ''}</td><td>${inr(r.buyer)}</td><td>${inr(r.transfer)}</td><td>${r.source === 'manual' ? 'Manually entered · demo assumption' : 'Historical panel · entry estimated'}</td><td>${!editable ? 'Not current' : S.quoteValid ? `Assumed current · v${S.versions.quotes}` : 'Invalid · fresh quote needed'}</td></tr>`).join('')}</tbody></table>
  ${editable ? `<button class="primary" data-action="edit">${quoteEditor ? 'Close quote editor' : 'Add a different price quote'}</button>` : '<p class="callout bad">The real record has no current quote. The editor is available in prototype scenario mode only; entered values cannot repair missing real evidence.</p>'}
  ${quoteEditor && editable ? `<form id="quote-form" class="quote-editor"><h3>Add a candidate quote</h3><p>Enter the complete pair from a quote. This offline prototype records your input as a demo assumption.</p><div class="row">
  <label class="field">Seller entry (₹)<input name="entry" type="number" min="0.01" step="0.01" required></label>
  <label class="field">Buyer pays (₹)<input name="buyer" type="number" min="0.01" step="0.01" required></label>
  <label class="field">Kept-order transfer (₹)<input name="transfer" type="number" min="0" step="0.01" required></label></div>
  <label class="check"><input name="confirmed" type="checkbox" required> I have entered all three values; the transfer is not inferred.</label>
  <button class="primary" type="submit">Save candidate and recalculate</button><p id="quote-feedback" role="status">${esc(quoteMessage)}</p></form>` : ''}
  ${editable && !S.quoteValid ? `<p class="callout bad">A product or weight change needs a new quote and the correct return fee. Adding a quote does not fill an unknown fee.</p><button data-action="requote">Re-capture existing pairs (demo assumption)</button>` : ''}
  <details><summary>View calculation and evidence</summary><p class="formula">Historical pairs: S = (B − T) ÷ 1.18 = ₹78.81 at ₹189, ₹79.66 at ₹210 · entry = T + 0.18S = ₹110.19 / ₹130.34. Entries are estimates, not executable quotes.</p><p>The historical panel already suggested ₹189. PriceCompass adds earnings after returns, a cash cap and a hold when evidence is missing.</p></details>`;
}

function economicsView(e) {
  if(e.shipping) return shippingEconomics(e);
  const k = S.mix;
  const rows = e.rows.map(r => r.econ ? `<tr><td>${inr(r.buyer)} → ${inr(r.transfer)}</td><td>${inr(r.econ.kept)}</td><td>${inr(r.econ.rto)}</td><td>${inr(r.econ.ret)}</td><td><b>${inr(r.econ.expected)}</b></td><td>C ≤ ${inr(r.ceiling ? r.ceiling.minimum : null)}</td><td>${r.passes ? '✓' : '✕'}${S.mode === 'scenario' && e.cmp.n && !r.supported ? ' · unsupported' : ''}</td></tr>`
    : `<tr><td>${inr(r.buyer)} → ${inr(r.transfer)}</td><td colspan="4" class="muted">Unconfirmed or private inputs: no profit figure</td><td>C ≤ ${r.ceiling ? inr(r.ceiling ? r.ceiling.minimum : null) : '–'}</td><td>–</td></tr>`).join('');
  const st = e.stress ? `<h3>Labelled stress cases · expected ₹ per dispatch ${src('calc')}</h3><table class="grid"><thead><tr><th>Demo what-if (not a confidence interval)</th>${S.quotes.map(q => `<th>${inr(q.buyer)}</th>`).join('')}</tr></thead><tbody>${e.stress.map(x => `<tr><td>${esc(x.label)}<br><small>${esc(x.scope)}</small></td>${x.values.map(v => `<td class="${v < 0 ? 'neg' : ''}">${inr(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>` : '';
  return `<h2>Earnings after returns</h2><p class="lead">Kept ${pct(k.k)} · RTO ${pct(k.r)} · return ${pct(k.q)} ${src(k.source === 'blended' ? 'calc' : 'assumed')} · reverse fee ${inr(S.fees.R)} ${src('panelFee')} · no RTO fee · damaged share of returns ${pct(S.fees.delta)}</p>
  <table class="grid"><thead><tr><th>Candidate</th><th>Kept</th><th>Intact RTO</th><th>Return</th><th>Expected m</th><th>Cost ceiling</th><th>Passes</th></tr></thead><tbody>${rows}</tbody></table>
  <details><summary>View calculation and evidence</summary><p class="formula">m = k(T − C) − o − qR − qδC · ceiling C ≤ (kT − o − qR − g) ÷ (k + qδ) · minimum g = ${inr(S.seller.g)} per ${S.seller.denominator === 'kept' ? 'kept order' : 'expected dispatch'}</p></details>
  <div class="row">${[['k', 'Kept %'], ['r', 'RTO %'], ['q', 'Return %']].map(([key, l]) => `<label class="field">${l}<input type="number" data-mix="${key}" value="${M.r2(S.mix[key])}" step="any" min="0"></label>`).join('')}
  <label class="field">Reverse fee R (₹)<input type="number" id="in-R" value="${S.fees.R ?? ''}" min="0"></label><label class="field">Damaged share of returns (%)<input type="number" id="in-d" value="${S.fees.delta}" min="0" max="100"></label></div>
  <button data-action="inputs">Apply inputs and recalculate</button>${st}${e.choice && e.alternative ? `<p class="callout">Demand threshold: ${inr(e.choice.buyer)} needs more than <b>${(e.alternative.econ.expected / e.choice.econ.expected).toFixed(5)}×</b> the mature dispatches of ${inr(e.alternative.buyer)}; ${inr(e.alternative.buyer)} wins while its volume stays above <b>${(e.choice.econ.expected / e.alternative.econ.expected * 100).toFixed(3)}%</b> of ${inr(e.choice.buyer)}'s. Same mix at both prices is an assumption, not learned demand.</p>` : ''}`;
}

function constraintsView(e) {
  const p = e.proc, s = S.seller;
  const body = p.known ? `<div class="kpis"><div><b>${inr(p.funding.perNew)}</b><span>funding per new unit = ${inr(S.costs.C)} purchase + ${inr(S.costs.o)} outside + ${inr(p.funding.reserve)} reserve</span></div>
    <div><b>${p.units} units</b><span>seller cap ${s.cap}: a limit on exposure, not a sales forecast (${p.affordableMax} would fit the cash)</span></div>
    <div><b>${inr(p.need)}</b><span>cash to keep available; ${inr(p.reserveHeld)} of it is reserve held, not an expense</span></div></div>
    <p class="callout ${p.blocked ? 'bad' : ''}">${esc(p.reason)}${p.fallback ? ` Option: shrink to ${p.fallback.units} units (${inr(p.fallback.need)}).` : p.blocked ? ' No smaller batch satisfies the MOQ: renegotiate MOQ, add cash, or hold.' : ''}</p>`
    : `<p class="callout bad">${esc(p.reason)}</p>`;
  return `<h2>Cash, inventory, MOQ and exposure cap</h2><p class="lead">A price can pass while procurement fails. Reserve = ${s.reservePct}% × ${e.shipping?'highest total return fee, rounded up':'reverse fee, rounded down'}: a stress policy held as cash, never booked as a cost.</p>${body}
  <div class="row"><label class="field">Available cash (₹)<input type="number" id="in-cash" value="${s.cash ?? ''}" min="0"></label><label class="field">Owned units<input type="number" id="in-owned" value="${s.owned}" min="0" step="1"></label>
  <label class="field">Seller cap (units)<input type="number" id="in-cap" value="${s.cap}" min="1" step="1"></label><label class="field">Supplier MOQ<input type="number" id="in-moq" value="${s.moq}" min="0" step="1"></label></div>
  <button data-action="inputs">Apply inputs and recalculate</button><p class="muted">Sources: ₹1,000 cash, cap 9 and MOQ 1 are worked-example assumptions ${src('assumed')}. Supplier MOQ is an evidence gap.</p>`;
}

function goalControls() {
  return `<section class="goal-controls"><h3>Your goal for this batch</h3><div class="row">
  <label class="field">What matters most?<select id="in-objective"><option value="competitive" ${S.seller.objective === 'competitive' ? 'selected' : ''}>Competitive starting offer</option><option value="earnings" ${S.seller.objective === 'earnings' ? 'selected' : ''}>Earnings per order</option></select></label>
  <label class="field">Minimum earnings (₹)<input type="number" id="in-minimum" min="0" step="0.01" value="${S.seller.g ?? ''}"></label>
  <label class="field">Minimum applies to<select id="in-denominator"><option value="dispatch" ${S.seller.denominator === 'dispatch' ? 'selected' : ''}>Each dispatch, after returns</option><option value="kept" ${S.seller.denominator === 'kept' ? 'selected' : ''}>Each kept order</option></select></label></div>
  <button data-action="goal">Update goal and recalculate</button><p class="muted">Dispatch means every shipped order, including returns and failed deliveries. A kept-order minimum still requires positive expected contribution after returns.</p></section>`;
}

function decisionView(e) {
  if(e.shipping) return shippingDecision(e);
  const c = e.choice, a = e.alternative, p = e.proc;
  const sens = e.sensitive ? e.sensitive[0] : null;
  const cell = (l, v, sub = '') => `<div class="dc"><span>${l}</span><b>${v}</b>${sub ? `<small>${sub}</small>` : ''}</div>`;
  const canApprove = ['READY FOR YOUR APPROVAL', 'WEAK-EVIDENCE TEST'].includes(e.status);
  const cashFits = p.known && !p.blocked;
  const title = !canApprove ? nextAction(e).title : `Scenario: test the ${inr(c.buyer)} buyer offer${cashFits ? ` with up to ${p.units} units` : ''}.`;
  return `<div class="decision-heading"><p class="eyebrow">YOUR DECISION · ${esc(S.product.sku)} · SCENARIO INPUTS ${S.mode === 'real' ? 'OFF' : 'ON'}</p><h2>${title}</h2><span class="decision-status ${canApprove ? 'good' : 'warning'}">${esc(decisionLabel(e))}</span></div>
  ${nextActionCard(e)}${evidenceSummary(e)}<div class="card ${canApprove ? 'ok' : e.status === 'HOLD' ? 'hold' : 'warn'}">
  ${c ? `<div class="dgrid summary-grid">
  ${cell('Buyer offer', inr(c.buyer), 'what the buyer pays')}
  ${cell('Expected contribution', inr2(c.econ.expected) + ' / dispatch', 'base case · before seller tax reconciliation')}
  ${cell('Cash to keep available', p.known ? inr(p.need) : 'Unverified', p.known ? `includes ${inr(p.reserveHeld)} reserve, held rather than spent` : '')}
  ${cell('First batch limit', cashFits ? p.units + ' units' : 'Buying blocked', 'exposure limit, not a sales forecast')}</div>
  <p class="recommendation">${S.seller.objective === 'earnings' ? 'This candidate leaves the most per dispatch among the supported base-case passes.' : 'This is the lowest supported candidate that passes the base earnings check.'} ${canApprove ? 'The demo downside checks also pass.' : 'The remaining checks must be resolved before approval.'} Buyer response determines total earnings; this is a starting test.</p>
  <div class="quote-line"><span>Seller enters <b>${inr(c.entry)}</b> ${c.entryEstimate != null ? '(estimate)' : '(manual input)'}</span><span>→ buyer pays <b>${inr(c.buyer)}</b></span><span>→ kept-order transfer <b>${inr(c.transfer)}</b></span></div>
  ${a ? `<p class="alternative">Alternative: <b>${inr(a.buyer)} → ${inr(a.econ.expected)} / dispatch</b>. ${a.econ.expected > c.econ.expected ? 'It earns more per dispatch; demand decides whether it earns more overall.' : 'It is a lower buyer offer with less contribution per dispatch.'}</p>` : ''}
  <p class="review-trigger"><b>Review trigger:</b> ${S.seller.cap} closed dispatches or day 30. Earlier if fees, damage, cost or comparable offers change.</p>
  ${e.downsideFailures.length ? `<div class="callout bad"><b>Base case passes; downside does not.</b><ul>${e.downsideFailures.map(x => `<li>${esc(x.label)}: ${inr(x.values[S.quotes.findIndex(q => q.id === c.id)])} / dispatch; fails the selected minimum or positive-contribution check.</li>`).join('')}</ul>Review another candidate or repair the economics. A smaller batch limits exposure but does not fix a losing unit.</div>` : ''}` : '<p>No eligible candidate. Resolve the missing inputs or failed checks below.</p>'}
  ${e.reasons.length ? `<ul class="reasons">${e.reasons.map(r => `<li>${esc(r)}</li>`).join('')}</ul>` : ''}
  <div class="actions"><button class="primary" data-action="approve" ${canApprove ? '' : 'disabled'}>Approve test</button><button data-action="alt" ${a ? '' : 'disabled'}>Switch to alternative</button><button data-action="edit">Edit price</button><button data-action="hold">Save for later</button></div>
  <p class="muted">Approval saves an in-memory decision only. No listing edit or purchase. Refresh clears the session.</p></div>
  ${noteMsg ? `<p class="callout" role="status">${noteMsg}</p>` : ''}
  ${goalControls()}
  <details><summary>View calculation and evidence</summary>
  ${c ? `<p>Most sensitive assumption: <b>${sens ? esc(sens.name) : '–'}</b> · ${sens ? esc(sens.text) : ''}. Review changes before committing.</p><table class="grid"><thead><tr><th>Check</th><th>Expected / dispatch</th><th>Scope</th></tr></thead><tbody>${e.stress.map(x => `<tr><td>${esc(x.label)}</td><td class="${x.values[S.quotes.findIndex(q => q.id === c.id)] < 0 ? 'neg' : ''}">${inr(x.values[S.quotes.findIndex(q => q.id === c.id)])}</td><td>${esc(x.scope)}</td></tr>`).join('')}</tbody></table><p>Downside checks are labelled demo assumptions, not a calibrated probability range. The exploratory acquisition-cost change is a separate future scenario; entering that cost recalculates the whole decision.</p>` : ''}
  <p>Product and quotes: historical panel. Comparable register: generated. Cash, costs and outcome mix: assumptions. <button data-step="product">Inspect inputs</button></p></details>
  <details ${S.snapshots.length ? 'open' : ''}><summary>Saved decisions (${S.snapshots.length})</summary>${S.snapshots.length ? `<table class="grid"><thead><tr><th>#</th><th>Action</th><th>Saved at</th><th>Status then</th><th>Choice</th><th>State now</th></tr></thead><tbody>${S.snapshots.map(x => `<tr><td>${x.id}</td><td>${esc(x.action)}</td><td>${esc(new Date(x.time).toLocaleString('en-IN', {timeZone:'Asia/Kolkata'}))} IST</td><td>${esc(x.status)}</td><td>${x.choice ? inr(x.choice.buyer) + ' · ' + inr(x.choice.expected) : '–'}</td><td>${esc(x.state)}${x.why ? ': ' + esc(x.why) : ''}</td></tr>`).join('')}</tbody></table>` : '<p>No saved decision yet.</p>'}</details>`;
}

function reviewView() {
  if(S.shipping.mode!=='historical') return `<h2>Review settled orders</h2><p class="callout">The sample cohort belongs to the historical ₹189 / ₹96 launch. It is kept separate from new shipping estimates and panel quotes so a new rate cannot rewrite old orders.</p><button data-action="historical-review">Open the historical cohort review</button>`;
  if (S.mode === 'real' || S.costs.private || ev().errors.length || !S.quoteValid || !S.quotes.some(q => q.buyer === 189)) return `<h2>Review settled orders</h2><p class="callout bad">${S.mode === 'real' ? 'No real dispatch record has been attached. Switch to prototype scenario to explore the labelled sample cohort.' : 'Confirm costs, valid quotes and the missing inputs before calculating the next decision. This sample cohort also needs its original ₹189 quote. Private cost mode shows ceilings only.'}</p><button data-step="product">Review inputs</button>`;
  const L = M.ledger(P.COHORT, HISTORICAL_INPUTS);
  const alreadyApplied = S.reviewedCohorts.includes(COHORT_ID);
  const u = review || M.update(S, L, K);
  const beforeEv = M.evaluate(review && review.beforeState ? review.beforeState : S);
  const e2 = M.evaluate(u.next), liveNext = alreadyApplied ? S : u.next, d = M.nextDecision(liveNext, L, M.evaluate(liveNext));
  const st = { kept: 'Kept', rto: 'RTO (refused)', return: 'Customer return', pending: 'Pending' };
  const b = u.before, a = u.after;
  const row = (l, x, y, f) => `<tr class="${M.r2(x) !== M.r2(y) ? 'chg' : ''}"><td>${l}</td><td>${f(x)}</td><td>${f(y)}</td></tr>`;
  return `<h2>Review and learn · sample launch · version 1 at ${inr(189)}</h2><p class="lead">${src('synthetic')} Nine labelled test dispatches to exercise the loop. They are not observed Meesho orders. Sample launch costs are fixed at ₹55 acquisition and ₹5 preparation; editing future costs never rewrites the ledger.</p>
  <table class="grid"><thead><tr><th>Dispatch</th><th>Outcome</th><th>Settlement</th><th>Reverse charge</th><th>Stock</th><th>Contribution</th><th>Cash</th></tr></thead><tbody>${L.rows.map(x => `<tr><td>${x.id}</td><td>${st[x.status]}</td><td>${x.settled === null ? 'not settled' : inr(x.settled)}</td><td>${x.reverse === null ? '–' : inr(x.reverse)}</td><td>${esc(x.stock)}</td><td>${x.contribution === null ? 'open' : inr(x.contribution)}</td><td>${inr(x.cash)}</td></tr>`).join('')}</tbody></table>
  <div class="kpis"><div><b>${inr(L.contribution)}</b><span>closed contribution (${L.closed} closed)</span></div><div><b>${inr(L.cash)}</b><span>net cash so far (bank ${inr(S.seller.cash)} → ${inr(S.seller.cash + L.cash)})</span></div><div><b>${L.intactUnits} units · ${inr(L.inventoryValue)}</b><span>recoverable stock at cost, not cash</span></div><div><b>${L.pending}</b><span>pending: not a sale, not a loss</span></div></div>
  <p class="formula">Closed cash ${inr(L.contribution - L.inventoryValue)} + recovered stock ${inr(L.inventoryValue)} = contribution ${inr(L.contribution)}. Settlements ${inr(L.settlements)}; reverse charges ${inr(L.reverseCharges)} (counted once, on the return only).</p>
  <h3>Inputs before → after</h3><label class="field inline">Prior weight K (pseudo-dispatches) <input type="number" id="in-K" value="${K}" min="1" step="1" ${alreadyApplied ? 'disabled' : ''}> <span class="tag miss">uncalibrated</span></label>
  <table class="grid narrow"><thead><tr><th>Input</th><th>Before</th><th>After</th></tr></thead><tbody>${row('Kept %', b.k, a.k, pct)}${row('RTO %', b.r, a.r, pct)}${row('Return %', b.q, a.q, pct)}${row('Reverse fee R', b.R, a.R, inr)}${row('Damaged share of returns', b.delta, a.delta, pct)}${row('Reserve per unit', b.reserve, a.reserve, inr)}</tbody></table>
  <p class="formula">Blend: (K × prior + closed count) ÷ (K + ${L.closed}). With K = ${K}: kept (${K} × ${b.k}% + ${L.kept}) ÷ ${K + L.closed} = ${pct(a.k)}. R takes the charge actually debited. K is not fitted to any data.</p>
  <h3>Recalculated economics</h3><table class="grid narrow"><thead><tr><th>Candidate</th><th>Before</th><th>After</th><th>Cost ceiling after</th></tr></thead><tbody>${e2.rows.map((r, i) => `<tr><td>${inr(r.buyer)}</td><td>${inr2(beforeEv.rows[i].econ ? beforeEv.rows[i].econ.expected : null)}</td><td><b>${inr2(r.econ ? r.econ.expected : null)}</b></td><td>C ≤ ${inr(r.ceiling ? r.ceiling.minimum : null)}</td></tr>`).join('')}</tbody></table>
  <div class="card ok"><div class="cardhead"><b>Next decision</b><span>seller approves or holds</span></div><p>${esc(d.price)}</p><p>${esc(d.stock)}</p></div>
  <button class="primary" data-action="apply" ${alreadyApplied ? 'disabled' : ''}>${alreadyApplied ? 'Cohort already applied — waiting for new outcomes' : `Apply the update as version ${S.versions.outcomes + 1} inputs`}</button><p class="muted">Each cohort is processed once. Reset everything starts a fresh demo.</p>`;
}

function render() {
  const e = ev();
  $('strip').innerHTML = strip(e);
  $('banner').innerHTML = banner(e);
  $('change').innerHTML = changeBox();
  const view = { product: productView, alternatives: alternativesView, quotes: quotesView, economics: economicsView, constraints: constraintsView, decision: decisionView, review: reviewView }[step];
  $('main').innerHTML = view(e);
  document.querySelectorAll('main table').forEach(table => { const wrapper = document.createElement('div'); wrapper.className = 'table-scroll'; wrapper.tabIndex = 0; wrapper.setAttribute('role', 'region'); wrapper.setAttribute('aria-label', 'Scrollable evidence table'); table.before(wrapper); wrapper.append(table); });
  const current = STEPS.findIndex(x => x[0] === step);
  $('step-nav').innerHTML = `<button data-step="${STEPS[Math.max(0,current-1)][0]}" ${current === 0 ? 'disabled' : ''}>← Previous check</button><span>${current+1} of 7</span><button data-step="${STEPS[Math.min(6,current+1)][0]}" ${current === 6 ? 'disabled' : ''}>${step === 'decision' ? 'Review settled orders' : 'Next check'} →</button>`;
  $('log').innerHTML = S.log.length ? S.log.slice(0, 8).map(x => `<li><b>${esc(x.area)}</b> v${S.versions[x.area]} · ${esc(x.reason)} · quotes ${x.quotes} · ${x.snapshots} snapshot(s) to review</li>`).join('') : '<li class="muted">No changes yet.</li>';
  document.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('on', b.dataset.mode === S.mode));
}

/* Before/after explanation for any change. */
function explain(title, before, after, extra) {
  const lines = [];
  const pick = e => e.choice ? `${inr(e.choice.buyer)} (${inr(e.choice.econ.expected)} / dispatch)` : 'none';
  if (before.status !== after.status) lines.push(`Status: ${esc(before.status)} → <b>${esc(after.status)}</b>`);
  if (pick(before) !== pick(after)) lines.push(`Choice: ${pick(before)} → <b>${pick(after)}</b>`);
  const alt = e => e.alternative ? inr(e.alternative.buyer) : 'none';
  if (alt(before) !== alt(after)) lines.push(`Alternative: ${alt(before)} → <b>${alt(after)}</b>`);
  after.rows.forEach((r, i) => { const x = before.rows[i]; if (r.econ && x && x.econ && M.r2(r.econ.expected) !== M.r2(x.econ.expected)) lines.push(`${inr(r.buyer)} expected: ${inr(x.econ.expected)} → <b>${inr(r.econ.expected)}</b>; cost ceiling ${inr(x.ceiling.minimum)} → ${inr(r.ceiling ? r.ceiling.minimum : null)}`); });
  if (before.proc.need !== after.proc.need || before.proc.blocked !== after.proc.blocked) lines.push(`Cash to keep available: ${inr(before.proc.need)} → <b>${after.proc.known ? inr(after.proc.need) : 'unverified'}</b>${after.proc.blocked ? ' · procurement blocked' : ''}`);
  if (before.cmp.n !== after.cmp.n) lines.push(`Qualified alternatives: ${before.cmp.n} → <b>${after.cmp.n}</b> (range ${after.cmp.n ? inr(after.cmp.min) + '–' + inr(after.cmp.max) : 'none'})`);
  (extra || []).forEach(x => lines.push(x));
  if (!lines.length) lines.push('No decision value changed.');
  lastChange = { title, lines };
}

function apply(area, reason, mutate, extraFn) {
  const before = ev();
  const r = M.change(S, area, reason, mutate);
  const after = ev();
  const extra = [after.shipping ? `Shipping context: ${after.shipping.confirmed ? 'panel quote validated' : 'estimate or panel revalidation required'}` : `Quotes: ${r.quoteHit ? '<b>invalidated</b> (product or weight changed what is shipped)' : 'still valid (this change does not alter entry → buyer → transfer)'}`,
    `Snapshots needing review: ${r.invalidated}`].concat(extraFn ? extraFn(after) : []);
  explain(reason, before, after, extra);
  if (!S.reviewedCohorts.includes(COHORT_ID)) review = null; noteMsg = '';
  render();
}

const DEMOS = {
  comparable: () => { S.mode = 'scenario'; S.shipping.mode='historical'; const i = S.register.findIndex(x => x.id === 'M3'); if (S.register[i].status === 'accepted') apply('comparables', 'Comparable M3 ₹210 fails re-check (spec table shows CAT6)', s => { s.register[i].status = 'excluded'; s.register[i].reason = 'Failed re-check: CAT6 in spec table'; }, () => ['₹210 is now priced above every qualified alternative, so it is unsupported. ₹189 stays the competitive start; the comparable range is not willingness to pay.']); step = 'alternatives'; render(); },
  returns: () => { S.mode = 'scenario'; S.shipping.mode='historical'; apply('fees', 'Reverse charge ₹165 and half of returns arrive damaged', s => { s.fees.R = 165; s.fees.delta = 50; }, () => ['Reserve rises to ₹33 per unit (20% × ₹165, rounded down): more cash held, not a cost.']); step = 'economics'; render(); },
  cash: () => { S.mode = 'scenario'; S.shipping.mode='historical'; apply('seller', 'Supplier MOQ 10 and only ₹700 cash', s => { s.seller.moq = 10; s.seller.cash = 700; }, () => ['The price still passes: procurement, not price, is blocked. Options: renegotiate MOQ, add cash, or hold.']); step = 'constraints'; render(); },
  weight: () => { S.mode = 'scenario'; S.shipping.mode='historical'; apply('product', 'Packed weight measured at 520 g (above the 500 g band)', s => { s.product.packedWeight = 520; s.product.packedWeightSource = 'measured'; s.fees.R = null; }, () => ['Return fee for the new band is unknown: no precise earnings until requoted.']); step = 'quotes'; render(); },
  cost90: () => { S.mode = 'scenario'; S.shipping.mode='historical'; apply('costs', 'Acquisition cost rises to ₹90', s => { s.costs.C = 90; }); step = 'decision'; render(); },
  reset: () => { S = startingState(); step = 'quotes'; quoteEditor = false; quoteMessage = ''; review = null; K = 20; lastChange = null; noteMsg = ''; render(); }
};

document.addEventListener('click', ev0 => {
  const t = ev0.target.closest('button'); if (!t) return;
  if (t.classList.contains('menu-toggle')) { const open = t.getAttribute('aria-expanded') !== 'true'; t.setAttribute('aria-expanded', String(open)); document.querySelector('.side').classList.toggle('expanded', open); return; }
  if (t.dataset.pricing) { step='quotes'; quoteEditor=false; apply('quotes','Calculation source changed',s=>{s.shipping.mode=t.dataset.pricing;}); return; }
  if (t.dataset.step) { step = t.dataset.step; render(); return; }
  if (t.dataset.action === 'real-hold') { S.mode = 'real'; step = 'decision'; quoteEditor = false; noteMsg = ''; render(); return; }
  if (t.dataset.mode) { const before = ev(); S.mode = t.dataset.mode; quoteEditor = false; noteMsg = ''; explain('Evidence mode: ' + (S.mode === 'real' ? 'real record' : 'prototype scenario'), before, ev()); render(); return; }
  if (t.dataset.demo) { DEMOS[t.dataset.demo](); return; }
  if (t.dataset.fail) { const i = +t.dataset.fail; const id = S.register[i].id, price = S.register[i].price; apply('comparables', `Comparable ${id} ₹${price} fails re-check`, s => { s.register[i].status = 'excluded'; s.register[i].reason = 'Failed re-check'; }); return; }
  const a = t.dataset.action; const e = ev();
  if (a === 'confirm-shipping') { step='quotes'; if(S.shipping.mode==='confirmed'){render();return;} apply('quotes', 'Review supplier-panel quote', s=>{s.shipping.mode='confirmed';}); return; }
  if (a === 'open-shipping') { step='quotes'; apply('quotes', 'Opened online shipping estimates', s=>{s.shipping.mode='online';}); return; }
  if (a === 'historical-review') { step='review'; apply('quotes', 'Opened original historical cohort', s=>{s.shipping.mode='historical';}); return; }
  if (a === 'save-estimate' && e.shipping && e.shipping.ok) { const snap=M.snapshot(S,e,e.shipping.confirmed?'Save quote review':'Save estimated plan'); snap.expectedRange=e.rows[0].econRange?e.rows[0].econRange.expected:null; noteMsg='Plan saved with its source and ranges. This is not approval or a listing change.';render();return; }
  if (a === 'inputs') { commitVisibleInputs(); return; }
  if (a === 'goal') { apply('seller', 'Seller goal and minimum confirmed', s => { s.seller.objective = $('in-objective').value; s.seller.denominator = $('in-denominator').value; s.seller.g = $('in-minimum').value === '' ? null : Number($('in-minimum').value); }); }
  if (a === 'approve' && (!e.shipping || e.shipping.confirmed) && ['READY FOR YOUR APPROVAL', 'WEAK-EVIDENCE TEST'].includes(e.status)) { M.snapshot(S, e, 'Approve ' + inr(e.choice.buyer)); noteMsg = 'Snapshot saved. Nothing was listed, bought or dispatched.'; render(); }
  if (a === 'alt' && e.alternative) { const before = e; apply('seller', 'Seller switched objective', s => { s.seller.objective = s.seller.objective === 'earnings' ? 'competitive' : 'earnings'; }); }
  if (a === 'hold') { M.snapshot(S, e, 'Hold'); noteMsg = 'Decision saved for later with its reasons and next action.'; render(); }
  if (a === 'edit') { S.shipping.mode='historical'; quoteEditor = !quoteEditor; quoteMessage = ''; step = 'quotes'; render(); }
  if (a === 'requote') { const before = ev(); S.quoteValid = true; S.versions.quotes += 1; S.log.unshift({ area: 'quotes', reason: 'Quotes re-captured (demo assumption)', quotes: 'valid', snapshots: 0 }); explain('Quotes re-captured', before, ev()); render(); }
  if (a === 'apply') {
    if(S.shipping.mode!=='historical')return;
    if (S.mode !== 'scenario' || S.costs.private || e.errors.length || !S.quoteValid || S.reviewedCohorts.includes(COHORT_ID)) return;
    const L = M.ledger(P.COHORT, HISTORICAL_INPUTS);
    const u = M.commitReview(S, L, K, COHORT_ID); if (!u.applied) return;
    const before = ev(), beforeState = JSON.parse(JSON.stringify(S)); S = u.next;
    const stale = S.snapshots.filter(x => x.state === 'Current');
    stale.forEach(x => { x.state = 'Needs review'; x.why = 'Outcome update v' + S.versions.outcomes; });
    S.log.unshift({ area: 'outcomes', reason: `Review applied once with K = ${K} (uncalibrated)`, quotes: 'still valid', snapshots: stale.length });
    explain('Review applied to the same SKU', before, ev(), ['This cohort is now processed. New outcomes are needed before another update.']); review = JSON.parse(JSON.stringify(u)); review.beforeState = beforeState; render();
  }
});

document.addEventListener('change', ev0 => {
  const t = ev0.target;
  if(t.closest('#shipping-form')) {
    if(!t.name.startsWith('ship-'))return;
    const value=t.value===''?null:Number(t.value);
    if(t.name==='ship-weight')apply('product','Packed weight changed; review shipping quote',s=>{s.product.packedWeight=value;s.product.packedWeightSource='measured';});
    else {
      const fields={'ship-buyer':'buyer','ship-panel-weight':'panelWeight','ship-zone':'zone','ship-tax':'taxBasis','ship-other':'other','ship-source':'rateSource','ship-carrier':'carrier','ship-return-tax':'returnTaxBasis'};
      apply('shipping','Shipping context changed; saved decisions need review',s=>{
        if(fields[t.name])s.shipping[fields[t.name]]=['ship-buyer','ship-panel-weight','ship-other'].includes(t.name)?value:t.value;
        else {const manual={'ship-forward-min':['manualForward',0],'ship-forward-max':['manualForward',1],'ship-return-min':['manualReturn',0],'ship-return-max':['manualReturn',1]}[t.name];if(manual)s.shipping[manual[0]][manual[1]]=value;}
      });
    }
    return;
  }
  if (['in-objective', 'in-denominator', 'in-minimum'].includes(t.id)) return; // Confirm the goal as one edit to preserve unfinished fields.
  const v = t.value === '' ? null : Number(t.value);
  const map = {
    'in-minimum': ['seller', 'Minimum earnings edited', s => { s.seller.g = v; }],
    'in-weight': ['product', 'Packed weight edited', s => { const crosses = (v > s.product.weightBand) !== (s.product.packedWeight > s.product.weightBand); s.product.packedWeight = v; s.product.packedWeightSource = 'measured'; if (crosses && v > s.product.weightBand) s.fees.R = null; }],
    'in-o': ['costs', 'Packing and preparation edited', s => { s.costs.o = v; }],
    'in-C': ['costs', 'Acquisition cost edited', s => { s.costs.C = v; }],
    'in-R': ['fees', 'Reverse fee edited', s => { s.fees.R = v; }],
    'in-d': ['fees', 'Damaged share edited', s => { s.fees.delta = v; }],
    'in-cash': ['seller', 'Available cash edited', s => { s.seller.cash = v; }],
    'in-owned': ['seller', 'Owned units edited', s => { s.seller.owned = v; }],
    'in-cap': ['seller', 'Seller cap edited', s => { s.seller.cap = v; }],
    'in-moq': ['seller', 'Supplier MOQ edited', s => { s.seller.moq = v; }]
  };
  if (map[t.id]) { const [area, reason, f] = map[t.id]; apply(area, reason, f); return; }
  if (t.dataset.mix) { apply('outcomes', 'Outcome mix edited', s => { s.mix[t.dataset.mix] = v; s.mix.source = 'assumed'; }); return; }
  if (t.id === 'in-private') { apply('costs', t.checked ? 'Cost kept private' : 'Cost shared', s => { s.costs.private = t.checked; s.costs.C = t.checked ? null : 55; }); return; }
  if (t.id === 'in-weak') { const before = ev(); S.weakAck = t.checked; explain('Weak-evidence acknowledgement', before, ev()); render(); return; }
  if (t.id === 'in-K' && !S.reviewedCohorts.includes(COHORT_ID)) { K = Math.max(1, Math.round(v || 20)); review = null; render(); }
});

function commitVisibleInputs() {
  const fields = {
    'in-weight': ['product', 'packedWeight'], 'in-C': ['costs', 'C'], 'in-o': ['costs', 'o'],
    'in-R': ['fees', 'R'], 'in-d': ['fees', 'delta'], 'in-cash': ['seller', 'cash'],
    'in-owned': ['seller', 'owned'], 'in-cap': ['seller', 'cap'], 'in-moq': ['seller', 'moq']
  };
  const changes = [];
  for (const [id, [area, key]] of Object.entries(fields)) {
    const input = $(id); if (!input || input.disabled) continue;
    const value = input.value === '' ? null : Number(input.value);
    if (S[area][key] !== value) changes.push({area, key, value});
  }
  for (const input of document.querySelectorAll('[data-mix]')) {
    const value = input.value === '' ? null : Number(input.value);
    if (S.mix[input.dataset.mix] !== value) changes.push({area: 'outcomes', key: input.dataset.mix, value});
  }
  if (!changes.length) { noteMsg = 'Inputs are up to date.'; render(); return; }
  const before = ev();
  for (const area of new Set(changes.map(x => x.area))) M.change(S, area, 'Seller confirmed ' + area + ' inputs', state => {
    for (const change of changes.filter(x => x.area === area)) {
      if (area === 'outcomes') { state.mix[change.key] = change.value; state.mix.source = 'assumed'; }
      else {
        state[area][change.key] = change.value;
        if (area === 'product') { state.product.packedWeightSource = 'measured'; if (change.value > state.product.weightBand) state.fees.R = null; }
      }
    }
  });
  explain('Seller confirmed inputs', before, ev());
  if (!S.reviewedCohorts.includes(COHORT_ID)) review = null;
  noteMsg = 'Inputs updated. Review the recalculated decision before approval.'; render();
}

document.addEventListener('submit', event => {
 if(event.target.id!=='shipping-form')return;
 event.preventDefault();
 const form=event.target,data=new FormData(form),num=name=>data.get(name)===''?null:Number(data.get(name));
 const candidate=JSON.parse(JSON.stringify(S)),c=candidate.shipping;
 candidate.product.packedWeight=num('ship-weight');candidate.product.packedWeightSource='measured';
 Object.assign(c,{buyer:num('ship-buyer'),panelWeight:num('ship-panel-weight'),zone:data.get('ship-zone'),taxBasis:data.get('ship-tax'),other:num('ship-other'),rateSource:data.get('ship-source'),carrier:data.get('ship-carrier'),returnTaxBasis:data.get('ship-return-tax'),manualForward:[num('ship-forward-min'),num('ship-forward-max')],manualReturn:[num('ship-return-min'),num('ship-return-max')]});
 if(c.mode==='confirmed'){
  if(!data.get('panel-confirm')){$('shipping-feedback').textContent='Confirm that these values came from the supplier panel.';return;}
  c.confirmed={entry:num('panel-entry'),transfer:num('panel-transfer'),returnGross:num('panel-return'),date:data.get('panel-date'),context:PCShipping.context(candidate)};
 }
 const result=PCShipping.calculate(candidate);
 const before=ev();
 if(S.product.packedWeight!==candidate.product.packedWeight || S.product.packedWeightSource!==candidate.product.packedWeightSource)M.change(S,'product','Packed weight confirmed for shipping calculation',state=>{state.product.packedWeight=candidate.product.packedWeight;state.product.packedWeightSource='measured';});
 M.change(S,'shipping',c.mode==='confirmed'?'Panel quote confirmed for current shipping context':'Shipping assumptions confirmed; buyer total fixed',state=>{state.shipping=c;});
 if(!result.ok){render();$('shipping-feedback').textContent=result.errors.join(' ');return;}
 explain('Shipping calculation updated',before,ev(),['Buyer total remains '+inr(c.buyer)+'. Public rates are not a current quote.']);
 noteMsg=c.mode==='confirmed'?'Panel net payout saved and used directly; shipping is not deducted again.':'Estimate updated. Confirm the panel quote before approval.';
 render();
});

document.addEventListener('submit', event => {
  if (event.target.id !== 'quote-form') return;
  event.preventDefault();
  if (S.mode !== 'scenario') return;
  const form = event.target, data = new FormData(form);
  const entry = Number(data.get('entry')), buyer = Number(data.get('buyer')), transfer = Number(data.get('transfer'));
  if (![entry, buyer, transfer].every(Number.isFinite) || entry <= 0 || buyer <= 0 || transfer < 0 || transfer > buyer || !data.get('confirmed')) {
    quoteMessage = 'Enter valid prices. The kept-order transfer must be between zero and the buyer price, and all three values must be confirmed.';
    $('quote-feedback').textContent = quoteMessage; return;
  }
  if (S.quotes.some(q => q.buyer === buyer)) { quoteMessage = 'That buyer price already has a candidate. Enter a different offer, or reset the demo.'; $('quote-feedback').textContent = quoteMessage; return; }
  quoteEditor = false;
  apply('quotes', 'Seller added a complete candidate quote (demo assumption)', s => {
    s.quotes.push({ id: 'Qmanual' + s.versions.quotes, label: 'Seller candidate', entry, entryEstimate: null, buyer, transfer, source: 'manual' });
    if (!s.quoteValid) s.quotes = s.quotes.slice(-1); // changed product: do not revive stale historical pairs
    s.quoteValid = true;
  });
  step = 'decision'; noteMsg = 'Candidate saved as a demo assumption. Earnings, comparable support, downside and cash have been checked; nothing was listed.'; render();
});

window.PCJ = { getState: () => JSON.parse(JSON.stringify(S)), evaluate: () => M.evaluate(S), demo: n => DEMOS[n](), go: s => { step = s; render(); } };
render();
