const fs = require('node:fs'), path = require('node:path');
const d = __dirname; let html = fs.readFileSync(path.join(d, 'index.html'), 'utf8');
html = html.replace('<link rel="stylesheet" href="styles.css">', () => `<style>${fs.readFileSync(path.join(d, 'styles.css'), 'utf8')}</style>`);
for (const f of ['shipping.js', 'record.js', 'model.js', 'app.js', 'seller-model.js', 'seller-ui.js']) html = html.replace(`<script src="${f}"></script>`, () => `<script>${fs.readFileSync(path.join(d, f), 'utf8')}</script>`);
fs.writeFileSync(path.join(d, '..', 'PriceCompass_Journey_Demo.html'), html); fs.writeFileSync(path.join(d, '..', 'index.html'), html);
fs.writeFileSync(path.join(d, '..', '..', 'index.html'), html);
console.log('Built offline demo and both submission entry points');
