const assert = require('node:assert/strict');
const P = require('./record.js'), M = require('./model.js');
let n = 0; const test = (name, f) => { f(); console.log('PASS ' + name); n++; };
const near = (a, b, t = 0.005) => assert.ok(Math.abs(a - b) < t, `${a} != ${b}`);
const S = () => P.base();

test('Kept / RTO / return rows and m formula agree', () => {
  const s = S(); const [a, b] = s.quotes.map(q => M.perDispatch(s, q));
  near(a.kept, 36); near(a.rto, -5); near(a.ret, -158); near(a.expected, 14.55); near(b.expected, 31.55);
  near(a.formula, a.expected, 1e-9); near(b.formula, b.expected, 1e-9);
});
test('Demand thresholds 2.16838x and 46.117%', () => { near(31.55 / 14.55, 2.16838, 1e-5); near(14.55 / 31.55, 0.46117, 1e-5); });
test('Cost ceilings use (kT - o - qR - g)/(k + q delta)', () => {
  const s = S(); near(M.ceiling(s, s.quotes[0]).minimum, 72.12); near(M.ceiling(s, s.quotes[1]).minimum, 92.12);
  s.fees.delta = 100; near(M.ceiling(s, s.quotes[0]).minimum, 61.3 / 0.95);
});
test('Entry estimates from the panel price structure', () => {
  near(96 + 0.18 * (189 - 96) / 1.18, 110.19); near(116 + 0.18 * (210 - 116) / 1.18, 130.34);
});
test('Funding: ₹90 per unit, cap 9 → ₹810; reserve ₹30 is funding not expense; 11 fit', () => {
  const s = S(); const p = M.procurement(s);
  assert.equal(p.funding.perNew, 90); assert.equal(p.units, 9); assert.equal(p.need, 810); assert.equal(p.reserveHeld, 270); assert.equal(p.affordableMax, 11); assert.equal(p.blocked, false);
});
test('C ₹90: −₹15.20 / +₹1.80, funding ₹125 (total, not reserve), ₹1,000 fits 8', () => {
  const s = S(); s.costs.C = 90; const e = M.evaluate(s);
  near(e.rows[0].econ.expected, -15.2); near(e.rows[1].econ.expected, 1.8);
  const p = M.procurement(s); assert.equal(p.funding.perNew, 125); assert.equal(p.funding.reserve, 30); assert.equal(p.affordableMax, 8);
  assert.equal(e.choice.buyer, 210);
});
test('Scenario: competitive start is ₹189 (lowest supported passing), alternative ₹210', () => {
  const e = M.evaluate(S()); assert.equal(e.choice.buyer, 189); assert.equal(e.alternative.buyer, 210); assert.equal(e.status, 'READY FOR YOUR APPROVAL');
  assert.equal(e.cmp.n, 3); assert.equal(e.cmp.median, 200);
});
test('Earnings objective picks ₹210', () => { const s = S(); s.seller.objective = 'earnings'; assert.equal(M.evaluate(s).choice.buyer, 210); });
test('Real mode: 0 qualified peers, no current quote → HOLD', () => {
  const s = S(); s.mode = 'real'; const e = M.evaluate(s); assert.equal(e.cmp.n, 0); assert.equal(e.status, 'HOLD'); assert.ok(e.reasons.length >= 3);
});
test('No qualified comparable: HOLD unless weak-evidence test acknowledged', () => {
  const s = S(); s.register.forEach(x => x.status = 'excluded'); assert.equal(M.evaluate(s).status, 'HOLD');
  s.weakAck = true; const e = M.evaluate(s); assert.equal(e.status, 'WEAK-EVIDENCE TEST'); assert.equal(e.choice.buyer, 189);
});
test('Demo 1: comparable M3 fails → ₹210 unsupported, snapshot stale, quote still valid', () => {
  const s = S(); M.snapshot(s, M.evaluate(s), 'approve', 't0');
  const r = M.change(s, 'comparables', 'M3 ₹210 failed re-check', x => { x.register[2].status = 'excluded'; });
  const e = M.evaluate(s);
  assert.equal(r.quoteHit, false); assert.equal(s.quoteValid, true); assert.equal(s.snapshots[0].state, 'Needs review');
  assert.equal(e.cmp.max, 200); assert.equal(e.cmp.median, 194.5); assert.equal(e.choice.buyer, 189); assert.equal(e.alternative, null);
  assert.equal(e.rows[1].supported, false);
});
test('Demo 2: reverse charge ₹165 and half of returns damaged → ₹10.60 / ₹27.60, reserve ₹33', () => {
  const s = S(); M.snapshot(s, M.evaluate(s), 'approve', 't0');
  M.change(s, 'fees', 'Reverse charge ₹165; 50% of returns unsellable', x => { x.fees.R = 165; x.fees.delta = 50; });
  const e = M.evaluate(s); near(e.rows[0].econ.expected, 10.6); near(e.rows[1].econ.expected, 27.6);
  near(e.rows[0].ceiling.minimum, 66.78); assert.equal(M.reserve(s), 33); assert.equal(e.proc.need, 837);
  assert.equal(s.quoteValid, true); assert.equal(s.snapshots[0].state, 'Needs review');
});
test('Demo 3: MOQ 10 and ₹700 cash block procurement while the price passes', () => {
  const s = S(); M.change(s, 'seller', 'MOQ 10; cash ₹700', x => { x.seller.moq = 10; x.seller.cash = 700; });
  const e = M.evaluate(s); assert.equal(e.status, 'PRICE PASSES · PROCUREMENT HOLD'); assert.equal(e.choice.buyer, 189);
  assert.equal(e.proc.need, 900); assert.equal(e.proc.fallback, null); assert.equal(s.quoteValid, true);
  s.seller.moq = 1; const e2 = M.evaluate(s); assert.equal(e2.proc.fallback.units, 7); assert.equal(e2.proc.fallback.need, 630);
});
test('Packed-weight change invalidates quotes → HOLD until requoted', () => {
  const s = S(); const r = M.change(s, 'product', 'Packed weight measured 520 g', x => { x.product.packedWeight = 520; x.fees.R = null; });
  assert.equal(r.quoteHit, true); assert.equal(M.evaluate(s).status, 'HOLD');
});
test('Stress cases (labelled what-ifs)', () => {
  const st = M.stressCases(S()); const v = Object.fromEntries(st.map(x => [x.label, x.values]));
  assert.deepEqual(st[1].values, [13.35, 30.35]); assert.deepEqual(st[2].values, [12.69, 27.29]); assert.deepEqual(st[3].values, [2.03, 17.53]);
  assert.deepEqual(st[4].values, [9.05, 26.05]); assert.deepEqual(st[5].values, [-15.2, 1.8]); void v;
});
test('Most sensitive assumption is acquisition cost (+31% flips ₹189)', () => {
  const e = M.evaluate(S()); assert.equal(e.sensitive[0].name, 'Acquisition cost C'); near(e.sensitive[1].flip, 17.5);
});
test('Private cost: ceilings only, no profit, no cash approval', () => {
  const s = S(); s.costs.private = true; s.costs.C = null; const e = M.evaluate(s);
  assert.equal(e.status, 'HOLD'); assert.equal(e.rows[0].econ, null); near(e.rows[0].ceiling.minimum, 72.12); assert.equal(e.proc.known, false);
});
test('Blank inputs are unknown, not zero', () => {
  for (const f of [s => s.costs.o = null, s => s.fees.R = null, s => s.seller.cash = null, s => s.mix.k = null]) { const s = S(); f(s); assert.equal(M.evaluate(s).status, 'HOLD'); }
});
test('Cohort ledger: +₹41 contribution, −₹129 cash, ₹110 recoverable stock, 1 pending', () => {
  const s = S(); const L = M.ledger(P.COHORT, s);
  assert.equal(L.kept, 6); assert.equal(L.rto, 1); assert.equal(L.returned, 1); assert.equal(L.pending, 1);
  assert.equal(L.contribution, 41); assert.equal(L.cash, -129); assert.equal(L.inventoryValue, 110); assert.equal(L.settlements, 576); assert.equal(L.reverseCharges, 165);
  const closedCash = L.rows.filter(x => x.status !== 'pending').reduce((a, x) => a + x.cash, 0); assert.equal(closedCash + L.inventoryValue, L.contribution);
});
test('K=20 update: 85/5/10 → 82.14/7.14/10.71, R ₹153 → ₹165, ₹189 → ₹11.00, ₹210 → ₹27.43', () => {
  const s = S(); const L = M.ledger(P.COHORT, s); const u = M.update(s, L, 20);
  near(u.after.k, 82.142857, 1e-5); near(u.after.r, 7.142857, 1e-5); near(u.after.q, 10.714286, 1e-5); assert.equal(u.after.R, 165); assert.equal(u.after.reserve, 33);
  const e = M.evaluate(u.next); near(e.rows[0].econ.expected, 11.0); near(e.rows[1].econ.expected, 27.43); near(e.rows[0].ceiling.minimum, 68.39);
  assert.equal(e.choice.buyer, 189);
});
test('Next decision keeps the price and holds procurement while one dispatch is pending', () => {
  const s = S(); const L = M.ledger(P.COHORT, s); const u = M.update(s, L, 20); const d = M.nextDecision(u.next, L, M.evaluate(u.next));
  assert.equal(d.bank, 871); assert.equal(d.available, 838); assert.equal(d.relist, 76); assert.equal(d.reorderUnits, 7); assert.equal(d.reorder, 727); assert.ok(/Keep ₹189/.test(d.price));
});
test('Negative downside requires review while preserving base-case recommendation', () => {
  const s = S(); s.fees.R = 165; s.fees.delta = 50;
  let e = M.evaluate(s); assert.equal(e.status, 'ASSISTED REVIEW REQUIRED'); assert.equal(e.downsideFailures.length, 1); near(e.downsideFailures[0].values[0], -2.10);
  s.seller.objective = 'earnings'; e = M.evaluate(s); assert.equal(e.choice.buyer, 210); assert.equal(e.status, 'READY FOR YOUR APPROVAL');
});
test('Exploratory cost change does not masquerade as current downside evidence', () => {
  const e = M.evaluate(S()); assert.equal(e.downsideFailures.length, 0); assert.equal(e.stress[5].scope, 'Exploratory cost change'); assert.equal(e.status, 'READY FOR YOUR APPROVAL');
});
test('Each settled cohort commits exactly once', () => {
  const s = S(), L = M.ledger(P.COHORT, s); const first = M.commitReview(s, L, 20, 'D1-D9'); assert.equal(first.applied, true);
  const second = M.commitReview(first.next, L, 20, 'D1-D9'); assert.equal(second.applied, false); assert.equal(second.next.versions.outcomes, 2); near(M.evaluate(second.next).rows[0].econ.expected, 11);
  const third = M.commitReview(second.next, L, 20, 'new-cohort'); assert.equal(third.applied, true); assert.equal(third.next.versions.outcomes, 3);
});
test('Invalid packed weight and minimum earnings hold approval', () => {
  for (const mutate of [s => s.product.packedWeight = null, s => s.product.packedWeight = 0, s => s.seller.g = -1, s => s.seller.g = null]) { const s = S(); mutate(s); assert.equal(M.evaluate(s).status, 'HOLD'); }
});
test('Private cost cannot produce a ceiling from missing reverse fees', () => {
  const s = S(); s.costs.private = true; s.costs.C = null; s.fees.R = null;
  assert.equal(M.evaluate(s).rows[0].ceiling, null); assert.equal(M.evaluate(s).status, 'HOLD');
});
test('Minimum denominator changes which quotes meet seller needs', () => {
  const s = S(); s.seller.g = 25; s.seller.denominator = 'kept'; assert.equal(M.evaluate(s).choice.buyer, 189);
  s.seller.denominator = 'dispatch'; assert.equal(M.evaluate(s).choice.buyer, 210); s.seller.g = 60; assert.equal(M.evaluate(s).status, 'HOLD');
});
test('Manually supplied quotes must pass market support and cash checks', () => {
  const s = S(); s.quotes.push({id:'manual',entry:120,buyer:199,transfer:106}); s.seller.objective = 'earnings'; assert.equal(M.evaluate(s).choice.buyer,210);
  s.quotes.push({id:'too-high',entry:140,buyer:230,transfer:130}); const e = M.evaluate(s); assert.equal(e.rows[3].supported,false); assert.equal(e.choice.buyer,210);
});
console.log(`${n} journey model checks passed.`);
