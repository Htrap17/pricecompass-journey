/* PriceCompass one-SKU journey: the decision record for SKU PC-CABLE-5M, version 1.
   Every value carries a provenance label. Nothing here is a live Meesho record. */
(function (root) {
  'use strict';
  const SOURCES = {
    audit: 'Team public audit, 28 Sep 2026 (observed Meesho / other-channel listings)',
    panel: 'Historical seller panel (~1 year old; observed, not a current quote)',
    panelFee: 'Seller panel / Meesho shipping-and-returns page [12] (fee read 2 Oct 2026; applicability to confirm)',
    derived: 'Estimate derived from the panel price structure (formula, not an executable quote)',
    assumed: 'Worked-example assumption (not observed)',
    generated: 'Generated scenario register (not observed)',
    synthetic: 'Prototype test cohort (synthetic, labelled; not observed)',
    calc: 'Calculation from the labelled inputs'
  };

  function base() {
    return {
      shipping: (typeof module !== 'undefined' ? require('./shipping.js') : PCShipping).defaults(),
      mode: 'scenario', // 'real' = only observed evidence; 'scenario' = labelled prototype assumptions
      weakAck: false,   // seller acknowledges a weak-evidence test when no comparable qualifies
      product: {
        sku: 'PC-CABLE-5M', version: 1,
        title: 'CAT5e Ethernet patch cable',
        unit: '5 m, white, UTP, RJ45 both ends',
        conductor: null, // copper vs CCA unresolved: a product-truth gap
        pack: 'Pack of 1',
        packedWeight: 250, packedWeightSource: 'assumed', // not measured
        weightBand: 500,  // fee band used: up to 500 g
        fulfilment: 'Self-ship through Meesho logistics', fulfilmentSource: 'assumed',
        offlinePrice: null // not recorded
      },
      costs: { C: 55, o: 5, private: false },
      fees: { R: 153, Rrange: [153, 165], rtoFee: 0, delta: 0 },
      mix: { k: 85, r: 5, q: 10, source: 'assumed' },
      seller: { objective: 'competitive', g: 0, denominator: 'dispatch', cash: 1000, owned: 0, cap: 9, moq: 1, reservePct: 20 },
      quotes: [
        { id: 'Q189', entry: 110, entryEstimate: 110.19, buyer: 189, transfer: 96, label: 'Platform suggestion', source: 'panel' },
        { id: 'Q210', entry: 130, entryEstimate: 130.34, buyer: 210, transfer: 116, label: 'Current listing', source: 'panel' }
      ],
      quoteValid: true, // scenario assumes the panel pair is current; real mode never does
      audit: [
        { id: 'A1', price: 165, what: 'Meesho, 5 m white CAT5e', status: 'excluded', reason: 'Out of stock; construction unresolved' },
        { id: 'A2', price: 167, what: 'Meesho, CAT6', status: 'excluded', reason: 'Wrong grade (CAT6)' },
        { id: 'A3', price: 222, what: 'Meesho, 10 m', status: 'excluded', reason: 'Wrong length (10 m)' },
        { id: 'A4', price: 155, what: 'Shopsy listing', status: 'excluded', reason: 'Other channel; weak reference' },
        { id: 'A5', price: 130, what: 'Moglix, CAT5', status: 'excluded', reason: 'Wrong grade and channel' }
      ],
      register: [
        { id: 'M1', price: 189, status: 'accepted', reason: 'Accepted by assumption' },
        { id: 'M2', price: 200, status: 'accepted', reason: 'Accepted by assumption; no quote at ₹200' },
        { id: 'M3', price: 210, status: 'accepted', reason: 'Accepted by assumption' },
        { id: 'M4', price: 189, status: 'excluded', reason: 'Duplicate seller' },
        { id: 'M5', price: 169, status: 'excluded', reason: 'Wrong specification (CAT6)' },
        { id: 'M6', price: 190, status: 'excluded', reason: 'Unavailable' }
      ],
      versions: { product: 1, shipping: 1, comparables: 1, quotes: 1, fees: 1, costs: 1, seller: 1, outcomes: 1 },
      reviewedCohorts: [],
      snapshots: [],
      log: []
    };
  }

  /* Synthetic 9-dispatch review cohort for the same SKU and version at ₹189. */
  const COHORT = [
    { id: 'D1', status: 'kept', settled: 96, reverse: 0, stock: 'sold' },
    { id: 'D2', status: 'kept', settled: 96, reverse: 0, stock: 'sold' },
    { id: 'D3', status: 'kept', settled: 96, reverse: 0, stock: 'sold' },
    { id: 'D4', status: 'kept', settled: 96, reverse: 0, stock: 'sold' },
    { id: 'D5', status: 'kept', settled: 96, reverse: 0, stock: 'sold' },
    { id: 'D6', status: 'kept', settled: 96, reverse: 0, stock: 'sold' },
    { id: 'D7', status: 'rto', settled: 0, reverse: 0, stock: 'intact' },
    { id: 'D8', status: 'return', settled: 0, reverse: 165, stock: 'intact' },
    { id: 'D9', status: 'pending', settled: null, reverse: null, stock: 'with buyer' }
  ];

  const api = { base, COHORT, SOURCES };
  if (typeof module !== 'undefined') module.exports = api; else root.PCRecord = api;
})(globalThis);
