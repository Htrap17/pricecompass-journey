# Current warehouse and shipping assumptions

The new seller flow uses `src/shipping.js` supplied dataset, version seller-screenshot-2026-10-05. The original screenshot is bundled as supplied-warehouse-rate-card.png. Received 5 October 2026; publication date and current tariff applicability are unknown.

The seller clarified that all listed courier/warehouse fees exclude GST, and customer-return cost is the reverse shipping fee plus GST only. These are seller-provided assumptions, not independently verified official tariff claims. Forward shipping defaults to half the listed reverse fee, labelled a demo assumption; the listed fee is halved before calculating GST.

GST is 18%, rounded to paise separately on forward shipping, reverse shipping and delivered-order warehouse handling. Warehouse handling is assumed additional to forward shipping. Other confirmed deductions are final totals including applicable taxes. Confirmed net payout and total return charge already include applicable fees and GST and receive no extra deductions.

Reverse rate bands: up to 500 g, above 500 to 1,000 g, above 1,000 to 1,500 g, above 1,500 to 2,000 g, and above 2,000 to 2,500 g. Carrier columns are transcribed exactly from the screenshot for seller-location and warehouse fulfilment. Unknown carrier spans the selected fulfilment column. Above 2,500 g requires manual courier rates or a complete panel quote.

Warehouse handling bands are independent: up to 150 g, above 150 to 500 g, above 500 to 1,000 g, above 1,000 to 2,000 g, and above 2,000 g. Under/over-500-km warehouse distance is not the published local/regional/national shipping zone. Unknown distance and exactly 500 km use both handling endpoints.

The screenshot's return handling, old-inventory and B2B reject charges are reference-only rows. No warehouse handling is added to returned orders under the seller's rule. Inbound transport, old-inventory and rejected-stock costs are excluded from ordinary earnings. Additional RTO shipping remains zero; warehouse RTO processing is free in the supplied table, while preparation costs remain applicable.

Expected earnings use the lowest payout and highest total reverse charge for downside checks. Cash reserve uses the highest return total and rounds up per unit. Fee context includes fulfilment, forward method, warehouse distance, carrier, parcel, buyer price, rate source, manual fees and tax bases. Changing context invalidates confirmation and saved choices. Historical ledgers and original fee assumptions remain independent.

Published forward ranges remain selectable only for seller-location shipping through 2,000 g. The source links and earlier profile below document those published observations and the separate historical demonstrations. The earlier profile's unknown return-GST alternatives do not override the seller's clarified GST-exclusive setting in the new flow.

---

## Earlier published and historical shipping profile

# Shipping sources and calculation assumptions

Bundled dataset: `src/shipping.js`, observations version 2026-10-05. Retrieval date for all sources: 2026-10-05. Values are indicative third-party observations, not an official Meesho tariff or a live quote.

- [EcomArray](https://www.ecomarray.com/what-are-the-shipping-charges-for-sellers-on-meesho): published/updated 2025-12-02. Forward bands and carrier-specific customer-return observations. Describes forward GST at 18% as additional. Return-table GST basis is unspecified.
- [Shiprocket](https://www.shiprocket.in/blog/meesho-shipping-charges/): published 2026-02-17. Reproduces the forward bands; selecting it changes provenance, not these observations. Its conflicting third-party RTO claims are not used.
- [Meesho shipping policy](https://supplier.meesho.com/shipping): no publication date displayed. Customer-return charges depend on weight; RTO carries no additional shipping fee. The calculator sets additional RTO shipping to zero; preparation costs remain in the contribution model.

Forward bands (₹, before GST by default):

| Packed weight | Local | Regional | National |
|---|---|---|---|
| ≤500 g | 35–45 | 45–70 | 55–90 |
| >500–1,000 g | 50–70 | 65–95 | 80–120 |
| >1,000–1,500 g | 60–85 | 80–120 | 100–150 |
| >1,500–2,000 g | 70–95 | 95–135 | 120–170 |

Customer-return observations (₹, GST basis unspecified):

| Carrier | ≤500 g | >500–1,000 g | >1,000–1,500 g | >1,500–2,000 g |
|---|---|---|---|---|
| Valmo | 153 | 163 | 169 | 184 |
| Ecom Express | 165 | 175 | 181 | 196 |
| Shadowfax | 162 | 172 | 178 | 192 |
| Delhivery | 161 | 203 | 244 | 290 |
| Xpressbees | 155 | 165 | 171 | 186 |

Unknown carrier spans these observations. Unknown return tax includes both listed-fee-inclusive and listed-fee-exclusive cases. Forward exclusive fees add rounded 18% GST; inclusive fees split GST out without increasing the total. Buyer total stays fixed: payout = buyer − forward gross − other deductions. Monetary outputs round to paise. Highest forward fee gives lowest payout. Negative payouts are shown.

Confirmed panel net payout overrides estimates without further subtraction. Total return fee is supplied including tax. Confirmation is seller-entered and tied to weight, chargeable-weight override, fulfilment, buyer total, zone, tax bases, carrier, deductions, rate source and manual rates. Context changes require revalidation. Panel data is not fetched automatically.

Expected contribution uses opposite payout/return endpoints; minimum earnings checks use the downside. Reserve funding uses the upper total return fee, rounded up to whole rupees per unit. It is cash held, not a second expense. Original historical reserve rounding and ledger accounting remain intact.

Manual rates above 2 kg remain assumptions. No volumetric divisor, exact pincode quote or seller-entry price is inferred. Scenario weight is labelled until a measured value is entered. Outcome rates, product costs and damage assumptions remain independent of shipping data. Seller product-tax and withholding reconciliation are outside this simplified scenario.
