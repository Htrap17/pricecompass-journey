> Earlier interface revision. Current warehouse behavior is documented in README.md and PriceCompass_Journey/SHIPPING_SOURCE_NOTES.md.

> Earlier interface revision. The current three-screen implementation is documented in SIMPLIFICATION_PLAN.md.

# Pre-GitHub interface plan

1. Start new sessions and Reset in Online estimate / Price and payout. Keep the historical calculation model unchanged and accessible through Historical example and historical demos.
2. Add context-specific next actions to decision screens. Route incomplete shipping to shipping inputs, uncertain estimates to panel confirmation, failed economics to product costs, cash/MOQ problems to funding, and missing real evidence to seller inputs. Preserve the approval rules and recorded calculation statuses.
3. Put a compact “Why this payout?” explanation beside the result: selected band/zone, gross shipping, deductions and payout. Explain that confirmed net payout is used directly.
4. Show weight, payout, cost and outcome evidence labels beside shipping results and decisions. Clearly distinguish scenario inputs from measured and seller-confirmed data.
5. Rebuild standalone files, check historical and shipping regressions, exercise desktop/mobile screens and next-action links, update demonstration notes and screenshots, package a new ZIP. Publishing remains a separate task. Direct file loading is a manual check because the app browser cannot navigate file URLs.
