# PriceCompass presentation prototype

Open `PriceCompass_Presentation_Demo.html` in Chrome, Edge, Safari or another modern browser. It is a single offline file: no server, installation, account, login or internet is required. The tested browser is Chrome; other browsers have not been exercised.

## Launch and reset

1. Double-click the HTML file, or use the browser’s File → Open command.
2. Start at Products → Review with PriceCompass for the original cable.
3. Use Demo controls for named input presets. Presets replace the active case’s inputs and invalidate earlier decisions for that case.
4. Use Demo controls → Reset all inputs and history → Reset inputs and history to return to the beginning. Reloading also starts a fresh in-memory session.

`index.html` loads the editable `styles.css`, `fixtures.js`, `model.js` and `app.js`. Open it directly to work on the source version. Run `node build.cjs` after source edits to regenerate the standalone HTML. No third-party assets or fonts are used; the cable illustration is inline SVG.

## What works

- Products, three-step PriceCompass, Orders & returns, Decision history.
- Competitive-start and kept-earnings ranking, minimum earnings units, explicit alternative selection, help-me-decide and a future-cash worksheet for release-cash decisions.
- Separate earnings, comparability, quote and cash gates. A Case B earnings pass never becomes overall approval while peers remain unresolved.
- Editable acquisition/outside costs, outcome mix, damage share, return charges, cash, reserve, upfront costs, stock, cap, MOQ, minimum, weight and route. Blank numeric inputs are unknown, not zero.
- Paid owned stock incurs economic cost but no new acquisition cash. An exact new-stock plan updates the total cap when new units are edited; manually reducing that cap below the plan blocks approval. MOQ applies only to new procurement.
- Material edits invalidate saved decisions. Cost, packaging, weight, route and return-fee edits also invalidate quote assumptions. Re-enabling the supplied quote checkbox is an explicit demo assumption, never a live refresh.
- Private-cost mode clears the active acquisition value and replaces precise earnings with thresholds. All input values and snapshots stay in memory by default; there is no localStorage, analytics or network transfer.
- Save test or hold, inspect dated snapshots, delete, explicit JSON export, disclosed private fields, and a printable decision sheet. Snapshots include private inputs entered at save time. Clearing the active cost does not silently erase prior snapshots; delete/reset/reload clears those.
- Three independent five-dispatch lifecycle fixtures, low exposure / weak response / higher-price branches, immediate economics review, and cable-plus-clips sensitivity.

## Origins and boundaries

The controlling specification is `01_BUILD_PROMPT.md` in the supplied handoff. Original historical cable anchors are buyer ₹189 / transfer ₹96 and buyer ₹210 / transfer ₹116, as documented in the supplied audit/manual. Exact entry mappings, comparable peers, acquisition/cash/outcome assumptions, Case B, bundle and lifecycle cohorts are supplied model fixtures, not measured seller outcomes. Case details keeps these origins accessible in the interface.

The earlier prototype’s intact-return outcome accounting informed the new model. Its old selection and cash rules were replaced where the new build prompt superseded them. The old prototype, 11 reference screenshots, deck, PDF and all other handoff files were preserved unchanged. The source ZIP was not modified.

This is a Meesho-inspired independent seller workspace. No production Meesho connection, current verified quotes, actual orders, automated listing edits, procurement or dispatch exists. Reserve is an editable stress policy, not an expense or universal platform fee. Buyer response and clip standalone sales remain missing evidence. Release-cash calculations compare entered assumptions; they do not certify demand or automatically approve a price test. Historical-only mode withholds current recommendations.

A real deployment would need authenticated, consented catalog/quote/settlement data, verified comparables, secure persistence, access controls and validated privacy practices. No live adoption, uplift or competition outcome is claimed.

## Tests

```
node test-model.cjs
node build.cjs
node test-browser.cjs
node test-final.cjs
```

The browser test needs Node 20+ and Playwright resolvable as `require('playwright')`, plus Google Chrome (it launches `channel: 'chrome'`). Dependencies are needed for tests only, never for the offline demo.

See `model-results.txt`, `browser-results.txt` and `VALIDATION.md` for actual results. Screenshots and tested sample JSON/print output are in `screenshots/`. Those samples contain demo fixture inputs, not user business data.

## File map

- `PriceCompass_Presentation_Demo.html`: self-contained runnable delivery.
- `index.html`, `styles.css`, `app.js`: editable interface.
- `fixtures.js`, `model.js`: supplied cases and central calculation functions.
- `build.cjs`: offline bundler.
- `test-model.cjs`, `test-browser.cjs`: numerical and real browser checks.
- `DEMO_SCRIPT.md`: 30-second and three-minute presentation paths.
- `VALIDATION.md`: coverage and limits.
