# PriceCompass presenter script

## Before presenting

Open `PriceCompass_Presentation_Demo.html` in Chrome, ideally at 1440×900 and 100% zoom. Reset through Demo controls and confirm. Start on Products. No internet is needed. Scroll naturally; all three steps are directly accessible. Saved decisions are in memory, so avoid reloading after saving.

## 30 seconds

**0–8 seconds:** Open original cable → Compare options. “A price suggestion becomes a decision when we add your costs, returns and cash limits.”

**8–18 seconds:** Show buyer ₹189, seller entry ₹165 and ₹26.85 expected earnings. Choose ₹210. “The alternative earns ₹43.85 per dispatch. We expose the trade-off instead of promising more sales.”

**18–30 seconds:** Review decision → Save test decision. Demo controls → Cost rises to ₹90. “An input change immediately invalidates the old decision. The low offer now loses ₹2.90; even the higher offer needs a fresh quote and an affordable stock plan.”

## Three minutes

| Time | Action | Say / show |
|---|---|---|
| 0:00–0:25 | Products → original cable → Compare options → Your decision | “Competitive start chooses the lowest eligible quoted offer: enter ₹165, buyer pays ₹189, expected earnings ₹26.85. Nine units require ₹810 retained cash. Nine is a cap, not a sales forecast.” |
| 0:25–0:50 | Choose alternative → ₹210 → Review decision → Save | “₹210 yields ₹43.85 per dispatch. The lower price needs more than 63.3% additional comparable mature dispatches to earn more in total. I choose the alternative, and save a local test—not a listing edit.” |
| 0:50–1:20 | Demo controls → Cost rises to ₹90; then MOQ nine at ₹90 cost | “₹189 is blocked at −₹2.90; ₹210 is +₹14.10 but requires renewed quote assumptions. Cash funds eight new units at ₹125 each. MOQ nine fails. Decision history marks the previous snapshot Needs review.” |
| 1:20–1:55 | Demo controls → Case B; Edit inputs → minimum unit Expected per dispatch → Compare | “A is the first ₹25-per-kept-order earnings pass. Change the denominator and B becomes the first pass. Neither is approved overall: peer attributes remain unresolved, and B/C sit outside the reference span.” |
| 1:55–2:15 | Demo controls → Case B · buy ten more → Edit inputs | “Six paid owned cables need ₹216 cash. Buying ten more needs ₹1,156, including reserve, against ₹700 received cash. A price can pass earnings while replenishment fails.” |
| 2:15–2:45 | Orders & returns → positive → pending → damaged | “These are three separate examples. Positive: ₹109 contribution, ₹54 cash and ₹55 recovered stock. Pending: ₹108 closed so far, two unresolved. Damaged: −₹113, so hold restock and investigate.” |
| 2:45–3:00 | Explore a bundle; change missing clips to 100% | “The bundle moves from ₹36.90 to ₹36.20 expected earnings. We still need buyer response and standalone clip sales before claiming incremental benefit. The seller approves every next step.” |

If short on time, omit the bundle and close on the three distinct lifecycle actions.

## Recovery cues

- Lost your place: Demo controls contains named presets; they edit real inputs.
- Quote unexpectedly blocked after an edit: this is intentional. The condition panel can explicitly re-enable supplied demo quote assumptions, but it never fetches a live quote.
- Case B save button disabled: intentional. Earnings eligibility is not overall recommendation eligibility.
- Privacy question: active costs and snapshots are memory-only. Export/print explicitly disclose included cost fields.
- Data-origin question: open Case details. Historical anchors, supplied model scenarios and calculated outcomes are distinguished there.
- Return to the beginning: Demo controls → Reset all inputs and history → confirm.
