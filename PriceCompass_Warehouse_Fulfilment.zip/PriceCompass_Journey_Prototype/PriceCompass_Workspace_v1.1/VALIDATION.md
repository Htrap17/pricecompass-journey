# Validation: seller workspace v1.1 (re-run 4 Oct 2026)

- `node test-model.cjs`: 21 numerical checks passed.
- `test-browser.cjs`: 23 browser checks passed.
- `test-final.cjs`: 7 final checks passed.

**Corrections in this build.** The return fee in the lifecycle and bundle calculations moves from ₹30 to ₹153:
- the positive cohort is now 4 kept + 1 RTO, giving +₹139 contribution and ₹84 cash;
- the damaged cohort gives −₹359;
- the bundle gives ₹24.60 vs ₹22.05.

Two other fixes:
- **Case B:** entries are now ₹94 / ₹104 / ₹123 / ₹142, and the first candidate to pass a per-dispatch minimum is C.
- **Hard-coded thresholds:** now 116.8% and 46.1%.

Test expectations were updated to these values. The earlier 21 / 23 counts belonged to the ₹30 build.

The primary demo is now `PriceCompass_Journey`.
