# PriceCompass with warehouse fulfilment

Updated 5 October 2026. Open **index.html** for the standalone prototype. There is no live Meesho connection or listing update.

## Three seller screens

1. **Product costs:** sample product, weight and current buyer price are loaded. Choose **Ship from my location** or **Use a warehouse**. Purchase cost, packing cost and minimum earnings start blank. Enter them or choose **Try sample values**.
2. **Suggested price:** see buyer price, payout after shipping and average earnings per shipped order, including returns and failed deliveries. Type a positive price with up to two decimals or use the comparison-range slider. Unsupported prices are labelled exploratory.
3. **Confirm your price:** optionally enter the actual net payout and total return charge including GST. Save the choice in this session. Refreshing clears it; saving does not update the listing.

## Fee rules

The default forward fee is **half the listed courier reverse shipping fee**, visibly labelled as a demo assumption. Add 18% GST to forward shipping, reverse shipping and warehouse delivered-order handling. Total customer-return cost is only reverse shipping plus GST; no warehouse return or delivered handling is added to returned orders.

Warehouse delivered handling is assumed additional to forward shipping. Its under/over-500-km zones are separate from the published shipping zones. Unknown distance, including exactly 500 km, produces a range. Unknown carrier spans the five supplied carriers. Reverse rates support weights through 2,500 g; higher weights require manual courier fees or a complete panel quote. Published forward estimates remain an option for seller-location shipping through 2,000 g.

A confirmed net payout and total return charge override all estimates directly. Shipping, warehouse fees and GST are not deducted again. Price, fulfilment and other shipping changes invalidate confirmation and mark saved choices for review.

The suggestion is the lowest supported whole-rupee price meeting the earnings target at the downside endpoint, with positive earnings required even at a zero target. No supported passing price means no suggestion. Cash reserve uses the highest total reverse charge. Saved choices cannot create confirmed approval to purchase stock.

## Sample results

Sample costs: ₹55 purchase, ₹5 packing, ₹10 minimum earnings. Weight: 250 g. Sample comparisons: ₹189 to ₹210.

The default seller-location scenario suggests **₹193**, with payout **₹95.65 to ₹102.73** and average earnings **₹10.08 to ₹17.52**. With warehouse fulfilment, unknown carrier and unknown distance, no supported price meets ₹10; the prototype gives that reason instead of inventing a recommendation.

At buyer price ₹189, Valmo seller-location shipping gives payout **₹98.73** and total return cost **₹180.54**. Valmo warehouse fulfilment over 500 km gives payout **₹79.85** and total return cost **₹171.10**. These are scenario estimates, not live quotes.

## More details and evidence

More details contains carrier, warehouse distance, calculation method, rates, GST breakdown, cash and stock, formulas and separate historical demonstrations. The screenshot's warehouse return handling, old-inventory and B2B reject rows are reference only. Warehouse inbound transport, old-inventory and rejected-stock costs are excluded from ordinary order earnings.

The supplied screenshot has no verified publication date. Fee tax treatment and return coverage follow the seller's clarification. See **PriceCompass_Journey/SHIPPING_SOURCE_NOTES.md**. Historic ledgers and once-only cohort updates remain unchanged.

## Delivery

- `index.html` and `PriceCompass_Journey/PriceCompass_Journey_Demo.html`: identical standalone pages.
- `PriceCompass_Journey/src/`: editable sources, build and tests.
- `PriceCompass_Journey/screenshots/warehouse-*.jpg`: current screenshots. Other sets show earlier revisions.
- `PriceCompass_Journey/VALIDATION.md`: current verification report.
- `DEMO_SCRIPT.md`: current walkthrough.
- `PriceCompass_Workspace_v1.1/`: original supplementary workspace, historical material.

Rebuild with `node PriceCompass_Journey/src/build.cjs`. Run `test-model.cjs`, `test-shipping.cjs`, `test-seller.cjs` and `test-warehouse.cjs` from that source directory. All **91 calculation checks passed**.

Current archive: **PriceCompass_Warehouse_Fulfilment.zip**, next to this folder. Publishing remains separate. The standalone page has no external runtime dependencies; direct offline file opening remains a manual check because the app browser blocks file URLs.
