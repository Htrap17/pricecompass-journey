/* PriceCompass one-SKU journey model. Pure functions; no network, no storage.
   Accounting (per dispatch, rupees):
     kept   = T - C - o
     RTO    = -o - rtoFee              (intact stock returns at acquisition value C, so C nets out)
     return = -o - R - delta*C         (reverse fee once; unsellable share loses C)
     m = k(T - C) - o - qR - q*delta*C (with rtoFee = 0)
   Contribution = net receipts + recoverable stock value - acquisition - outside costs.
   The transfer T already nets shipping and platform deductions, so they are never subtracted again.
   Seller output GST, input credit and TCS/TDS are not modelled: T is taken as the panel shows it. */
(function (root) {
  'use strict';
  const ok = x => typeof x === 'number' && Number.isFinite(x) && x >= 0;
  const r2 = x => Math.round(x * 100 + (x >= 0 ? 1e-6 : -1e-6)) / 100; // half away from zero, display rounding
  const shares = s => ({ k: s.mix.k / 100, r: s.mix.r / 100, q: s.mix.q / 100 });

  function errors(s) {
    const e = [];
    if (!s.costs.private && !ok(s.costs.C)) e.push('Acquisition cost is blank: blank is unknown, not zero.');
    if (!ok(s.costs.o)) e.push('Outside cost per dispatch is blank.');
    if (!ok(s.fees.R)) e.push('Return (reverse) fee is unknown for this weight band.');
    if (!ok(s.fees.delta) || s.fees.delta > 100) e.push('Damage share must be 0 to 100%.');
    if (![s.mix.k, s.mix.r, s.mix.q].every(ok) || Math.abs(s.mix.k + s.mix.r + s.mix.q - 100) > 1e-6) e.push('Kept + RTO + return must total 100%.');
    if (!ok(s.seller.cash)) e.push('Available cash is blank.');
    for (const key of ['cap', 'moq', 'owned']) if (!Number.isInteger(s.seller[key]) || s.seller[key] < 0) e.push(key + ' must be a whole number.');
    if (s.seller.cap === 0) e.push('Seller cap must be at least 1.');
    return e;
  }

  function perDispatch(s, quote, over) {
    const v = Object.assign({ C: s.costs.C, o: s.costs.o, R: s.fees.R, delta: s.fees.delta / 100, rtoFee: s.fees.rtoFee }, shares(s), over || {});
    const T = quote.transfer;
    const kept = T - v.C - v.o, rto = -v.o - v.rtoFee, ret = -v.o - v.R - v.delta * v.C;
    const expected = v.k * kept + v.r * rto + v.q * ret;
    const formula = v.k * (T - v.C) - v.o - v.r * v.rtoFee - v.q * v.R - v.q * v.delta * v.C; // same number, written as m
    return { kept, rto, ret, expected, formula };
  }

  /* Highest acquisition cost at which the candidate still meets the seller minimum g. */
  function ceiling(s, quote) {
    const { k, r, q } = shares(s), d = s.fees.delta / 100, o = s.costs.o, R = s.fees.R, g = s.seller.g;
    const positive = (k * quote.transfer - o - r * s.fees.rtoFee - q * R) / (k + q * d);
    const minimum = s.seller.denominator === 'kept'
      ? quote.transfer - o - g
      : (k * quote.transfer - o - r * s.fees.rtoFee - q * R - g) / (k + q * d);
    return { positive, minimum: Math.min(positive, minimum) };
  }

  const reserve = s => Math.floor(s.fees.R * s.seller.reservePct / 100); // stress-policy funding held, not an expense

  function funding(s) {
    const res = reserve(s);
    return { reserve: res, perNew: s.costs.C + s.costs.o + res, perOwned: s.costs.o + res };
  }

  /* Cash to keep available for the capped batch. A cap limits exposure; it is not a forecast. */
  function procurement(s) {
    if (s.costs.private || !ok(s.costs.C)) return { known: false, blocked: true, reason: 'Private or blank cost: cash cannot be verified.' };
    const f = funding(s), sel = s.seller;
    const ownedUsed = Math.min(sel.owned, sel.cap);
    let newUnits = sel.cap - ownedUsed;
    const reasons = [];
    if (newUnits > 0 && newUnits < sel.moq) {
      reasons.push(`Supplier MOQ ${sel.moq} forces ${sel.moq} new units, above your cap of ${sel.cap}.`);
      newUnits = sel.moq;
    }
    const units = ownedUsed + newUnits;
    const need = newUnits * f.perNew + ownedUsed * f.perOwned;
    if (need > sel.cash) reasons.push(`Needs ₹${need} but ₹${sel.cash} is available.`);
    let fallback = null;
    if (reasons.length) {
      for (let n = sel.cap; n >= 1; n--) {
        const own = Math.min(sel.owned, n), buy = n - own;
        if (buy > 0 && buy < sel.moq) continue;
        const c = buy * f.perNew + own * f.perOwned;
        if (c <= sel.cash) { fallback = { units: n, need: c }; break; }
      }
    }
    const affordableMax = Math.floor((sel.cash - ownedUsed * f.perOwned) / f.perNew) + ownedUsed;
    const blocked = reasons.length > 0;
    return { known: true, units, newUnits, ownedUsed, need, reserveHeld: units * f.reserve, funding: f, blocked, reasons, fallback, affordableMax,
      reason: blocked ? reasons.join(' ') : `${units} units fit: keep ₹${need} available (₹${units * f.reserve} of it is reserve, not an expense).` };
  }

  function comparables(s) {
    const list = s.mode === 'real' ? s.audit : s.register;
    const q = list.filter(x => x.status === 'accepted').map(x => x.price).sort((a, b) => a - b);
    const n = q.length;
    const median = n ? (n % 2 ? q[(n - 1) / 2] : (q[n / 2 - 1] + q[n / 2]) / 2) : null;
    return { source: s.mode === 'real' ? 'audit' : 'register', list, n, min: n ? q[0] : null, max: n ? q[n - 1] : null, median,
      evidence: n === 0 ? 'none' : n === 1 ? 'weak' : 'range' };
  }

  /* Supported = at least one qualified alternative at or above the candidate's buyer price. */
  const supported = (cmp, buyer) => cmp.n > 0 && buyer <= cmp.max;

  function stressCases(s) {
    const Rmax = s.fees.Rrange[1];
    const cases = [
      ['Base', {}],
      [`Highest listed reverse fee ₹${Rmax}`, { R: Rmax }],
      ['COD-like mix 73 / 19 / 8', { k: .73, r: .19, q: .08 }],
      [`Stress: kept 77.5, RTO 7.5, return 15, fee ₹${Rmax}`, { k: .775, r: .075, q: .15, R: Rmax }],
      ['Every return unsellable (δ 100%)', { delta: 1 }],
      ['Acquisition cost rises to ₹90', { C: 90 }]
    ];
    return cases.map(([label, over]) => ({ label, values: s.quotes.map(q => r2(perDispatch(s, q, over).expected)) }));
  }

  function sensitivity(s, quote) {
    const { k, r, q } = shares(s), d = s.fees.delta / 100, T = quote.transfer, C = s.costs.C, o = s.costs.o, g = s.seller.g;
    const cMax = ceiling(s, quote).minimum;
    const qFlip = ((1 - r) * (T - C) - o - r * s.fees.rtoFee - g) / (T - C + s.fees.R + d * C);
    const rFlip = q > 0 ? (k * (T - C) - o - r * s.fees.rtoFee - q * d * C - g) / q : Infinity;
    const items = [
      { name: 'Acquisition cost C', now: C, flip: cMax, rel: (cMax - C) / C, text: `flips above ₹${r2(cMax)} (+${Math.round((cMax - C) / C * 100)}%)` },
      { name: 'Return share', now: q * 100, flip: qFlip * 100, rel: (qFlip - q) / q, text: `flips above ${r2(qFlip * 100)}% (now ${r2(q * 100)}%)` },
      { name: 'Reverse fee R', now: s.fees.R, flip: rFlip, rel: (rFlip - s.fees.R) / s.fees.R, text: `flips above ₹${r2(rFlip)}` }
    ].sort((a, b) => a.rel - b.rel);
    return items;
  }

  function evaluate(s) {
    const errs = errors(s);
    const cmp = comparables(s);
    const costKnown = !s.costs.private && ok(s.costs.C);
    const quoteOk = s.mode === 'scenario' && s.quoteValid;
    const rows = s.quotes.map(q => {
      const e = costKnown && !errs.length ? perDispatch(s, q) : null;
      const ceil = !errs.length || s.costs.private ? ceiling(s, q) : null;
      const metric = e ? (s.seller.denominator === 'kept' ? e.kept : e.expected) : null;
      const passesMin = e ? metric >= s.seller.g : false;
      const positive = e ? e.expected > 0 : false;
      const sup = supported(cmp, q.buyer);
      return Object.assign({}, q, { econ: e, ceiling: ceil, passesMin, positive, supported: sup, quoteOk,
        passes: !!(e && passesMin && positive && quoteOk) });
    });
    const passing = rows.filter(x => x.passes && (cmp.evidence === 'none' || x.supported));
    const byBuyer = [...passing].sort((a, b) => a.buyer - b.buyer);
    const byEarn = [...passing].sort((a, b) => b.econ.expected - a.econ.expected);
    const choice = s.seller.objective === 'earnings' ? byEarn[0] || null : byBuyer[0] || null;
    const alternative = choice ? (s.seller.objective === 'earnings' ? byBuyer.find(x => x !== choice) : byEarn.find(x => x !== choice)) || null : null;
    const proc = procurement(s);
    const reasons = [...errs];
    if (s.mode === 'real') {
      reasons.push('No current quote: the ₹189 / ₹96 and ₹210 / ₹116 pairs are ~1-year-old panel records.');
      reasons.push(`0 qualified comparables in the 28 Sep 2026 audit (5 asks, all excluded).`);
      reasons.push('Acquisition cost ₹55, outside cost ₹5 and supplier MOQ are not confirmed by the seller.');
    } else {
      if (!s.quoteValid) reasons.push('Quotes are invalid: product, weight or fulfilment changed. Re-capture entry → buyer → transfer.');
      if (!costKnown) reasons.push('Cost kept private: only cost ceilings are shown; no profit or cash approval.');
      if (cmp.evidence === 'none' && !s.weakAck) reasons.push('No qualified comparable: a weak-evidence test needs your explicit acknowledgement, otherwise HOLD.');
      if (!choice && costKnown && s.quoteValid && !errs.length) reasons.push('No quoted candidate meets the earnings check: repair costs or hold.');
      rows.filter(x => x.passes && cmp.evidence !== 'none' && !x.supported).forEach(x => reasons.push(`₹${x.buyer} is above every qualified alternative (max ₹${cmp.max}): unsupported.`));
      if (proc.blocked && costKnown) reasons.push('Procurement: ' + proc.reason);
    }
    let status;
    if (errs.length || s.mode === 'real' || !s.quoteValid || !costKnown || !choice || (cmp.evidence === 'none' && !s.weakAck)) status = 'HOLD';
    else if (proc.blocked) status = 'PRICE PASSES · PROCUREMENT HOLD';
    else if (cmp.evidence === 'none') status = 'WEAK-EVIDENCE TEST';
    else status = 'READY FOR YOUR APPROVAL';
    return { rows, cmp, choice, alternative, proc, status, reasons, errors: errs,
      stress: costKnown && !errs.length ? stressCases(s) : null,
      sensitive: choice ? sensitivity(s, choice) : null };
  }

  /* Ledger for the review cohort: contribution, cash and inventory kept apart. */
  function ledger(records, s) {
    const C = s.costs.C, o = s.costs.o;
    const rows = records.map(x => {
      if (x.status === 'pending') return Object.assign({}, x, { contribution: null, cash: -C - o, stockValue: 0 });
      const stockValue = (x.status === 'rto' || x.status === 'return') && x.stock === 'intact' ? C : 0;
      const cash = x.settled - x.reverse - C - o;
      return Object.assign({}, x, { contribution: cash + stockValue, cash, stockValue });
    });
    const closed = rows.filter(x => x.status !== 'pending');
    const count = st => rows.filter(x => x.status === st).length;
    return {
      rows,
      kept: count('kept'), rto: count('rto'), returned: count('return'), pending: count('pending'), closed: closed.length,
      settlements: closed.reduce((a, x) => a + x.settled, 0),
      reverseCharges: closed.reduce((a, x) => a + x.reverse, 0),
      contribution: closed.reduce((a, x) => a + x.contribution, 0),
      cash: rows.reduce((a, x) => a + x.cash, 0),
      intactUnits: closed.filter(x => x.stockValue > 0).length,
      inventoryValue: closed.reduce((a, x) => a + x.stockValue, 0),
      damagedReturns: rows.filter(x => x.status === 'return' && x.stock === 'damaged').length,
      observedReverse: closed.filter(x => x.reverse > 0).map(x => x.reverse)
    };
  }

  /* Blend prior mix with closed outcomes. K is an uncalibrated prior weight (pseudo-dispatches). */
  function update(s, L, K) {
    const before = { k: s.mix.k, r: s.mix.r, q: s.mix.q, R: s.fees.R, delta: s.fees.delta, reserve: reserve(s) };
    const n = L.closed;
    const kk = (K * s.mix.k / 100 + L.kept) / (K + n) * 100, rr = (K * s.mix.r / 100 + L.rto) / (K + n) * 100;
    const qq = 100 - kk - rr;
    const R = L.observedReverse.length ? L.observedReverse.reduce((a, b) => a + b, 0) / L.observedReverse.length : s.fees.R;
    const delta = L.returned ? (L.damagedReturns / L.returned) * 100 : s.fees.delta;
    const next = JSON.parse(JSON.stringify(s));
    next.mix = { k: kk, r: rr, q: qq, source: 'blended' };
    next.fees.R = R; next.fees.delta = delta;
    next.versions.outcomes += 1; next.versions.fees += (R !== s.fees.R || delta !== s.fees.delta) ? 1 : 0;
    const after = { k: kk, r: rr, q: qq, R, delta, reserve: reserve(next) };
    return { K, before, after, next };
  }

  function nextDecision(s, L, ev) {
    const f = funding(s);
    const bank = s.seller.cash + L.cash;
    const available = bank - L.pending * f.reserve;
    const relist = L.intactUnits * f.perOwned;
    const reorderUnits = Math.max(0, s.seller.cap - L.intactUnits);
    const reorder = reorderUnits * f.perNew + relist;
    const current = ev.rows.find(x => x.buyer === 189) || ev.rows[0];
    const keepPrice = current && current.econ && current.econ.expected >= s.seller.g;
    return {
      bank, available, relist, reorderUnits, reorder,
      price: keepPrice ? `Keep ₹${current.buyer}: expected ₹${r2(current.econ.expected).toFixed(2)} per dispatch still meets the ₹${s.seller.g} minimum. No price change is forced.`
        : `₹${current.buyer} no longer meets the minimum: review the price with a fresh quote, or hold.`,
      stock: L.pending > 0
        ? `Relist the ${L.intactUnits} intact units now (keep ₹${relist} available). Hold new procurement until ${L.pending} pending dispatch matures and the quote is re-captured; then a ${reorderUnits}-unit reorder needs ₹${reorder} against ₹${available} available.`
        : `A ${reorderUnits}-unit reorder needs ₹${reorder} against ₹${available} available.`,
      fits: reorder <= available
    };
  }

  /* Change control: every edit bumps a version; snapshots record versions; quotes depend on product + fulfilment. */
  const QUOTE_DEPS = ['product'];
  function change(s, area, reason, mutate) {
    mutate(s);
    s.versions[area] += 1;
    const quoteHit = QUOTE_DEPS.includes(area);
    if (quoteHit) s.quoteValid = false;
    const stale = s.snapshots.filter(x => x.state === 'Current');
    stale.forEach(x => { x.state = 'Needs review'; x.why = (x.why ? x.why + '; ' : '') + reason; });
    s.log.unshift({ area, reason, quotes: quoteHit ? 'invalidated' : 'still valid', snapshots: stale.length });
    return { quoteHit, invalidated: stale.length };
  }

  function snapshot(s, ev, action, time) {
    const snap = { id: s.snapshots.length + 1, time: time || new Date().toISOString(), action, state: 'Current', why: '',
      versions: Object.assign({}, s.versions), status: ev.status,
      choice: ev.choice ? { entry: ev.choice.entry, buyer: ev.choice.buyer, transfer: ev.choice.transfer, expected: r2(ev.choice.econ.expected) } : null,
      units: ev.proc.units, cashToKeep: ev.proc.need };
    s.snapshots.unshift(snap);
    return snap;
  }

  const api = { errors, perDispatch, ceiling, reserve, funding, procurement, comparables, supported, stressCases, sensitivity, evaluate, ledger, update, nextDecision, change, snapshot, r2 };
  if (typeof module !== 'undefined') module.exports = api; else root.PCJourney = api;
})(globalThis);
