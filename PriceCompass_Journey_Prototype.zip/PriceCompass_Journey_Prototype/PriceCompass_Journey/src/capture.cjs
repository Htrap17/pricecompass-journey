const { chromium } = require('playwright'), path = require('node:path');
const FILE = 'file://' + path.join(__dirname, '..', 'PriceCompass_Journey_Demo.html'), OUT = path.join(__dirname, '..', 'shots');
(async () => {
  const b = await chromium.launch();
  const shoot = async (w, h, fn, sel, name) => { const p = await b.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 2 }); await p.goto(FILE); await fn(p); await p.locator(sel).first().screenshot({ path: path.join(OUT, name + '.png') }); await p.close(); };
  await shoot(1700, 900, async p => {}, '#strip', 'strip');
  await shoot(1050, 900, async p => { await p.click('[data-step="decision"]'); }, '.card', 'card');
  await shoot(1050, 900, async p => { await p.click('[data-step="economics"]'); }, 'main', 'econ');
  await shoot(1050, 900, async p => { await p.click('[data-step="review"]'); }, 'main', 'review');
  await shoot(1050, 900, async p => { await p.click('[data-step="decision"]'); await p.click('[data-action="approve"]'); await p.click('[data-demo="comparable"]'); }, '#change', 'demo1');
  await shoot(1050, 900, async p => { await p.click('[data-step="decision"]'); await p.click('[data-action="approve"]'); await p.click('[data-demo="returns"]'); }, '#change', 'demo2');
  await shoot(1050, 900, async p => { await p.click('[data-demo="cash"]'); }, '#change', 'demo3');
  await shoot(1440, 900, async p => { await p.click('[data-mode="real"]'); await p.click('[data-step="decision"]'); }, 'body', 'realhold');
  await b.close();
})();
