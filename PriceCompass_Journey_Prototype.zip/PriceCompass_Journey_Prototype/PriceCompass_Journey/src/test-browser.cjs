const { chromium } = require('playwright'), assert = require('node:assert/strict'), path = require('node:path');
const FILE = 'file://' + path.join(__dirname, '..', 'PriceCompass_Journey_Demo.html'), SHOTS = path.join(__dirname, '..', 'screenshots');
(async () => {
  const b = await chromium.launch({ headless: true }), p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [], external = []; p.on('pageerror', x => errors.push(x.message)); p.on('console', x => { if (x.type() === 'error') errors.push(x.text()); });
  p.on('request', r => { if (/^https?:/.test(r.url())) external.push(r.url()); });
  let n = 0; const t = async (name, f) => { await f(); console.log('PASS ' + name); n++; };
  const ev = () => p.evaluate(() => PCJ.evaluate()), st = () => p.evaluate(() => PCJ.getState());
  const shot = async name => p.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: true });
  const main = () => p.locator('main').innerText(), change = () => p.locator('#change').innerText();
  await p.goto(FILE);
  await t('Opens offline on product truth with gaps shown', async () => { assert.match(await main(), /Unresolved/); assert.match(await main(), /Not recorded/); await shot('j01-product'); });
  await t('Real record is a justified HOLD with three reasons', async () => {
    await p.click('[data-mode="real"]'); await p.click('[data-step="decision"]'); const e = await ev(); assert.equal(e.status, 'HOLD'); assert.equal(e.cmp.n, 0);
    assert.match(await main(), /0 qualified comparables/); await shot('j02-real-hold');
  });
  await t('Audit shows five dated exclusions and no comparable range', async () => { await p.click('[data-step="alternatives"]'); assert.match(await main(), /0 qualified/); assert.match(await main(), /not willingness to pay/i); await shot('j03-real-alternatives'); });
  await t('Scenario chain reaches ₹189 with ₹210 alternative', async () => {
    await p.click('[data-mode="scenario"]'); await p.click('[data-step="decision"]'); const e = await ev();
    assert.equal(e.status, 'READY FOR YOUR APPROVAL'); assert.equal(e.choice.buyer, 189); assert.equal(e.alternative.buyer, 210);
    const m = await main(); assert.match(m, /₹14\.55/); assert.match(m, /₹810/); assert.match(m, /Acquisition cost C/i); assert.match(m, /Review trigger/i); await shot('j04-decision-card');
  });
  await t('Quotes and economics steps show estimates and formula', async () => {
    await p.click('[data-step="quotes"]'); assert.match(await main(), /110\.19/); await shot('j05-quotes');
    await p.click('[data-step="economics"]'); const m = await main(); assert.match(m, /2\.16838×/); assert.match(m, /46\.117%/); assert.match(m, /−₹15\.20/); await shot('j06-economics');
    await p.click('[data-step="constraints"]'); assert.match(await main(), /reserve held, not an expense/); await shot('j07-cash');
  });
  await t('Approve saves a snapshot only', async () => { await p.click('[data-step="decision"]'); await p.click('[data-action="approve"]'); const s = await st(); assert.equal(s.snapshots.length, 1); assert.equal(s.snapshots[0].state, 'Current'); });
  await t('Demo 1: comparable fails → ₹210 unsupported, snapshot needs review, quote valid', async () => {
    await p.click('[data-demo="comparable"]'); const e = await ev(), s = await st();
    assert.equal(e.alternative, null); assert.equal(e.choice.buyer, 189); assert.equal(s.snapshots[0].state, 'Needs review'); assert.equal(s.quoteValid, true);
    const c = await change(); assert.match(c, /Alternative: ₹210 → none/); assert.match(c, /still valid/); await shot('j08-demo-comparable');
  });
  await t('Demo 2: return cost and damage rise → recalculated, explained', async () => {
    await p.click('[data-demo="reset"]'); await p.click('[data-step="decision"]'); await p.click('[data-action="approve"]'); await p.click('[data-demo="returns"]');
    const e = await ev(), s = await st(); assert.equal(Math.round(e.rows[0].econ.expected * 100), 1060); assert.equal(s.snapshots[0].state, 'Needs review'); assert.equal(s.quoteValid, true);
    const c = await change(); assert.match(c, /₹14\.55 → ₹10\.60/); assert.match(c, /₹810 → ₹837/); await shot('j09-demo-returns');
  });
  await t('Demo 3: cash and MOQ block procurement while the price passes', async () => {
    await p.click('[data-demo="reset"]'); await p.click('[data-demo="cash"]'); const e = await ev();
    assert.equal(e.status, 'PRICE PASSES · PROCUREMENT HOLD'); assert.equal(e.proc.need, 900); assert.match(await change(), /procurement blocked/); await shot('j10-demo-cash');
  });
  await t('Weight crossing the band invalidates quotes; requote restores validity', async () => {
    await p.click('[data-demo="reset"]'); await p.click('[data-demo="weight"]'); let s = await st(); assert.equal(s.quoteValid, false); assert.equal((await ev()).status, 'HOLD');
    assert.match(await change(), /invalidated/); await shot('j11-demo-weight');
    await p.click('[data-action="requote"]'); s = await st(); assert.equal(s.quoteValid, true); assert.equal((await ev()).status, 'HOLD');
  });
  await t('Review: ledger, K=20 uncalibrated update, next decision keeps price', async () => {
    await p.click('[data-demo="reset"]'); await p.click('[data-step="review"]'); const m = await main();
    for (const re of [/₹41/, /−₹129/, /2 units · ₹110/, /uncalibrated/, /82\.14%/, /₹165/, /₹11/, /₹27\.43/, /Keep ₹189/, /₹727/]) assert.match(m, re);
    await shot('j12-review');
    await p.click('[data-action="apply"]'); const s = await st(); assert.equal(s.versions.outcomes, 2); assert.equal(Math.round(s.fees.R), 165);
    assert.equal((await ev()).choice.buyer, 189); await shot('j13-review-applied');
  });
  await t('Private cost shows ceilings only', async () => {
    await p.click('[data-demo="reset"]'); await p.click('[data-step="product"]'); await p.check('#in-private'); await p.click('[data-step="economics"]');
    assert.match(await main(), /no profit figure/); assert.match(await main(), /₹72\.12/); assert.equal((await ev()).status, 'HOLD');
  });
  await t('No page errors and no external requests', async () => { assert.deepEqual(errors, []); assert.deepEqual(external, []); });
  console.log(`${n} journey browser checks passed.`); await b.close();
})().catch(e => { console.error(e); process.exit(1); });
