'use strict';
/* PriceCompass one-SKU journey: interface. All state is in memory; nothing leaves the page. */
const M = PCJourney, P = PCRecord;
let S = P.base(), step = 'product', review = null, K = 20, lastChange = null, noteMsg = '';
const $ = id => document.getElementById(id);
const esc = x => String(x).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const inr = x => typeof x === 'number' && Number.isFinite(x)
  ? (x < 0 ? '−' : '') + '₹' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: Number.isInteger(M.r2(x)) ? 0 : 2, maximumFractionDigits: 2 }).format(Math.abs(M.r2(x)))
  : '–';
const inr2 = x => typeof x === 'number' ? (x < 0 ? '−' : '') + '₹' + Math.abs(M.r2(x)).toFixed(2) : '–';
const pct = x => M.r2(x) + '%';
const tag = (t, cls = '') => `<span class="tag ${cls}">${esc(t)}</span>`;
const SRC = { audit: ['Observed · audit 28 Sep 2026', 'obs'], panel: ['Historical panel', 'hist'], panelFee: ['Panel / fee page', 'hist'], derived: ['Estimate (formula)', 'est'],
  assumed: ['Assumption', 'asm'], generated: ['Generated register', 'gen'], synthetic: ['Synthetic test cohort', 'gen'], calc: ['Calculation', 'calc'], missing: ['Missing', 'miss'] };
const src = k => tag(SRC[k][0], SRC[k][1]);
const STEPS = [['product', '1', 'Product truth'], ['alternatives', '2', 'Qualified alternatives'], ['quotes', '3', 'Candidate quotes'], ['economics', '4', 'Outcome economics'],
  ['constraints', '5', 'Cash and stock'], ['decision', '6', 'Decision card'], ['review', '7', 'Review and learn']];
const ev = () => M.evaluate(S);

function strip(e) {
  const prodGaps = [S.product.conductor === null, S.product.packedWeightSource !== 'measured', S.product.offlinePrice === null].filter(Boolean).length;
  const st = {
    product: `${prodGaps} gaps`,
    alternatives: `${e.cmp.n} qualified${S.mode === 'real' ? ' (audit)' : ' (register)'}`,
    quotes: S.mode === 'real' ? 'not current' : S.quoteValid ? `valid · v${S.versions.quotes}` : 'INVALID',
    economics: e.choice ? inr(e.choice.econ.expected) + ' / dispatch' : (e.rows[0].econ ? inr(e.rows[0].econ.expected) : 'ceilings only'),
    constraints: e.proc.known ? (e.proc.blocked ? 'blocked' : `${e.proc.units} units · ${inr(e.proc.need)}`) : 'unverified',
    decision: e.status,
    review: review ? `v${S.versions.outcomes} updated` : 'not yet'
  };
  const bad = { quotes: S.mode === 'real' || !S.quoteValid, constraints: e.proc.blocked, decision: e.status !== 'READY FOR YOUR APPROVAL', alternatives: e.cmp.n === 0 };
  return `<ol class="strip">${STEPS.map(([id, n, name]) => `<li><button data-step="${id}" class="${step === id ? 'on' : ''} ${bad[id] ? 'warn' : ''}"><b>${n} · ${name}</b><span>${esc(st[id])}</span></button></li>`).join('<li class="arr" aria-hidden="true">→</li>')}</ol>`;
}

function banner(e) {
  const real = S.mode === 'real';
  return `<div class="mode ${real ? 'real' : 'scen'}"><b>${real ? 'REAL RECORD' : 'PROTOTYPE SCENARIO'}</b> ${real
    ? 'Only observed evidence is used: the dated audit and the historical panel. Assumed costs and the generated register are switched off.'
    : 'The historical panel pair is treated as a current quote and the generated register M1–M6 as qualified offers. Both are labelled assumptions, not live Meesho data.'}
    <span class="status s-${e.status.split(' ')[0].toLowerCase()}">${esc(e.status)}</span></div>`;
}

function changeBox() {
  if (!lastChange) return '';
  return `<section class="change" role="status"><h3>What just changed · ${esc(lastChange.title)}</h3><ul>${lastChange.lines.map(l => `<li>${l}</li>`).join('')}</ul></section>`;
}

function productView() {
  const p = S.product;
  const row = (f, v, s, note = '') => `<tr><th>${f}</th><td>${v}</td><td>${s}</td><td class="muted">${note}</td></tr>`;
  return `<h2>Product truth · ${esc(p.sku)} · version ${p.version}</h2><p class="lead">What exactly will be shipped. A photo match finds candidates; it does not prove equivalence.</p>
  <table class="grid"><thead><tr><th>Field</th><th>Value</th><th>Source</th><th>Note</th></tr></thead><tbody>
  ${row('Unit and specs', esc(p.title + ', ' + p.unit), src('panel'), 'Listing title in the historical panel')}
  ${row('Conductor', p.conductor ? esc(p.conductor) : '<b class="neg">Unresolved</b>', src('missing'), 'Copper vs copper-clad aluminium changes comparability')}
  ${row('Pack', esc(p.pack), src('panel'), '')}
  ${row('Packed weight', p.packedWeight + ' g', src(p.packedWeightSource === 'measured' ? 'calc' : 'assumed'), `Fee band used: up to ${p.weightBand} g. Crossing the band invalidates the quote and the return fee.`)}
  ${row('Fulfilment', esc(p.fulfilment), src('assumed'), 'Warehouse fees not in scope for v1')}
  ${row('Offline price', p.offlinePrice ? inr(p.offlinePrice) : '<b class="neg">Not recorded</b>', src('missing'), 'Gap: ask the seller')}
  ${row('Acquisition cost C', S.costs.private ? 'Private' : inr(S.costs.C), src('assumed'), 'Seller-private; ceiling shown if withheld')}
  ${row('Outside cost o', inr(S.costs.o) + ' per dispatch', src('assumed'), 'Packing and preparation, paid on every dispatch')}
  </tbody></table>
  <div class="row"><label class="field">Packed weight (g)<input type="number" id="in-weight" value="${p.packedWeight}" min="1"></label>
  <label class="field">Acquisition cost C (₹)<input type="number" id="in-C" value="${S.costs.private ? '' : S.costs.C ?? ''}" min="0" step="any" ${S.costs.private ? 'disabled' : ''}></label>
  <label class="check"><input type="checkbox" id="in-private" ${S.costs.private ? 'checked' : ''}> Keep my cost private (show ceilings only)</label></div>`;
}

function alternativesView(e) {
  const real = S.mode === 'real';
  const list = (rows, editable) => `<table class="grid"><thead><tr><th>ID</th><th>Offer</th><th>Buyer price</th><th>Status</th><th>Reason</th>${editable ? '<th></th>' : ''}</tr></thead><tbody>${rows.map((x, i) =>
    `<tr class="${x.status}"><td>${x.id}</td><td>${esc(x.what || 'Register row')}</td><td>${inr(x.price)}</td><td>${x.status === 'accepted' ? '✓ qualified' : '✕ excluded'}</td><td>${esc(x.reason)}</td>${editable ? `<td>${x.status === 'accepted' ? `<button class="mini" data-fail="${i}">Fails re-check</button>` : ''}</td>` : ''}</tr>`).join('')}</tbody></table>`;
  const c = e.cmp;
  return `<h2>Qualified alternatives</h2><p class="lead">What this buyer can buy instead: same spec, in stock, independent seller, same buyer context, same date. Every exclusion is logged. <b>A comparable range is not willingness to pay.</b></p>
  <h3>Observed: public audit, 28 Sep 2026 ${src('audit')}</h3>${list(S.audit, false)}
  <p class="callout ${real ? 'bad' : ''}">Audit result: <b>0 qualified</b> of 5 asks. With no qualified match the real record can only support a justified HOLD, or a weak-evidence test the seller explicitly accepts.</p>
  ${real ? '' : `<h3>Prototype register M1–M6 ${src('generated')}</h3>${list(S.register, true)}`}
  <div class="kpis"><div><b>${c.n}</b><span>qualified (${real ? 'audit' : 'register'})</span></div><div><b>${c.n ? inr(c.min) + '–' + inr(c.max) : 'none'}</b><span>qualified range, not demand</span></div><div><b>${c.median !== null ? inr(c.median) : '–'}</b><span>median: reference only, no quote</span></div></div>
  ${real ? '' : `<label class="check"><input type="checkbox" id="in-weak" ${S.weakAck ? 'checked' : ''}> If nothing qualifies, I accept a capped weak-evidence test</label>`}`;
}

function quotesView(e) {
  return `<h2>Candidate quotes · entry → buyer pays → kept-order transfer</h2><p class="lead">Each candidate is a versioned map. Shipping and platform deductions sit between buyer price and transfer, so they are counted once, inside T.</p>
  <table class="grid"><thead><tr><th>Candidate</th><th>Seller enters</th><th>Buyer pays</th><th>Transfer T</th><th>Basis</th><th>Quote state</th></tr></thead><tbody>${e.rows.map(r =>
    `<tr><td>${esc(r.label)}</td><td>${inr(r.entry)} <small class="muted">(estimate ${inr(r.entryEstimate)})</small> ${src('derived')}</td><td>${inr(r.buyer)}</td><td>${inr(r.transfer)}</td><td>${src('panel')}</td><td>${S.mode === 'real' ? '<b class="neg">Not current</b>' : S.quoteValid ? `Valid · v${S.versions.quotes} (assumed current)` : '<b class="neg">Invalid: requote</b>'}</td></tr>`).join('')}</tbody></table>
  <p class="formula">S = (B − T) ÷ 1.18 = ₹78.81 at ₹189, ₹79.66 at ₹210 · entry = T + 0.18S = ₹110.19 / ₹130.34. The two shipping values differ by ₹0.85: a documented spec-vs-arithmetic conflict, so entries are estimates within about ₹1.</p>
  ${S.mode === 'scenario' && !S.quoteValid ? `<button data-action="requote" class="primary">Re-capture quotes (demo assumption: same values, new version)</button>` : ''}
  <p class="muted">The historical panel already suggested ₹189. PriceCompass did not discover it; it adds the economics, the cash cap and the HOLD when evidence is missing.</p>`;
}

function economicsView(e) {
  const k = S.mix;
  const rows = e.rows.map(r => r.econ ? `<tr><td>${inr(r.buyer)} → ${inr(r.transfer)}</td><td>${inr(r.econ.kept)}</td><td>${inr(r.econ.rto)}</td><td>${inr(r.econ.ret)}</td><td><b>${inr(r.econ.expected)}</b></td><td>C ≤ ${inr(r.ceiling.minimum)}</td><td>${r.passes ? '✓' : '✕'}${S.mode === 'scenario' && e.cmp.n && !r.supported ? ' · unsupported' : ''}</td></tr>`
    : `<tr><td>${inr(r.buyer)} → ${inr(r.transfer)}</td><td colspan="4" class="muted">Cost private or blank: no profit figure</td><td>C ≤ ${r.ceiling ? inr(r.ceiling.minimum) : '–'}</td><td>–</td></tr>`).join('');
  const st = e.stress ? `<h3>Labelled stress cases · expected ₹ per dispatch ${src('calc')}</h3><table class="grid"><thead><tr><th>What-if (not a confidence interval)</th>${S.quotes.map(q => `<th>${inr(q.buyer)}</th>`).join('')}</tr></thead><tbody>${e.stress.map(x => `<tr><td>${esc(x.label)}</td>${x.values.map(v => `<td class="${v < 0 ? 'neg' : ''}">${inr(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>` : '';
  return `<h2>Outcome economics per dispatch</h2><p class="lead">Kept ${pct(k.k)} · RTO ${pct(k.r)} · return ${pct(k.q)} ${src(k.source === 'blended' ? 'calc' : 'assumed')} · reverse fee ${inr(S.fees.R)} ${src('panelFee')} · no RTO fee · damaged share of returns ${pct(S.fees.delta)}</p>
  <table class="grid"><thead><tr><th>Candidate</th><th>Kept</th><th>Intact RTO</th><th>Return</th><th>Expected m</th><th>Cost ceiling</th><th>Passes</th></tr></thead><tbody>${rows}</tbody></table>
  <p class="formula">m = k(T − C) − o − qR − qδC · ceiling C ≤ (kT − o − qR − g) ÷ (k + qδ) · minimum g = ${inr(S.seller.g)} per ${S.seller.denominator === 'kept' ? 'kept order' : 'expected dispatch'}</p>
  <div class="row">${[['k', 'Kept %'], ['r', 'RTO %'], ['q', 'Return %']].map(([key, l]) => `<label class="field">${l}<input type="number" data-mix="${key}" value="${M.r2(S.mix[key])}" step="any" min="0"></label>`).join('')}
  <label class="field">Reverse fee R (₹)<input type="number" id="in-R" value="${S.fees.R ?? ''}" min="0"></label><label class="field">Damaged share of returns (%)<input type="number" id="in-d" value="${S.fees.delta}" min="0" max="100"></label></div>
  ${st}${e.choice && e.alternative ? `<p class="callout">Demand threshold: ${inr(e.choice.buyer)} needs more than <b>${(e.alternative.econ.expected / e.choice.econ.expected).toFixed(5)}×</b> the mature dispatches of ${inr(e.alternative.buyer)}; ${inr(e.alternative.buyer)} wins while its volume stays above <b>${(e.choice.econ.expected / e.alternative.econ.expected * 100).toFixed(3)}%</b> of ${inr(e.choice.buyer)}'s. Same mix at both prices is an assumption, not learned demand.</p>` : ''}`;
}

function constraintsView(e) {
  const p = e.proc, s = S.seller;
  const body = p.known ? `<div class="kpis"><div><b>${inr(p.funding.perNew)}</b><span>funding per new unit = ${inr(S.costs.C)} purchase + ${inr(S.costs.o)} outside + ${inr(p.funding.reserve)} reserve</span></div>
    <div><b>${p.units} units</b><span>seller cap ${s.cap}: a limit on exposure, not a sales forecast (${p.affordableMax} would fit the cash)</span></div>
    <div><b>${inr(p.need)}</b><span>cash to keep available; ${inr(p.reserveHeld)} of it is reserve held, not an expense</span></div></div>
    <p class="callout ${p.blocked ? 'bad' : ''}">${esc(p.reason)}${p.fallback ? ` Option: shrink to ${p.fallback.units} units (${inr(p.fallback.need)}).` : p.blocked ? ' No smaller batch satisfies the MOQ: renegotiate MOQ, add cash, or hold.' : ''}</p>`
    : `<p class="callout bad">${esc(p.reason)}</p>`;
  return `<h2>Cash, inventory, MOQ and exposure cap</h2><p class="lead">A price can pass while procurement fails. Reserve = ${s.reservePct}% × reverse fee, rounded down: a stress policy held as cash, never booked as a cost.</p>${body}
  <div class="row"><label class="field">Available cash (₹)<input type="number" id="in-cash" value="${s.cash ?? ''}" min="0"></label><label class="field">Owned units<input type="number" id="in-owned" value="${s.owned}" min="0" step="1"></label>
  <label class="field">Seller cap (units)<input type="number" id="in-cap" value="${s.cap}" min="1" step="1"></label><label class="field">Supplier MOQ<input type="number" id="in-moq" value="${s.moq}" min="0" step="1"></label></div>
  <p class="muted">Sources: ₹1,000 cash, cap 9 and MOQ 1 are worked-example assumptions ${src('assumed')}. Supplier MOQ is an evidence gap.</p>`;
}

function decisionView(e) {
  const c = e.choice, a = e.alternative, p = e.proc;
  const sens = e.sensitive ? e.sensitive[0] : null;
  const cell = (l, v, s = '') => `<div class="dc"><span>${l}</span><b>${v}</b>${s ? `<small>${s}</small>` : ''}</div>`;
  const stress = e.stress && c ? e.stress.slice(1).map(x => `${esc(x.label)}: ${inr(x.values[S.quotes.findIndex(q => q.buyer === c.buyer)])}`).join(' · ') : '';
  return `<h2>Decision card · ${esc(S.product.sku)} v${S.product.version}</h2>
  <div class="card ${e.status === 'READY FOR YOUR APPROVAL' ? 'ok' : e.status === 'HOLD' ? 'hold' : 'warn'}"><div class="cardhead"><b>${esc(e.status)}</b><span>Objective: ${S.seller.objective === 'earnings' ? 'earnings per order' : 'competitive start'} · minimum ${inr(S.seller.g)} per ${S.seller.denominator === 'kept' ? 'kept order' : 'expected dispatch'}</span></div>
  ${c ? `<div class="dgrid">${cell('Enter', inr(c.entry), 'estimate ' + inr(c.entryEstimate))}${cell('Buyer pays', inr(c.buyer), 'historical panel')}${cell('Kept-order transfer', inr(c.transfer), 'historical panel')}
  ${cell('Expected contribution', inr(c.econ.expected) + ' / dispatch', 'base case; scenario inputs')}${cell('Quantity', p.known && !p.blocked ? p.units + ' units (cap)' : 'blocked', 'cap is not a forecast')}${cell('Cash to keep available', p.known ? inr(p.need) : '–', p.known ? 'incl. ' + inr(p.reserveHeld) + ' reserve, not an expense' : '')}
  ${cell('Most sensitive assumption', sens ? esc(sens.name) : '–', sens ? esc(sens.text) : '')}${cell('Alternative', a ? inr(a.buyer) + ' → ' + inr(a.econ.expected) : 'none supported', a ? 'earnings per order' : '')}${cell('Review trigger', '9 closed or day 30', 'early: reverse charge > ₹153, damaged return, peer below ₹189, cost > ' + inr(c.ceiling.minimum))}</div>
  <p class="stress"><b>Stress cases:</b> ${stress}</p>` : `<p>No eligible candidate.</p>`}
  ${e.reasons.length ? `<ul class="reasons">${e.reasons.map(r => `<li>${esc(r)}</li>`).join('')}</ul>` : ''}
  <div class="actions"><button class="primary" data-action="approve" ${['READY FOR YOUR APPROVAL', 'WEAK-EVIDENCE TEST'].includes(e.status) ? '' : 'disabled'}>Approve test</button>
  <button data-action="alt" ${a ? '' : 'disabled'}>Switch to alternative</button><button data-action="edit">Edit price</button><button data-action="hold">Hold</button></div>
  <p class="muted">Approving saves a dated snapshot only. No listing edit, purchase or dispatch happens. The seller owns the price.</p></div>
  ${noteMsg ? `<p class="callout">${noteMsg}</p>` : ''}
  <h3>Snapshots</h3>${S.snapshots.length ? `<table class="grid"><thead><tr><th>#</th><th>Action</th><th>Status then</th><th>Choice</th><th>Versions</th><th>State now</th></tr></thead><tbody>${S.snapshots.map(x => `<tr><td>${x.id}</td><td>${esc(x.action)}</td><td>${esc(x.status)}</td><td>${x.choice ? inr(x.choice.buyer) + ' · ' + inr(x.choice.expected) : '–'}</td><td class="muted">${Object.entries(x.versions).map(([k, v]) => k[0] + v).join(' ')}</td><td class="${x.state === 'Current' ? '' : 'neg'}">${esc(x.state)}${x.why ? ': ' + esc(x.why) : ''}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">No snapshot yet.</p>'}`;
}

function reviewView() {
  const L = M.ledger(P.COHORT, S);
  const u = review || M.update(S, L, K);
  const e2 = M.evaluate(u.next), d = M.nextDecision(u.next, L, e2);
  const st = { kept: 'Kept', rto: 'RTO (refused)', return: 'Customer return', pending: 'Pending' };
  const b = u.before, a = u.after;
  const row = (l, x, y, f) => `<tr class="${M.r2(x) !== M.r2(y) ? 'chg' : ''}"><td>${l}</td><td>${f(x)}</td><td>${f(y)}</td></tr>`;
  return `<h2>Review and learn · same SKU, version 1, launched at ${inr(189)}</h2><p class="lead">${src('synthetic')} Nine labelled test dispatches to exercise the loop. They are not observed Meesho orders.</p>
  <table class="grid"><thead><tr><th>Dispatch</th><th>Outcome</th><th>Settlement</th><th>Reverse charge</th><th>Stock</th><th>Contribution</th><th>Cash</th></tr></thead><tbody>${L.rows.map(x => `<tr><td>${x.id}</td><td>${st[x.status]}</td><td>${x.settled === null ? 'not settled' : inr(x.settled)}</td><td>${x.reverse === null ? '–' : inr(x.reverse)}</td><td>${esc(x.stock)}</td><td>${x.contribution === null ? 'open' : inr(x.contribution)}</td><td>${inr(x.cash)}</td></tr>`).join('')}</tbody></table>
  <div class="kpis"><div><b>${inr(L.contribution)}</b><span>closed contribution (${L.closed} closed)</span></div><div><b>${inr(L.cash)}</b><span>net cash so far (bank ${inr(S.seller.cash)} → ${inr(S.seller.cash + L.cash)})</span></div><div><b>${L.intactUnits} units · ${inr(L.inventoryValue)}</b><span>recoverable stock at cost, not cash</span></div><div><b>${L.pending}</b><span>pending: not a sale, not a loss</span></div></div>
  <p class="formula">Closed cash ${inr(L.contribution - L.inventoryValue)} + recovered stock ${inr(L.inventoryValue)} = contribution ${inr(L.contribution)}. Settlements ${inr(L.settlements)}; reverse charges ${inr(L.reverseCharges)} (counted once, on the return only).</p>
  <h3>Inputs before → after</h3><label class="field inline">Prior weight K (pseudo-dispatches) <input type="number" id="in-K" value="${K}" min="1" step="1"> <span class="tag miss">uncalibrated</span></label>
  <table class="grid narrow"><thead><tr><th>Input</th><th>Before</th><th>After</th></tr></thead><tbody>${row('Kept %', b.k, a.k, pct)}${row('RTO %', b.r, a.r, pct)}${row('Return %', b.q, a.q, pct)}${row('Reverse fee R', b.R, a.R, inr)}${row('Damaged share of returns', b.delta, a.delta, pct)}${row('Reserve per unit', b.reserve, a.reserve, inr)}</tbody></table>
  <p class="formula">Blend: (K × prior + closed count) ÷ (K + ${L.closed}). With K = ${K}: kept (${K} × ${b.k}% + ${L.kept}) ÷ ${K + L.closed} = ${pct(a.k)}. R takes the charge actually debited. K is not fitted to any data.</p>
  <h3>Recalculated economics</h3><table class="grid narrow"><thead><tr><th>Candidate</th><th>Before</th><th>After</th><th>Cost ceiling after</th></tr></thead><tbody>${e2.rows.map((r, i) => `<tr><td>${inr(r.buyer)}</td><td>${inr2(ev().rows[i].econ ? ev().rows[i].econ.expected : null)}</td><td><b>${inr2(r.econ.expected)}</b></td><td>C ≤ ${inr(r.ceiling.minimum)}</td></tr>`).join('')}</tbody></table>
  <div class="card ok"><div class="cardhead"><b>Next decision</b><span>seller approves or holds</span></div><p>${esc(d.price)}</p><p>${esc(d.stock)}</p></div>
  <button class="primary" data-action="apply">Apply the update as version ${S.versions.outcomes + 1} inputs</button>`;
}

function render() {
  const e = ev();
  $('strip').innerHTML = strip(e);
  $('banner').innerHTML = banner(e);
  $('change').innerHTML = changeBox();
  const view = { product: productView, alternatives: alternativesView, quotes: quotesView, economics: economicsView, constraints: constraintsView, decision: decisionView, review: reviewView }[step];
  $('main').innerHTML = view(e);
  $('log').innerHTML = S.log.length ? S.log.slice(0, 8).map(x => `<li><b>${esc(x.area)}</b> v${S.versions[x.area]} · ${esc(x.reason)} · quotes ${x.quotes} · ${x.snapshots} snapshot(s) to review</li>`).join('') : '<li class="muted">No changes yet.</li>';
  document.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('on', b.dataset.mode === S.mode));
}

/* Before/after explanation for any change. */
function explain(title, before, after, extra) {
  const lines = [];
  const pick = e => e.choice ? `${inr(e.choice.buyer)} (${inr(e.choice.econ.expected)} / dispatch)` : 'none';
  if (before.status !== after.status) lines.push(`Status: ${esc(before.status)} → <b>${esc(after.status)}</b>`);
  if (pick(before) !== pick(after)) lines.push(`Choice: ${pick(before)} → <b>${pick(after)}</b>`);
  const alt = e => e.alternative ? inr(e.alternative.buyer) : 'none';
  if (alt(before) !== alt(after)) lines.push(`Alternative: ${alt(before)} → <b>${alt(after)}</b>`);
  after.rows.forEach((r, i) => { const x = before.rows[i]; if (r.econ && x.econ && M.r2(r.econ.expected) !== M.r2(x.econ.expected)) lines.push(`${inr(r.buyer)} expected: ${inr(x.econ.expected)} → <b>${inr(r.econ.expected)}</b>; cost ceiling ${inr(x.ceiling.minimum)} → ${inr(r.ceiling.minimum)}`); });
  if (before.proc.need !== after.proc.need || before.proc.blocked !== after.proc.blocked) lines.push(`Cash to keep available: ${inr(before.proc.need)} → <b>${after.proc.known ? inr(after.proc.need) : 'unverified'}</b>${after.proc.blocked ? ' · procurement blocked' : ''}`);
  if (before.cmp.n !== after.cmp.n) lines.push(`Qualified alternatives: ${before.cmp.n} → <b>${after.cmp.n}</b> (range ${after.cmp.n ? inr(after.cmp.min) + '–' + inr(after.cmp.max) : 'none'})`);
  (extra || []).forEach(x => lines.push(x));
  if (!lines.length) lines.push('No decision value changed.');
  lastChange = { title, lines };
}

function apply(area, reason, mutate, extraFn) {
  const before = ev();
  const r = M.change(S, area, reason, mutate);
  const after = ev();
  const extra = [`Quotes: ${r.quoteHit ? '<b>invalidated</b> (product or weight changed what is shipped)' : 'still valid (this change does not alter entry → buyer → transfer)'}`,
    `Snapshots needing review: ${r.invalidated}`].concat(extraFn ? extraFn(after) : []);
  explain(reason, before, after, extra);
  review = null; noteMsg = '';
  render();
}

const DEMOS = {
  comparable: () => { S.mode = 'scenario'; const i = S.register.findIndex(x => x.id === 'M3'); if (S.register[i].status === 'accepted') apply('comparables', 'Comparable M3 ₹210 fails re-check (spec table shows CAT6)', s => { s.register[i].status = 'excluded'; s.register[i].reason = 'Failed re-check: CAT6 in spec table'; }, () => ['₹210 is now priced above every qualified alternative, so it is unsupported. ₹189 stays the competitive start; the comparable range is not willingness to pay.']); step = 'alternatives'; render(); },
  returns: () => { S.mode = 'scenario'; apply('fees', 'Reverse charge ₹165 and half of returns arrive damaged', s => { s.fees.R = 165; s.fees.delta = 50; }, () => ['Reserve rises to ₹33 per unit (20% × ₹165, rounded down): more cash held, not a cost.']); step = 'economics'; render(); },
  cash: () => { S.mode = 'scenario'; apply('seller', 'Supplier MOQ 10 and only ₹700 cash', s => { s.seller.moq = 10; s.seller.cash = 700; }, () => ['The price still passes: procurement, not price, is blocked. Options: renegotiate MOQ, add cash, or hold.']); step = 'constraints'; render(); },
  weight: () => { S.mode = 'scenario'; apply('product', 'Packed weight measured at 520 g (above the 500 g band)', s => { s.product.packedWeight = 520; s.product.packedWeightSource = 'measured'; s.fees.R = null; }, () => ['Return fee for the new band is unknown: no precise earnings until requoted.']); step = 'quotes'; render(); },
  cost90: () => { S.mode = 'scenario'; apply('costs', 'Acquisition cost rises to ₹90', s => { s.costs.C = 90; }); step = 'decision'; render(); },
  reset: () => { S = P.base(); step = 'product'; review = null; K = 20; lastChange = null; noteMsg = ''; render(); }
};

document.addEventListener('click', ev0 => {
  const t = ev0.target.closest('button'); if (!t) return;
  if (t.dataset.step) { step = t.dataset.step; render(); return; }
  if (t.dataset.mode) { const before = ev(); S.mode = t.dataset.mode; explain('Evidence mode: ' + (S.mode === 'real' ? 'real record' : 'prototype scenario'), before, ev()); render(); return; }
  if (t.dataset.demo) { DEMOS[t.dataset.demo](); return; }
  if (t.dataset.fail) { const i = +t.dataset.fail; const id = S.register[i].id, price = S.register[i].price; apply('comparables', `Comparable ${id} ₹${price} fails re-check`, s => { s.register[i].status = 'excluded'; s.register[i].reason = 'Failed re-check'; }); return; }
  const a = t.dataset.action; const e = ev();
  if (a === 'approve') { M.snapshot(S, e, 'Approve ' + inr(e.choice.buyer)); noteMsg = 'Snapshot saved. Nothing was listed, bought or dispatched.'; render(); }
  if (a === 'alt' && e.alternative) { const before = e; S.seller.objective = S.seller.objective === 'earnings' ? 'competitive' : 'earnings'; explain('Seller switched objective', before, ev()); render(); }
  if (a === 'hold') { M.snapshot(S, e, 'Hold'); noteMsg = 'HOLD saved with its reasons.'; render(); }
  if (a === 'edit') { noteMsg = 'A price of your own needs a fresh quote (entry → buyer → transfer) before any earnings are shown. Status stays HOLD for that price; no transfer is inferred.'; render(); }
  if (a === 'requote') { const before = ev(); S.quoteValid = true; S.versions.quotes += 1; S.log.unshift({ area: 'quotes', reason: 'Quotes re-captured (demo assumption)', quotes: 'valid', snapshots: 0 }); explain('Quotes re-captured', before, ev()); render(); }
  if (a === 'apply') { const L = M.ledger(P.COHORT, S); const u = M.update(S, L, K); const before = ev(); const snaps = S.snapshots; const log = S.log; S = u.next; S.snapshots = snaps; S.log = log;
    S.snapshots.filter(x => x.state === 'Current').forEach(x => { x.state = 'Needs review'; x.why = 'Outcome update v' + S.versions.outcomes; });
    S.log.unshift({ area: 'outcomes', reason: `Review applied with K = ${K} (uncalibrated)`, quotes: 'still valid', snapshots: snaps.length });
    explain('Review applied to the same SKU', before, ev(), ['Price is not changed automatically.']); review = u; render(); }
});

document.addEventListener('change', ev0 => {
  const t = ev0.target; const v = t.value === '' ? null : Number(t.value);
  const map = {
    'in-weight': ['product', 'Packed weight edited', s => { const crosses = (v > s.product.weightBand) !== (s.product.packedWeight > s.product.weightBand); s.product.packedWeight = v; s.product.packedWeightSource = 'measured'; if (crosses && v > s.product.weightBand) s.fees.R = null; }],
    'in-C': ['costs', 'Acquisition cost edited', s => { s.costs.C = v; }],
    'in-R': ['fees', 'Reverse fee edited', s => { s.fees.R = v; }],
    'in-d': ['fees', 'Damaged share edited', s => { s.fees.delta = v; }],
    'in-cash': ['seller', 'Available cash edited', s => { s.seller.cash = v; }],
    'in-owned': ['seller', 'Owned units edited', s => { s.seller.owned = v; }],
    'in-cap': ['seller', 'Seller cap edited', s => { s.seller.cap = v; }],
    'in-moq': ['seller', 'Supplier MOQ edited', s => { s.seller.moq = v; }]
  };
  if (map[t.id]) { const [area, reason, f] = map[t.id]; apply(area, reason, f); return; }
  if (t.dataset.mix) { apply('outcomes', 'Outcome mix edited', s => { s.mix[t.dataset.mix] = v; s.mix.source = 'assumed'; }); return; }
  if (t.id === 'in-private') { apply('costs', t.checked ? 'Cost kept private' : 'Cost shared', s => { s.costs.private = t.checked; s.costs.C = t.checked ? null : 55; }); return; }
  if (t.id === 'in-weak') { const before = ev(); S.weakAck = t.checked; explain('Weak-evidence acknowledgement', before, ev()); render(); return; }
  if (t.id === 'in-K') { K = Math.max(1, Math.round(v || 20)); review = null; render(); }
});

window.PCJ = { getState: () => JSON.parse(JSON.stringify(S)), evaluate: () => M.evaluate(S), demo: n => DEMOS[n](), go: s => { step = s; render(); } };
render();
