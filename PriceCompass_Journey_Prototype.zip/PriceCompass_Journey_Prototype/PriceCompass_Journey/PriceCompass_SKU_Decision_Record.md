# PriceCompass one-SKU decision record

**SKU:** PC-CABLE-5M, version 1 · CAT5e Ethernet patch cable, 5 m, white
**Record date:** 4 Oct 2026 · **Prepared for:** Meesho DICE Challenge S3 submission
**Status of the real record:** **HOLD** (justified below). The decision card in section 7 is a **prototype scenario** that runs the same chain on labelled assumptions.

Every number carries one provenance label:

| Label | Meaning |
|---|---|
| **Observed** | Seen by the team on a dated public page. |
| **Historical panel** | Seen by the team in a seller panel about a year ago. It is not a current quote. |
| **Fee page** | Read from Meesho's shipping and returns page [12] and the seller panel. Applicability to this seller still needs confirming. |
| **Estimate** | Derived by formula from the panel's price structure. It is not an executable quote. |
| **Assumption** | A worked-example input. It was not observed. |
| **Generated** | A scenario register row made up for the prototype. |
| **Synthetic** | A labelled prototype test cohort. It was not observed. |
| **Calculation** | Arithmetic on the labelled inputs above. |

## 0. Why this SKU, and what is kept out

The team has three products in the deck: a bottle, a cable and a kurti. There is also a second cable seller, the computer-accessories shopkeeper.

The original 5 m white CAT5e cable has the strongest evidence:
- It is the only product with a **dated public comparable audit** (28 Sep 2026, five asks, each with a logged exclusion reason).
- It has **two historical panel price pairs** (₹189 → ₹96 and ₹210 → ₹116).

The shopkeeper's fields are all supplied calculation inputs, with no capture or seller confirmation. The kurti and bottle are illustrative.

This record uses **only** cable data. Bottle, kurti and shopkeeper figures stay on their own slides as secondary examples and never enter this record. The one exception is the COD-like 73/19/8 mix, which comes from the bottle band. It appears **only** as a labelled stress case, never as a cable input.

## 1. Product truth

| Field | Value | Source |
|---|---|---|
| Unit and specs | CAT5e patch cable, 5 m, white, UTP, RJ45 both ends | Historical panel listing |
| Conductor (copper vs copper-clad aluminium) | **Unresolved** | Gap |
| Pack | Pack of 1 | Historical panel |
| Packed weight | 250 g used. **Not measured**; only the ≤ 500 g fee band matters | Assumption |
| Fulfilment | Self-ship through Meesho logistics | Assumption |
| Offline price | **Not recorded** | Gap |
| Acquisition cost C | ₹55 per unit. If the seller keeps cost private, only the ceiling in section 4 is shown | Assumption |
| Outside cost o | ₹5 per dispatch (packing and preparation, paid on every dispatch) | Assumption |

## 2. Qualified alternatives (comparables)

Public audit, 28 Sep 2026 (Observed):

| Ask | Buyer price | Result | Reason |
|---|---|---|---|
| A1 Meesho, 5 m white CAT5e | ₹165 | Excluded | Out of stock; construction unresolved |
| A2 Meesho, CAT6 | ₹167 | Excluded | Wrong grade |
| A3 Meesho, 10 m | ₹222 | Excluded | Wrong length |
| A4 Shopsy listing | ₹155 | Excluded | Other channel; weak reference |
| A5 Moglix, CAT5 | ₹130 | Excluded | Wrong grade and channel |

**Qualified: 0 of 5.** With no qualified match there is no comparable range for this SKU. A comparable range would describe what buyers can buy instead, not what they will pay.

The real record therefore supports only two outcomes:
- a **justified HOLD**; or
- a **weak-evidence test** that the seller explicitly accepts as a capped trial without market support.

The weak-evidence evidence also cuts against ₹189: the only same-title Meesho listing (₹165, out of stock) and the Shopsy reference (₹155) are both cheaper. ₹189 is **not** shown to be competitive.

The prototype scenario instead uses a generated register (M1–M6, Generated): M1 ₹189, M2 ₹200 and M3 ₹210 are accepted by assumption. M4 (duplicate), M5 (wrong spec) and M6 (unavailable) are excluded. The ₹200 median is a reference only and has no quote.

**Support rule:** a candidate is supported only if at least one qualified alternative sits at or above its buyer price.

## 3. Candidate quotes: entry → buyer pays → kept-order transfer

| Candidate | Seller enters | Buyer pays | Transfer T | Basis |
|---|---|---|---|---|
| Platform suggestion | ₹110 (estimate ₹110.19) | ₹189 | ₹96 | Historical panel; entry is an estimate |
| Current listing | ₹130 (estimate ₹130.34) | ₹210 | ₹116 | Historical panel; entry is an estimate |

**Panel price structure:**
- Buyer = entry + S
- Transfer = entry − 0.18S
- So S = (B − T) ÷ 1.18 and entry = T + 0.18S.

At ₹189, S = ₹78.81, GST on shipping is ₹14.19 and the entry is ₹110.19. At ₹210, S = ₹79.66 and the entry is ₹130.34.

**Spec-vs-arithmetic conflict (documented):**
- The same weight band should carry one shipping charge, but the two pairs imply S values ₹0.85 apart.
- The deck's "₹78.81 shipping" applies exactly only to ₹189.
- Both entries are therefore **estimates within about ₹1**, not executable quotes.

**Acknowledgement.** The historical panel already suggested ₹189. PriceCompass did not discover that price. What it adds:
- the outcome economics behind ₹189;
- the cost ceiling;
- the cash to keep available;
- the alternative and its demand threshold;
- the review trigger;
- the HOLD when evidence is missing.

**Real record:** no current quote exists, so the quote gate fails.

## 4. Outcome economics (accounting definitions)

**Contribution = net receipts + recoverable stock value − acquisition − outside costs.**

- **Net receipts** = settled kept-order transfers − reverse (return) charges debited.
- **Counting each fee once:**
  - Shipping, GST on shipping and platform deductions sit between the buyer price and T, so they are counted once, inside T.
  - The reverse fee R is charged only on customer returns.
  - No RTO fee is charged [12].
- **Recoverable stock:** an intact RTO or return comes back at acquisition value C. An unsellable return (share δ of returns) is worth ₹0.
- **Tax treatment:**
  - T is taken as the panel shows it.
  - The seller's output GST on the cable, input-tax credit and TCS/TDS are **not modelled**. This is an evidence gap for a GST-registered seller.
  - The kurti example on p.4 models 5% product GST separately; that example is not part of this record.
- **The reserve is funding held, not an expense.**

Per dispatch, with k, r, q = kept, RTO and return shares:

| Outcome | Formula | ₹189 | ₹210 |
|---|---|---|---|
| Kept | T − C − o | +₹36 | +₹56 |
| Intact RTO | −o | −₹5 | −₹5 |
| Intact return | −o − R − δC | −₹158 | −₹158 |

Expected contribution per dispatch, base case (85/5/10, R = ₹153, δ = 0):

**m = k(T − C) − o − qR − qδC**

- ₹189: 0.85 × 41 − 5 − 15.3 = **₹14.55**
- ₹210: 0.85 × 61 − 5 − 15.3 = **₹31.55**

**Demand thresholds** (assuming the same costs and outcome mix at both prices):
- ₹189 needs more than **2.16838×** the mature dispatches of ₹210 (31.55 ÷ 14.55, so +116.8%).
- ₹210 wins while its volume stays above **46.117%** of ₹189's volume.

**Cost ceiling** for a minimum g per expected dispatch:

**C ≤ (kT − o − qR − g) ÷ (k + qδ)**

With g = ₹0 and δ = 0: ₹189 → **C < ₹72.12**; ₹210 → **C < ₹92.12**.

### Labelled stress cases

These are separate what-ifs, not a confidence interval. Values are expected ₹ per dispatch.

| What-if | ₹189 | ₹210 |
|---|---|---|
| Base | ₹14.55 | ₹31.55 |
| Highest listed reverse fee, ₹165 | ₹13.35 | ₹30.35 |
| COD-like mix 73/19/8 (bottle band) | ₹12.69 | ₹27.29 |
| Stress: 77.5/7.5/15 with fee ₹165 | ₹2.03 | ₹17.53 |
| Every return unsellable (δ = 100%) | ₹9.05 | ₹26.05 |
| Acquisition cost rises to ₹90 | **−₹15.20** | **+₹1.80** |

### Most sensitive assumption: acquisition cost C

- **Acquisition cost C** (₹55, unconfirmed) flips ₹189 above ₹72.12, which is only +31%.
- **Return share** would have to reach 17.5% (from 10%), which is +75%.
- **Reverse fee** would have to reach ₹298.50.

## 5. Seller constraints: cash, inventory, MOQ, exposure cap

**Objective:** competitive start (seller's choice). Earnings per order is the alternative objective.

**Minimum:** g = ₹0 per **expected dispatch**, meaning positive expected contribution only (Assumption). The denominator is stated explicitly because a ₹25-per-kept-order minimum and a ₹25-per-dispatch minimum pick different candidates; the shopkeeper example on A1 shows this.

**Funding per new unit:**
- ₹55 purchase + ₹5 outside cost + ₹30 reserve = **₹90**.
- The reserve is 20% × ₹153 = ₹30.60, rounded down to ₹30. It is a stress policy.
- At C = ₹90, funding is **₹125 per unit**. That is total funding (₹90 + ₹5 + ₹30), not the reserve.

**Cash and quantity:**
- Cash available is ₹1,000; owned stock is 0; supplier MOQ is 1 (an Assumption and an evidence gap).
- 11 units would fit the cash. The seller sets the cap at **9**.
- **9 × ₹90 = ₹810** to keep available. Of that, ₹270 is reserve held, not an expense.

**A cap is not a forecast.** Nine stocked units are not nine sales.

At C = ₹90, ₹1,000 fits 8 units. A supplier MOQ of 9 would need ₹1,125: hold or renegotiate.

## 6. First-price choice: per-candidate rationale

| Candidate | Comparable support | Quote | Economics | Cash | Rationale |
|---|---|---|---|---|---|
| ₹189 (enter about ₹110) | Real: none · Scenario: M1 ₹189 and M3 ₹210 at or above | Real: not current · Scenario: assumed current | ₹14.55; ceiling ₹72.12 | 9 units, ₹810 | **Competitive start** = lowest supported candidate that passes in the scenario. Not "optimal". |
| ₹210 (enter about ₹130) | Real: none · Scenario: M3 ₹210 | as above | ₹31.55; ceiling ₹92.12 | 9 units, ₹810 | **Alternative**: higher contribution per dispatch. Wins if volume stays above 46.117% of ₹189's. |
| ₹200 (register median) | reference only | **no quote** | not computable | n/a | Not a candidate: no transfer can be inferred. |
| Below ₹189 (₹165 / ₹155 references) | excluded (out of stock / other channel) | no quote | not computable | n/a | Not candidates. They warn that ₹189 may not be competitive. |

**Decision, real record: HOLD.** Three reasons:
1. There is no current quote.
2. 0 comparables qualified.
3. Cost, MOQ and conductor are unconfirmed.

**Decision, prototype scenario:** a capped ₹189 test, or ₹210 if the seller prefers earnings per order. If the register is switched off (0 qualified), only a seller-acknowledged **weak-evidence test** is allowed.

## 7. Decision card (prototype scenario)

| Field | Value |
|---|---|
| Enter | ₹110 (estimate ₹110.19) |
| Buyer pays | ₹189 (historical panel) |
| Kept-order transfer | ₹96 (historical panel) |
| Expected contribution | ₹14.55 per dispatch. Stress: ₹13.35 (fee ₹165) · ₹12.69 (COD-like mix) · ₹2.03 (stress mix) · ₹9.05 (all returns unsellable) · −₹15.20 (C ₹90) |
| Quantity | 9 units (seller cap; not a forecast) |
| Cash to keep available | ₹810, including ₹270 reserve (not an expense) |
| Most sensitive assumption | Acquisition cost: ₹189 fails above ₹72.12 |
| Alternative | ₹210 → ₹31.55 per dispatch |
| Review trigger | All 9 dispatches closed, or day 30, whichever comes first. Review early on any of: a reverse charge above ₹153, a damaged return, a qualified peer below ₹189, or replacement cost above ₹72.12 |
| Seller action | **Approve** (saves a dated snapshot only) · **Edit** (needs a fresh quote first) · **Hold** |

## 8. Learning loop: same SKU, same version, launched at ₹189

The cohort below is a **Synthetic** prototype test cohort, labelled as such. It is not an observed Meesho order record.

| Dispatch | Outcome | Settlement | Reverse charge | Stock | Contribution | Cash |
|---|---|---|---|---|---|---|
| D1–D6 | Kept | ₹96 each, settled | ₹0 | sold | +₹36 each | +₹36 each |
| D7 | RTO (refused) | ₹0 | ₹0 (no RTO fee) | back, intact | −₹5 | −₹60 |
| D8 | Customer return | ₹0 | ₹165 | back, intact | −₹170 | −₹225 |
| D9 | Pending (inside return window) | not settled | n/a | with buyer | open | −₹60 |

**Contribution (8 closed):** closed cash −₹69 + recoverable stock ₹110 = **+₹41**. The 6 kept orders give ₹216, minus ₹5 for the RTO and ₹170 for the return.

**Cash:** settlements ₹576 − reverse charges ₹165 − acquisition ₹495 (9 units) − outside costs ₹45 = **−₹129**. The bank balance moves from ₹1,000 to ₹871.

**Inventory:** 2 intact units at cost (₹110). This is stock, not cash. One unit is still with the buyer.

**Pending:** D9 counts as neither a sale nor a loss.

### Inputs before → after

The update uses K = 20 pseudo-dispatches as the prior weight. **K = 20 is uncalibrated**: it was chosen for illustration and not fitted to any data.

| Input | Before | After | How |
|---|---|---|---|
| Kept | 85% | 82.14% | (20 × 0.85 + 6) ÷ 28 |
| RTO | 5% | 7.14% | (20 × 0.05 + 1) ÷ 28 |
| Return | 10% | 10.71% | (20 × 0.10 + 1) ÷ 28 |
| Reverse fee R | ₹153 | ₹165 | the charge actually debited on D8 |
| Damaged share of returns | 0% | 0% | the one return came back intact |
| Reserve per unit | ₹30 | ₹33 | 20% × ₹165, rounded down |

### Recalculated economics

| Candidate | Before | After | Cost ceiling after |
|---|---|---|---|
| ₹189 | ₹14.55 | **₹11.00** | C < ₹68.39 |
| ₹210 | ₹31.55 | **₹27.43** | C < ₹88.39 |

₹210 now wins while its volume stays above 40.1% of ₹189's.

### Next decision (the seller approves or holds)

- **Price:** keep ₹189. Expected contribution is still ₹11.00 per dispatch, above the ₹0 minimum. **No price change is forced.**
- **Stock:**
  - Relist the 2 intact units now, keeping ₹76 available.
  - Hold new procurement until D9 matures and the quote is re-captured.
  - Then a 7-unit reorder would need ₹727 against ₹838 available (₹871 minus ₹33 reserve for D9).
- **Real record:** still HOLD until a live quote and a qualified comparable exist.

## 9. Prototype cause-and-effect demos (same SKU)

| Demo | What changes | Recalculation | State and invalidation |
|---|---|---|---|
| 1. A comparable fails | M3 ₹210 fails re-check (spec shows CAT6) | Qualified range ₹189–₹210 → ₹189–₹200; median ₹200 → ₹194.50; ₹210 becomes unsupported; the alternative is removed; ₹189 stays | Comparables version +1; snapshot → "Needs review"; quotes stay valid (comparables do not change entry → buyer → transfer) |
| 2. Return cost and damage rise | R ₹153 → ₹165; half of returns unsellable | ₹14.55 → ₹10.60; ₹31.55 → ₹27.60; ceiling → ₹66.78; reserve ₹30 → ₹33; cash to keep ₹810 → ₹837 | Fees version +1; snapshot → "Needs review"; quotes stay valid |
| 3. Cash and MOQ block buying | MOQ 1 → 10; cash ₹1,000 → ₹700 | The price still passes; procurement needs ₹900 for 10 units, above both the cap of 9 and the ₹700 cash | Status: "Price passes · procurement hold". Seller options: renegotiate MOQ, add cash or hold |
| Extra: packed weight 520 g | Crosses the 500 g band | Return fee unknown, so no earnings figure is shown | Product version +1; **quotes invalidated**; HOLD until requoted |
| Extra: acquisition cost ₹90 | C ₹55 → ₹90 | ₹189 → −₹15.20 (fails); ₹210 → +₹1.80; funding ₹125 per unit; 8 units fit | Costs version +1; snapshot → "Needs review" |

## 10. Sources

- **[12] Meesho shipping and returns page:** basis for the return fee and for no RTO fee. Checked 28 Sep 2026. The ₹153–₹165 band for ≤ 500 g was read from the seller panel (2 Oct 2026); its applicability to this seller still needs confirming.
- **[11] Meesho supplier pricing page:** 0% commission and the 7-day payment cycle. Checked 28 Sep 2026.
- **Team public audit, 28 Sep 2026:** the five cable asks in section 2 (team record).
- **Historical seller panel:** the ₹189 / ₹96 and ₹210 / ₹116 pairs, about one year old (team record).
- **Bottle-band panel (team record):** COD RTO 19% and return 8%, used only as the COD-like stress case.
- **Workings:** prototype `model.js` and `test-model.cjs` (21 checks). The deck's Appendix A1 carries the same formulas.
