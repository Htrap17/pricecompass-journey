# PriceCompass one-SKU journey prototype

Open `PriceCompass_Journey_Demo.html` in Chrome, Edge or Safari. It is a single offline file: no server, login or internet, and nothing is stored or sent anywhere.

**SKU:** PC-CABLE-5M v1, a CAT5e cable, 5 m, white, pack of 1. The record is in `PriceCompass_SKU_Decision_Record.md`.

## Demo path (about 3 minutes)

1. Click **Real record** in the sidebar, then step 6. The decision card shows **HOLD**, with three reasons: no current quote, 0 of 5 audit offers qualified, and cost not confirmed.
2. Click **Prototype scenario**. Walk steps 1 to 6: product gaps, then alternatives, quotes, economics (₹14.55 / ₹31.55 plus stress cases), cash (9 units, ₹810), and the decision card. Click **Approve test**; this saves a snapshot only.
3. Run the demos in the sidebar:
   - **1 · A comparable fails:** ₹210 becomes unsupported and the snapshot goes to Needs review.
   - **2 · Return cost and damage rise:** ₹14.55 drops to ₹10.60.
   - **3 · Cash and MOQ block buying:** the price passes but procurement holds.
   - **+ Packed weight:** quotes are invalidated.
   - **Reset everything** between demos.
4. Open step 7, **Review and learn**. It shows the synthetic 9-dispatch cohort, contribution vs cash vs stock, and the K = 20 (uncalibrated) update. ₹189 moves to ₹11.00 and the price is kept. **Apply the update** creates version 2 of the inputs.

## Source and tests

Source files are in `src/`: `record.js` (the decision record), `model.js` (calculations), `app.js`, `index.html` and `styles.css`.

Rebuild with `node src/build.cjs`. Run the tests with:
- `node src/test-model.cjs` (21 checks)
- `NODE_PATH=$(npm root -g) node src/test-browser.cjs` (13 checks; needs Playwright)

Results from 4 Oct 2026 are in `model-results.txt` and `browser-results.txt`.

## Boundaries

The prototype has no Meesho connection and makes no listing edits or purchases. The scenario inputs and the review cohort are labelled assumptions or synthetic data. K = 20 is uncalibrated. No adoption or uplift is claimed.
