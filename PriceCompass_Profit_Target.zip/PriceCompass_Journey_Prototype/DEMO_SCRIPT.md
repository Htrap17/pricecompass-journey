# Earnings target and market comparison walkthrough

Open the prototype. Catalogue, similar seller offers and outcome rates are labelled sample data; shipping uses the labelled half-reverse-fee assumption.

1. Enter purchase cost **₹100**, packing **₹5**, and minimum earnings **₹10**. Keep Ship from my location selected. Click Suggest a price.
2. Show **Price to meet your target: ₹238**. Estimated payout is ₹140.65 to ₹147.73, and average earnings per shipped order are ₹10.08 to ₹17.52, including returns and failed deliveries.
3. Point to **What similar sellers charge**: sample range ₹189 to ₹210 and median ₹200 from three similar offers. The page explains that ₹238 is ₹28 above the range. Meeting the earnings target does not predict that buyers will accept this price.
4. Type **₹210** into the amount field. Average earnings change immediately to **-₹13.72 to -₹6.28**. This price is within the sample range but below the earnings target. There is no slider.
5. Click **Use calculated price** to restore ₹238, then Choose this price. The confirmation screen retains the target and seller comparison. A real net panel payout and total return charge override estimates directly; changing price requires confirmation again.
6. Saving stays in the session and does not change a Meesho listing or approve a stock purchase. Cash funding and source/fee assumptions remain under More details.

Optional: sample costs ₹55/₹5 and target ₹10 still calculate ₹193. Default warehouse fulfilment with unknown carrier and distance now calculates ₹211, above the sample seller range, instead of stopping at ₹210. With Valmo and over 500 km selected, the warehouse target price is ₹202. Warehouse tax and return rules are unchanged.
