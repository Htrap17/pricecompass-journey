# Current price calculation

The price now meets the seller's average earnings target independently of market comparisons. It may be above or below the sample seller range. The result shows the range and median separately, including a specific gap above the range. The slider is removed; the amount field retains live updates. Purchase ₹100, packing ₹5 and target ₹10 calculate ₹238, with ₹10.08 to ₹17.52 average earnings and sample median ₹200.

Latest screenshots: screenshots/price-target-*.jpg. Actual checks: price-target-browser-results.txt. Published at the same submitted GitHub Pages URL. Previous warehouse behavior is documented below; its market-capped suggestion has been replaced by target-based calculation.

# PriceCompass warehouse revision

Open the root index.html or PriceCompass_Journey_Demo.html. The default three-screen seller flow now includes warehouse fulfilment, seller-supplied reverse rates through 2,500 g and a labelled half-return-fee forward assumption. Listed courier and warehouse handling fees receive 18% GST. Returns use reverse shipping plus GST only.

Source is in src/. seller-model.js starts the current scenario and evaluates prices. shipping.js contains the supplied rate card and fee helpers alongside preserved historical shipping calculations. seller-ui.js provides the screens and More details.

Run:

```text
node src/build.cjs
node src/test-model.cjs
node src/test-shipping.cjs
node src/test-seller.cjs
node src/test-warehouse.cjs
```

There are 95 passing calculation checks: 28 historical, 29 original shipping, 23 seller and 15 warehouse. Result files are model-results.txt, shipping-results.txt, seller-results.txt and warehouse-results.txt.

Actual app-browser findings are in warehouse-browser-results.txt. Latest screenshots are screenshots/warehouse-*.jpg. Other browser reports and screenshots describe earlier revisions. The optional src/test-browser.cjs harness was updated and syntax-checked, but was not terminal-executed for this delivery. capture.cjs is an optional screenshot helper; delivered screenshots came from the app browser.

Read VALIDATION.md, SHIPPING_SOURCE_NOTES.md and the package DEMO_SCRIPT.md. supplied-warehouse-rate-card.png is the original seller-supplied screenshot. Its publication date is unknown.

Panel totals are used directly without extra fees. A saved choice is not confirmed approval or a listing update. No live connection or publication is included. Direct offline file opening remains a manual check.
