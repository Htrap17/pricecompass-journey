# Verification: target-based price calculation

Verified 5 October 2026. **95 calculation checks passed:** 28 historical model, 29 original shipping, 23 seller-flow and 15 warehouse. Original historical and fee regression expectations remain unchanged. The seller suite now checks prices above and below the sample range, missing comparisons, higher targets, the ₹100 purchase-cost case and invalid order outcomes.

Purchase ₹100, packing ₹5 and target ₹10 produce **₹238**, with estimated payout ₹140.65 to ₹147.73 and average earnings ₹10.08 to ₹17.52. ₹237 fails the target. Sample range is ₹189 to ₹210, median ₹200. The result identifies the ₹28 gap above the range. At ₹210 the same costs produce -₹13.72 to -₹6.28 average earnings; it is not shown as the target-based price.

The solver finds the lowest positive whole-rupee price meeting the raw downside earnings target. Market comparisons do not cap this result. A positive kept-order share is required for achievable positive earnings. Missing comparisons leave the financial calculation available, with a clear unavailable-comparison message. Invalid shipping/outcome data still blocks a usable calculated price. Safe integer limits prevent unbounded searches. Estimates cannot create confirmed approval.

Actual app-browser checks covered the ₹100 scenario, range/median/gap copy, no slider, immediate updates at ₹210, restoring the calculated price, keyboard progression and comparison on the confirmation screen. All three phone screens had document/scroll widths of 390 pixels; the desktop price screen had matching widths of 1280 pixels. Visible copy had no em/en dashes and no console errors were captured. Current screenshots: price-target-desktop.jpg and price-target-mobile.jpg. Findings: price-target-browser-results.txt.

All source JavaScript passed syntax checks. Standalone entry points are byte-identical and have no external runtime dependencies. The current ZIP passed integrity checks. Direct offline file opening remains a manual check because the app browser blocks file URLs. The optional browser harness was updated but not terminal-executed. Warehouse GST, reverse-fee coverage, reserves, panel override, stale confirmation and historical ledgers are preserved. Comparison and outcome data remain samples, not live marketplace quotes.

---

## Previous warehouse revision verification

# Verification: warehouse fulfilment

Verified 5 October 2026.

## Calculation tests

**91 checks passed:** 28 historical model, 29 original shipping, 19 updated seller-flow and 15 warehouse checks. Results are in the corresponding *-results.txt files.

The original historical and shipping suites still pass unchanged, preserving ledgers, once-only cohort updates, inclusive/exclusive historical GST, old payout examples, RTO ₹0, reserve funding and stale-quote rules. New seller sessions use the supplied GST-exclusive rate profile, independent of historical defaults.

Warehouse checks cover every supplied carrier, both fulfilment columns and all five reverse bands; independent warehouse handling boundaries; 2,500/2,501 g coverage; GST once; unknown carrier and distance ranges; reference fees excluded from returns; published forward estimates limited to seller shipping; manual above-band fees; complete panel override; quote and snapshot invalidation; downside contribution, reserve funding and ledger preservation.

Seller-location example: reverse ₹153 gives forward ₹76.50, forward GST ₹13.77, payout ₹98.73 from ₹189 and total return cost ₹180.54. Warehouse example: 250 g, Valmo, over 500 km gives forward ₹72.50, GST ₹13.05, delivered handling ₹20, handling GST ₹3.60, payout ₹79.85 and total return cost ₹171.10. No warehouse handling is added to customer-return cost.

The updated seller suite verifies the default ₹193 suggestion, raw target comparisons before display rounding, zero and missing inputs, price precision, exploratory prices, no invented recommendations, reserve rules and stale confirmations.

## Actual browser checks

The built page was tested through localhost in the app browser. The default ₹193 suggestion, seller-location ₹98.73 example, warehouse ₹79.85 example and fee breakdown matched the calculator. Warehouse fulfilment with unknown carrier/distance produced no supported suggestion for the sample ₹10 target. Choosing Valmo and over 500 km produced the supported ₹202 warehouse suggestion.

Keyboard activation advanced screens. The slider arrow key updated payout and earnings immediately. Supplying ₹96 net payout and ₹153 total return charge in warehouse mode gave ₹14.55 earnings without further shipping, warehouse or GST subtraction. Saving then changing fulfilment cleared confirmation and marked the saved choice for review. The browser captured no console errors.

All three seller screens were captured on desktop and a 390 x 844 phone. Desktop warehouse screens had matching document/scroll widths of 1280 pixels; phone screens had matching widths of 390 pixels. Expanded warehouse settings and supplied fee tables also remained within the phone width with locally scrollable tables. Visible warehouse copy contained no em or en dashes.

Actual findings: warehouse-browser-results.txt. Latest screenshots: screenshots/warehouse-*.jpg. Older reports and screenshot sets document prior revisions. The optional Playwright harness was updated and syntax-checked, but not terminal-executed; no automated browser-harness pass is claimed.

## Build and limits

All source JavaScript passes syntax checks. Root index.html, journey index.html and PriceCompass_Journey_Demo.html are byte-identical standalone pages with bundled styles, scripts and data and no external runtime dependencies. Source links use internet only when opened deliberately. The new ZIP was integrity-tested.

Direct file opening remains a manual check because the app browser blocks file URLs. The public website was not published or changed. The supplied rate card is not verified as a current official tariff; the half-fee method and fee coverage are seller-authorised assumptions. Warehouse inbound transport, old-inventory and rejected-stock costs are excluded from ordinary earnings. Product tax and withholding remain outside the model. Saving is in-memory only.
