/* Local catalogue handoff and pure price calculations. No network access. */
(function(root){
 'use strict';
 const P=typeof module!=='undefined'?require('./record.js'):root.PCRecord;
 const M=typeof module!=='undefined'?require('./model.js'):root.PCJourney;
 const H=typeof module!=='undefined'?require('./shipping.js'):root.PCShipping;
 const clone=x=>JSON.parse(JSON.stringify(x));
 const money=x=>typeof x==='number'&&Number.isFinite(x)&&x>=0&&Math.abs(x*100-Math.round(x*100))<.000001;
 function catalogue(){const b=P.base(),listing=b.quotes.find(q=>q.label==='Current listing');return {product:clone(b.product),buyerPrice:listing.buyer,source:'simulated',label:'Demo using a sample catalogue'};}
 function start(){const s=P.base();Object.assign(s.shipping,{feeProfile:'supplied',fulfilment:'self',forwardMethod:'half-return',warehouseDistance:'unknown',taxBasis:'exclusive',returnTaxBasis:'exclusive'});s.shipping.mode='online';s.shipping.buyer=catalogue().buyerPrice;s.costs.C=null;s.costs.o=null;s.seller.g=null;s.seller.denominator='dispatch';return s;}
 function costErrors(s){const e=[];if(!money(s.costs.C))e.push('Enter your purchase cost.');if(!money(s.costs.o))e.push('Enter your packing cost.');if(!money(s.seller.g))e.push('Enter your minimum earnings per order.');if(s.costs.private)e.push('Enter your costs to calculate earnings.');return e;}
 function evaluatePrice(state,buyer,options={}){
  const s=clone(state),errors=costErrors(s);s.seller.denominator='dispatch';
  if(!money(buyer)||buyer<=0)errors.push('Enter a buyer price greater than zero, with no more than two decimal places.');
  s.shipping.buyer=buyer;
  const quote=s.shipping.confirmed;
  const confirmed=!options.estimateOnly&&s.shipping.mode==='confirmed'&&quote&&quote.context===H.context(s);
  const stale=s.shipping.mode==='confirmed'&&!confirmed&&!options.estimateOnly;
  if(!confirmed){s.shipping.mode='online';s.shipping.confirmed=null;}
  if(errors.length)return {ok:false,errors,buyer,payout:null,earnings:null,targetMet:false,confirmed:false,stale:!!stale,estimateStatus:'needs-input'};
  const evaluation=M.evaluate(s),shipping=evaluation.shipping,row=evaluation.rows[0],cmp=evaluation.cmp;
  if(!shipping.ok||!row.econRange)return {ok:false,errors:shipping.ok?evaluation.errors:shipping.errors,buyer,payout:shipping.payout,earnings:null,targetMet:false,confirmed:false,stale:!!stale,estimateStatus:'needs-input',comparison:cmp,evaluation};
  const earnings=row.econRange.expected.map(M.r2),kept=row.econRange.kept.map(M.r2);
  const targetMet=row.econRange.expected[0]>0&&earnings[0]>0&&row.econRange.expected[0]>=s.seller.g;
  return {ok:true,errors:[],buyer,payout:shipping.payout,earnings,kept,target:s.seller.g,targetMet,confirmed:!!confirmed,stale:!!stale,supported:cmp.n>0&&buyer>=cmp.min&&buyer<=cmp.max,comparison:cmp,shipping,funding:evaluation.proc,evaluation,estimateStatus:confirmed?'seller-confirmed':'estimated'};
 }
 function suggest(state){
  const cmp=M.comparables(state),errors=costErrors(state);
  if(errors.length)return {ok:false,price:null,reason:errors[0],errors,comparison:cmp};
  const initial=evaluatePrice(state,1,{estimateOnly:true});
  if(!initial.ok)return {ok:false,price:null,reason:initial.errors[0]||'Complete the missing shipping inputs.',comparison:cmp};
  if(!(state.mix.k>0))return {ok:false,price:null,reason:'No positive average earnings are possible when no orders are kept. Review the order outcome rates.',comparison:cmp};
  // The target determines the price. Comparable prices provide context, never a ceiling.
  const limit=Math.floor(Number.MAX_SAFE_INTEGER/100);
  let lo=1,hi=1,result=initial;
  while(!result.targetMet&&hi<limit){lo=hi+1;hi=Math.min(limit,hi*2);result=evaluatePrice(state,hi,{estimateOnly:true});if(!result.ok)break;}
  if(!result.ok||!result.targetMet)return {ok:false,price:null,reason:'A price meeting this target cannot be calculated safely. Review your inputs.',comparison:cmp};
  while(lo<hi){const mid=lo+Math.floor((hi-lo)/2),r=evaluatePrice(state,mid,{estimateOnly:true});if(r.ok&&r.targetMet)hi=mid;else lo=mid+1;}
  result=evaluatePrice(state,lo,{estimateOnly:true});
  return {ok:true,price:lo,result,comparison:cmp,reason:'Lowest whole-rupee price that meets your average earnings target using the cautious estimate.'};
 }
 function setPrice(state,buyer){
  if(!money(buyer)||buyer<=0)return false;
  if(state.shipping.buyer===buyer)return true;
  M.change(state,'shipping','Buyer price changed',s=>{s.shipping.buyer=buyer;s.shipping.mode='online';});return true;
 }
 function confirm(state,transfer,returnFee,date){
  if(!money(transfer)||transfer>state.shipping.buyer||!money(returnFee))return {ok:false,error:'Enter a valid payout and total return fee. Payout cannot exceed the buyer price.'};
  const s=clone(state);s.shipping.mode='confirmed';s.shipping.confirmed={entry:null,transfer,returnGross:returnFee,date,context:H.context(s)};
  const c=H.calculate(s);if(!c.ok)return {ok:false,error:c.errors.join(' ')};
  M.change(state,'shipping','Payout from Meesho confirmed',x=>{x.shipping=s.shipping;});return {ok:true};
 }
 const api={catalogue,start,costErrors,evaluatePrice,suggest,setPrice,confirm,money};
 if(typeof module!=='undefined')module.exports=api;else root.PCSeller=api;
})(globalThis);
